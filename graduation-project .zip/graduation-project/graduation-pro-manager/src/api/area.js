import request from '../utils/request';

export default{
    getAll() {//获取课程
        return request({
            url: `area`,
            method: 'get',
        });
    },
    getPatternAll() {//获取课程
        return request({
            url: `pattern`,
            method: 'get',
        });
    },
    deleteById(id) {//获取课程
        return request({
            url: `area/${id}`,
            method: 'delete',
        });
    },
    deletePatternById(id) {//获取课程
        return request({
            url: `pattern/${id}`,
            method: 'delete',
        });
    },
    saveCategory(categories) {
        return request({
            url: `area/add`,
            method: 'post',
            data:categories
        });
    },
    savePattern(patterns) {
        return request({
            url: `pattern/add`,
            method: 'post',
            data:patterns
        });
    },

}
