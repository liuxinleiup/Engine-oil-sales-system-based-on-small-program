import request from '../utils/request';

export default{
    //banner
    getBanner(page, size){
        return request({
            url: `banner/pageBanner/${page}/${size}`,
            method: 'get',
        });
    },
    savebanner(banner){
        return request({
            url: `banner/addBanner`,
            method: 'post',
            data:banner
        });
    },
    deleteBanner(id) {//
        return request({
            url: `banner/remove/${id}`,
            method: 'delete',
        });
    },
}
