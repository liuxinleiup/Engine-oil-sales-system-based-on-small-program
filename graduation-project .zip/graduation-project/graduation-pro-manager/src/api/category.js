import request from '../utils/request';

export default{
    getAll() {//获取课程
        return request({
            url: `category`,
            method: 'get',
        });
    },
    deleteById(id) {//获取课程
        return request({
            url: `category/${id}`,
            method: 'delete',
        });
    },
    saveCategory(categories) {
        return request({
            url: `category/add`,
            method: 'post',
            data:categories
        });
    },

}
