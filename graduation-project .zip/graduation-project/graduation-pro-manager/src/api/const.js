
export default{
    FileUploadInterface() {//获取QR
        // return 'https://www.mofangkongjian.com:8001/rubikspace/file/upload'
        return 'http://localhost:8888/costume/file/upload'
    },

}
