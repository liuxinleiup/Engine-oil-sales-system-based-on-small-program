import request from '../utils/request';

export default{

    saveCoupon(coupon) {//获取课程
        return request({
            url: `coupon/saveCoupon`,
            method: 'post',
            data:coupon
        });
    },
    listCoupon(coupon, page, size) {//获取课程
        return request({
            url: `coupon/conditionSearch/${page}/${size}`,
            method: 'post',
            data:coupon
        });
    },
    deleteByids(ids) {//获取课程
        return request({
            url: `coupon/deleteByids`,
            method: 'delete',
            data:ids
        });
    },

}
