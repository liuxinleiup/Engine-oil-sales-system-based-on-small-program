import request from '../utils/request';

export default{
    queryAll( page, size) {
        return request({
            url: `logistics-info/queryAll/${page}/${size}`,
            method: 'get'
        });
    },
    ordersReceived(page, size) {
        return request({
            url: `logistics-info/ordersReceived/${page}/${size}`,
            method: 'get',
        });
    },
    receptionOrder(id) {
        return request({
            url: `logistics-info/receptionOrder/${id}`,
            method: 'get',
        });
    },

    queryInfoById(id) {
        return request({
            url: `logistics-info/queryInfoById/${id}`,
            method: 'get',
        });
    },
    updateInfo(info) {
        return request({
            url: `logistics-info/updateInfo`,
            method: 'post',
            data:info
        });
    },
    removeInfo(id) {
        return request({
            url: `logistics-info/removeInfo/${id}`,
            method: 'delete',
        });
    },


}
