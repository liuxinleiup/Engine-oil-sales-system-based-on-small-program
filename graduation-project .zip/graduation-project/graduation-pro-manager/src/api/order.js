import request from '../utils/request';

export default{
    conditionSearch(order, page, size) {
        return request({
            url: `t-order/conditionSearch/${page}/${size}`,
            method: 'post',
            data:order
        });
    },
    deleteById(id) {
        return request({
            url: `t-order/${id}`,
            method: 'delete',
        });
    },
    shipments(orderNo,  trackNum) {
        return request({
            url: `t-order/ship/${orderNo}/${trackNum}`,
            method: 'get',
        });
    },
}
