import request from '../utils/request';

export default{
    getCategory() {
        return request({
            url: `category`,
            method: 'get',
        });
    },
    getArea() {
        return request({
            url: `area`,
            method: 'get',
        });
    },
    getSaleAttr() {
        return request({
            url: `saleattr`,
            method: 'get',
        });
    },
    saveProduct(spuInfo) {//
        return request({
            url: `spu-info/saveSpuInfo`,
            method: 'post',
            data:spuInfo
        });
    },
    getProduct(spuInfo, page, size) {//
        return request({
            url: `spu-info/${page}/${size}`,
            method: 'post',
            data:spuInfo
        });
    },
    getById(id) {//
        return request({
            url: `spu-info/${id}`,
            method: 'get',
        });
    },
    deleteById(id) {//
        return request({
            url: `spu-info/${id}`,
            method: 'delete',
        });
    },
    update(spuInfo) {//
        return request({
            url: `spu-info/updateSpu`,
            method: 'put',
            data:spuInfo
        });
    },
}

