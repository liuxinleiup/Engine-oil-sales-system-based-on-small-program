import request from '../utils/request';

export default{
    conditionSearch(user, page, size) {
        return request({
            url: `user/conditionlist/${page}/${size}`,
            method: 'post',
            data:user
        });
    },
    deleteById(id) {
        return request({
            url: `user/${id}`,
            method: 'delete',
        });
    },
    deleteByIds(ids) {
        return request({
            url: `user/deleteByids`,
            method: 'delete',
            data:ids
        });
    },
    getLoadChatList(){
        return request({
            url: `/chat/loadChatList`,
            method: 'post',
        });
    }
}
