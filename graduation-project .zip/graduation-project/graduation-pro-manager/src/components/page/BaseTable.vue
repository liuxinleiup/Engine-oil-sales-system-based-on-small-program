<template>
  <div>
    <el-row>
      <el-col :span="4" :offset="2">
        <div v-for="item in chatList"
             @click="switchChat(item.id)"
             style="cursor: pointer;height: 70px;width:200px;background: #e7e6e6;padding: 10px 0px">
          <img :src="item.avatar" style=" border-radius: 50%;;height: 50px ;width: 50px;">
          <div style="margin-left: 5px;">{{ item.name }}</div>
        </div>
      </el-col>
      <el-col :span="15">
        <div class="container" style="height: 500px;overflow: scroll">
          <div v-for="(item, index) in curList" :key="index">
            <!-- 聊天列表 -->
            <div class="user-chat-list u-flex" :class="{'user-chat-me':item.isme}">

              <!-- 内容 -->
              <div class="user-chat-list-body">
                <img v-if="!item.isme" style="width: 50px;height: 50px;border-radius: 50%" :src="item.avatar"/>

                <span v-if="item.type=='text'">{{ item.msg }}</span>

                <img v-if="item.isme"
                     style="width: 50px;height: 50px;border-radius: 50%;
                     float: right;margin-top: -10px" :src="item.avatar"/>
              </div>
            </div>
          </div>
        </div>
        <div>
          <el-input placeholder="请输入内容" v-model="msg">
            <el-button slot="append" icon="el-icon-position" @click="send()" style="font-size: 25px"></el-button>
          </el-input>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import indexApi from '../../api/user';

export default {
  name: 'basetable',
  data() {
    return {
      path: 'ws://localhost:8888/chat/000',
      socket: '',
      msg: '',
      list: [],//所有的聊天数据
      curList: [],//当前用户的聊天数据
      toUid: '',
      avatar: 'https://gulipro-edu.oss-cn-beijing.aliyuncs.com/images/kefu.jpeg',
      chatList: []
    };
  },
  mounted() {
    this.getLoadChatList();
  },
  methods: {
    switchChat(uid) {
      this.toUid = uid;
      //过滤数组，从list当中筛选出数据添加到curList当中
      this.curList = [];
      for (let i = 0; i < this.list.length; i++) {
        if (this.list[i].fromUid === this.toUid) {
          this.curList.push(this.list[i]);
        }
      }
    },
    getLoadChatList() {
      indexApi.getLoadChatList().then(res => {
        if (res.data.list != undefined) {
          this.chatList = res.data.list;
        }
        // 初始化
        this.init();
      });
    },
    init: function () {
      if (typeof (WebSocket) === 'undefined') {
        alert('您的浏览器不支持socket');
      } else {
        // 实例化socket
        this.socket = new WebSocket(this.path);
        // 监听socket连接
        this.socket.onopen = this.open;
        // 监听socket错误信息
        this.socket.onerror = this.error;
        // 监听socket消息
        this.socket.onmessage = this.getMessage;
      }
    },
    open: function () {
      console.log('socket连接成功');
    },
    error: function () {
      console.log('连接错误');
    },
    getMessage: function (msg) {
      let data = JSON.parse(msg.data);
      //判断该消息在当前列表中是否存在
      let ids = [];
      for (let i = 0; i < this.chatList.length; i++) {
        ids.push(this.chatList[i].id);
      }
      if (data.length === 1 && !ids.includes(data[0].fromUid)) {
        let contact = {
          id: data[0].fromUid,
          avatar: data[0].avatar,
          name: data[0].name,
        }
        this.chatList.push(contact);
      }
      for (let i = 0; i < data.length; i++) {
        data[i].isme = false;
        data[i].type = 'text';
      }
      for (let i = 0; i < data.length; i++) {
        this.list.push(data[i]);
      }
      //判断是否添加到curList
      if (data.length === 1 && data[0].fromUid === this.toUid) {
        this.curList.push(data[0]);
      }
    },
    send: function () {
      let param = {
        fromUid: '000',
        toUid: this.toUid,
        msg: this.msg,
        isme: true,
        type: 'text',
        avatar: this.avatar
      };
      this.curList.push(param);
      this.list.push(param);
      this.msg = ""
      this.socket.send(JSON.stringify(param));
    },
    close: function () {
      console.log('socket已经关闭');
    }
  },
  destroyed() {
    // 销毁监听
    this.socket.onclose = this.close;
  }
};
</script>

<style>
.user-chat-list {
  padding: 20px 0;
}

.user-chat-list > img {
  width: 50px;
  height: 50px;
  border-radius: 100%;
  flex-shrink: 0;
}

.user-chat-list-body {
  position: relative;
  background: #e0dfdf;
  padding: 25px;
  margin-left: 20px;
  border-radius: 20px;
  margin-right: 100px;
}

.user-chat-list-body:after {
  position: absolute;
  left: -30px;
  right: 0;
  content: '';
  width: 0;
  height: 0;
  border: 16px solid #e0dfdf;
  top: 20px;
  border-color: transparent #e0dfdf transparent transparent;
}

.user-chat-me {
  justify-content: flex-end;

}

.user-chat-me .user-chat-list-body {
  margin-right: 20px;
  margin-left: 100px;
}

.user-chat-me .user-chat-list-body:after {
  left: auto;
  right: -30px;
  transform: rotate(180deg);
  border-color: transparent #e0dfdf transparent transparent;
}

.user-chat-list-body > image {
  max-width: 150px;
  max-height: 200px;
}

.user-chat-time {
  padding: 50px 0;
  color: #a2a2a2;
  font-size: 24px;
}

.el-select .el-input {
  width: 130px;
  height: 30px;
}

.input-with-select .el-input-group__prepend {
  background-color: #fff;
}
</style>
