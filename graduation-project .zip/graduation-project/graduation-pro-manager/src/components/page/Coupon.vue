<template>
  <div class="container">
    <div class="handle-box">
      <el-button
          type="primary"
          icon="el-icon-delete"
          class="handle-del mr10"
      >批量删除
      </el-button>
<!--      <el-select style="width: 100px" v-model="conditionSearch.isputaway" placeholder="请选择">-->
<!--        <el-option-->
<!--            label="下架"-->
<!--            value="false">-->
<!--        </el-option>-->
<!--        <el-option-->
<!--            label="上架"-->
<!--            value="true">-->
<!--        </el-option>-->
<!--        <el-option-->
<!--            label="全部"-->
<!--            value="">-->
<!--        </el-option>-->
<!--      </el-select>-->
      <el-input style="width: 170px" v-model="conditionSearch.couponName" placeholder="产品名"
                class="handle-input mr10"></el-input>
      <el-button type="primary" icon="el-icon-search" @click="getData()">搜索</el-button>

      <el-button type="primary" icon="el-icon-plus" @click="dialogVisible=!dialogVisible">新增</el-button>

      <el-button type="primary" icon="el-icon-refresh" @click="reset()" style="margin-left: 10px">重置</el-button>
    </div>

    <el-table
        :data="coupons"
        border
        class="table"
        ref="multipleTable"
        header-cell-class-name="table-header"
    >
      <el-table-column type="selection" width="55" align="center"></el-table-column>
      <el-table-column prop="couponName" label="优惠券名称" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column label="优惠券类型">
        <template slot-scope="scope">
          <span>{{ scope.row.useType === 0 ? "全场通用" : scope.row.useType === 1 ? "指定分类" : "指定商品" }}</span>
        </template>
      </el-table-column>
      <el-table-column label="使用门槛">
        <template slot-scope="scope">
          <span style="color: red"> {{ scope.row.minPoint > 0 ? "不限门槛" : +scope.row.minPoint + "起" }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="num" label="发行数量"  width="85"></el-table-column>
      <el-table-column prop="amount" label="优惠额度" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column label="领取时间">
        <template slot-scope="scope">
          <span > {{ scope.row.enableStartTime+" / "+ scope.row.enableEndTime}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="note" label="备注" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column label="操作" width="180" align="center">
        <template slot-scope="scope">
          <router-link style="margin-right: 15px" :to="{path:'addPro',query:{id:scope.row.id}}">
            <el-button type="warning" icon="el-icon-edit" circle>
            </el-button>
          </router-link>
          <el-button type="primary"
                     @click="showDetail(scope.row.detail)"
                     icon="el-icon-view" circle></el-button>
          <el-button type="danger"
                     @click="deleteByids(scope.row.id)"
                     icon="el-icon-delete" circle></el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination
          background
          layout="total, prev, pager, next"
          :current-page="page"
          :page-size="pageSize"
          :total="pageTotal"
          @current-change="handlePageChange"
      ></el-pagination>
    </div>


    <!--    新增-->
    <div>
      <el-dialog
          title="新增"
          :visible.sync="dialogVisible"
          width="40%">
        <el-form ref="form" :model="form" label-width="120px">
          <el-form-item label="优惠券名称">
            <el-input v-model="form.couponName"></el-input>
          </el-form-item>
          <el-form-item label="优惠券数量">
            <el-input v-model="form.num" type="number"></el-input>
          </el-form-item>
          <el-form-item label="优惠券金额">
            <el-input v-model="form.amount"></el-input>
          </el-form-item>
          <el-form-item label="使用门槛">
            <el-input v-model="form.minPoint"></el-input>
          </el-form-item>
          <el-form-item label="起始日期">
            <el-col :span="11">
              <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="form.enableStartTime"
                  value-format="yyyy-MM-dd"
                  style="width: 100%;"
              ></el-date-picker>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="form.enableEndTime"
                  value-format="yyyy-MM-dd"
                  style="width: 100%;"
              ></el-date-picker>
            </el-col>
          </el-form-item>
          <el-form-item label="使用类型">
            <el-select v-model="form.useType" placeholder="请选择">
              <el-option label="全场通用" :value="0"/>
              <el-option label="指定分类" :value="1"/>
              <el-option label="指定商品" :value="2"/>
            </el-select>
          </el-form-item>
          <el-form-item label="分类" v-if="form.useType===1">
            <el-select v-model="form.cid" placeholder="请选择">
              <el-option v-for="item in categorys" :label="item.catelogName" :value="item.id"/>
            </el-select>
          </el-form-item>
          <el-form-item label="展示样式">
            <el-radio-group v-model="form.showType">
              <el-radio label="仿京东" :value="1"></el-radio>
              <el-radio label="仿淘宝" :value="2"></el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="备注">
            <el-input type="textarea" rows="5" v-model="form.note"></el-input>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button type="primary" @click="saveCoupon">确 定</el-button>
       </span>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import categoryApi from '../../api/category.js';
import couponApi from '../../api/coupon.js';

export default {
  name: "Coupon",
  created() {
    this.getData();
    this.getCategory();
    // this.getSpuinfo();
  },
  data() {
    return {
      dialogVisible: false,
      form: {
        couponName: '',
        num: null,
        amount: null,
        enableEndTime: '',
        enableStartTime: '',
        useType: '',
        showType: '',
        minPoint: null,
        note: '',
        cid: null,
        spuid: null,
      },
      page: 1,
      pageSize: 10,
      pageTotal: 0,
      categorys: [],
      coupons: [],
      conditionSearch: {
        couponName: ''
      }
    }
  },
  methods: {
    // 分页导航
    handlePageChange(val) {
      this.pageIndex = val;
      this.getProduct();
    },
    getCategory() {
      categoryApi.getAll().then(res => {
        this.categorys = res.data.categorys;
      })
    },
    getData() {
      couponApi.listCoupon(this.conditionSearch, this.page, this.pageSize).then(res => {
        console.log(res)
        this.pageTotal = res.data.total;
        this.coupons = res.data.rows;
      })
    },
    deleteByids(id) {
      couponApi.deleteByids([id]).then(res => {
        if (res.success) {
          this.getData()
        } else {
          this.$message.error(res.message)
        }
      })
    },
    saveCoupon() {
      couponApi.saveCoupon(this.form).then(res => {
        if (res.success) {
          this.$message.success("添加成功")
          this.dialogVisible = false
          this.resetForm()
          this.getData()
        } else {
          this.$message.error(res.message)
        }
      })
    },
    resetForm() {
      this.form = {
        couponName: '',
        num: null,
        amount: null,
        enableEndTime: '',
        enableStartTime: '',
        useType: '',
        showType: '',
        minPoint: null,
        note: '',
        cid: null,
        spuid: null,
      }
    },
    reset() {
      this.conditionSearch = {};
      this.getData()
    }
  }
}
</script>

<style scoped>
.handle-box {
  margin-bottom: 20px;
}


.handle-input {
  width: 300px;
  display: inline-block;
  margin-left: 10px;
}
</style>
