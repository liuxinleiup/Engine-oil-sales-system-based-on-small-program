<template>
    <div class="">
        <div class="container">
            <el-tabs v-model="activeName">
                <el-tab-pane :label="`banner设置`" name="third">
                    <el-row>
                        <el-col :span="10">
                            <el-card class="box-card" style="width: 100%;margin-bottom: 15px"  v-for="(item, index) in banners">
                                <div slot="header" class="clearfix">
                                    <span>{{item.title}}</span>
                                    <el-button style="float: right; padding: 3px 0" type="text" @click="deleteBanner(item.id)">删除</el-button>
                                </div>
                                <img style="width: 100%; height: 230px" :src="item.imageUrl"/>
                            </el-card>
                        </el-col>
                        <el-col :span="10" :offset="2">
                            <el-input placeholder="请输入内容" v-model="banner.title">
                                <template slot="prepend">标题</template>
                            </el-input>
                            <el-input placeholder="请输入内容" v-model="banner.linkUrl" style="margin-top: 15px;margin-bottom: 15px">
                                <template slot="prepend">URL</template>
                            </el-input>
                            <el-upload
                                    class="upload-demo"
                                    drag
                                    :on-success="handleAvatarSuccess2"
                                    :action="fileurl"
                                    multiple>
                                <i class="el-icon-upload"></i>
                                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                            </el-upload>
                            <el-button @click="savebanner()">保存</el-button>
                        </el-col>
                    </el-row>
                </el-tab-pane>
            </el-tabs>
        </div>
    </div>
</template>

<script>
    import bannerApi from '../../api/banner';
    import constVal from '../../api/const';

    export default {
        name: 'other',
        created() {
            this.getBanner();
            this.fileurl = constVal.FileUploadInterface();
        },
        data() {
            return {
                adswitch:false,
                activeName: 'third',
                banners:[],
                banner:{
                    title:'',
                    linkUrl:''
                },
                fileurl:'',
            }
        },
        methods: {
            //获取banner
            getBanner(){
                bannerApi.getBanner(1, 4).then( res=>{
                    this.banners = res.data.items;
                })
            },
            savebanner(){
                if (this.banner.title == '' || this.linkUrl == ''){
                    this.$message.info("请输入内容")
                    return;
                }
                bannerApi.savebanner(this.banner).then(res=>{
                    if (res.success){
                        this.$message.success("设置成功")
                        this.getBanner();
                    }else{
                        this.$message.error(res.message)
                    }
                })
            },
            //删除banner
            deleteBanner(id){
                bannerApi.deleteBanner(id).then( res=>{
                    if (res.success){
                        this.$message.success("删除成功")
                        this.getBanner();
                    }else{
                        this.$message.error(res.message)
                    }
                })
            },
            handleAvatarSuccess2(res) {
                this.banner.imageUrl = res.data.url;
            },
        },

    }

</script>

<style>

</style>

