<template>
    <div class="container">
        <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="地区管理" name="first">
                <el-row>
                    <el-col>
                        <div style="margin-bottom:10px;">
                            <el-button type="primary" icon="el-icon-plus" size="mini" @click="addLimitStu()">添加</el-button>
                        </div>
                    </el-col>
                    <el-col :span="11">
                        <el-table
                                :data="categoryList"
                                style="width: 100%">
                            <el-table-column
                                    label="序号"
                            >
                                <template slot-scope="scope">
                                    {{scope.$index+1}}
                                </template>
                            </el-table-column>
                            <el-table-column
                                    label="地区名"
                            >
                                <template slot-scope="scope">
                                    <div @click="priceInput=false">
                                        <el-input v-model="scope.row.areaName"></el-input>
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column
                                    label="操作">
                                <template slot-scope="scope">
                                    <el-button size="mini" type="danger" icon="el-icon-close" circle @click="removeTempData(scope.$index)"></el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                        <div style="margin-top:10px;">
                            <el-button type="primary" size="mini" @click="saveData()">保存</el-button>
                        </div>
                    </el-col>


                    <el-col :span="12" :offset="1">
                        <el-table
                                :data="tableData"
                                style="width: 100%">
                            <el-table-column
                                    label="序号"
                            >
                                <template slot-scope="scope">
                                    {{scope.$index+1}}
                                </template>
                            </el-table-column>
                            <el-table-column
                                    label="类别名"
                            >
                                <template slot-scope="scope">
                                    <div @click="priceInput=false">
                                        <el-input :disabled="true" v-model="scope.row.areaName"></el-input>
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column
                                    fixed="right"
                                    label="操作">
                                <template slot-scope="scope">
                                    <el-tooltip class="item" effect="dark" content="删除该地区会删除此地区下的商品信息" placement="top-start">
                                        <el-button @click="deleteById(scope.row.id)" type="text" size="small">删除</el-button>
                                    </el-tooltip>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-col>
                </el-row>
            </el-tab-pane>

            <el-tab-pane label="图案管理" name="second">
                <el-row>
                    <el-col>
                        <div style="margin-bottom:10px;">
                            <el-button type="primary" icon="el-icon-plus" size="mini" @click="addLimitPattern()">添加</el-button>
                        </div>
                    </el-col>
                    <el-col :span="11">
                        <el-table
                                :data="patternList"
                                style="width: 100%">
                            <el-table-column
                                    label="序号"
                            >
                                <template slot-scope="scope">
                                    {{scope.$index+1}}
                                </template>
                            </el-table-column>
                            <el-table-column
                                    label="图案"
                            >
                                <template slot-scope="scope">
                                    <div @click="priceInput=false">
                                        <el-input v-model="scope.row.patterName"></el-input>
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column
                                    label="操作">
                                <template slot-scope="scope">
                                    <el-button size="mini" type="danger" icon="el-icon-close" circle @click="removePatternData(scope.$index)"></el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                        <div style="margin-top:10px;">
                            <el-button type="primary" size="mini" @click="savePattern()">保存</el-button>
                        </div>
                    </el-col>

                    <el-col :span="12" :offset="1">
                        <el-table
                                :data="patternTable"
                                style="width: 100%">
                            <el-table-column
                                    label="序号"
                            >
                                <template slot-scope="scope">
                                    {{scope.$index+1}}
                                </template>
                            </el-table-column>
                            <el-table-column
                                    label="类别名"
                            >
                                <template slot-scope="scope">
                                    <div @click="priceInput=false">
                                        <el-input :disabled="true" v-model="scope.row.patterName"></el-input>
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column
                                    fixed="right"
                                    label="操作">
                                <template slot-scope="scope">
                                    <el-tooltip class="item" effect="dark" content="删除该地区会删除此地区下的商品信息" placement="top-start">
                                        <el-button @click="deletePatternById(scope.row.id)" type="text" size="small">删除</el-button>
                                    </el-tooltip>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-col>
                </el-row>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>

<script>
    import areaApi from '../../../api/area.js';

    export default {
        name: 'areaManager',
        created() {
            this.getData();
            this.getPattern();
        },
        data(){
            return{
                activeName: 'first',
                tableData:[],
                patternTable:[],
                categoryList:[],
                patternList:[],
            }
        },
        methods:{
            handleClick(tab, event) {
                console.log(tab, event);
            },
            getData(){
                areaApi.getAll().then( res=>{
                    this.tableData = res.data.areas;
                })
            },
            getPattern(){
                areaApi.getPatternAll().then( res=>{
                    this.patternTable = res.data.patterns;
                })
            },
            deleteById(id){
                areaApi.deleteById(id).then(res=>{
                    if (res.success){
                        this.getData();
                    }else{
                        this.$message.error(res.message)
                    }
                })
            },
            deletePatternById(id){
                areaApi.deletePatternById(id).then(res=>{
                    if (res.success){
                        this.getPattern();
                    }else{
                        this.$message.error(res.message)
                    }
                })
            },
            saveData(){
                //校验
                for (let limitListElement of this.categoryList) {
                    if (limitListElement.areaName == null){
                        console.log(limitListElement)
                        this.$message.error("请输入完整数据")
                        return
                    }
                }
                areaApi.saveCategory(this.categoryList).then(res=>{
                    if (res.success){
                        this.categoryList = [],
                            this.getData();
                    }else{
                        this.$message.error(res.message)
                    }
                })
            },
            savePattern(){
                //校验
                for (let limitListElement of this.patternList) {
                    if (limitListElement.patterName == null){
                        this.$message.error("请输入完整数据")
                        return
                    }
                }
                areaApi.savePattern(this.patternList).then(res=>{
                    if (res.success){
                        this.patternList = []
                        this.getPattern();
                    }else{
                        this.$message.error(res.message)
                    }
                })
            },
            addLimitStu() {
                const saleAttr = {
                    areaName: null,
                }
                this.categoryList.push(saleAttr)
            },
            addLimitPattern() {
                const pattern = {
                    patterName: null,
                }
                this.patternList.push(pattern)
            },
            removeTempData(index) {
                this.limitList.splice(index, 1)
            },
            removePatternData(index) {
                this.patternList.splice(index, 1)
            },
        }
    };
</script>

<style scoped>

</style>
