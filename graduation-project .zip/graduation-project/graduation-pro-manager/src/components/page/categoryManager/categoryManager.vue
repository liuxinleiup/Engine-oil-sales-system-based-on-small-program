<template>
    <div class="container">
        <el-row>
            <el-col>
                <div style="margin-bottom:10px;">
                    <el-button type="primary" icon="el-icon-plus" size="mini" @click="addLimitStu()">添加</el-button>
                </div>
            </el-col>
            <el-col :span="11">
                <el-table
                        :data="categoryList"
                        style="width: 100%">
                    <el-table-column
                            label="序号"
                    >
                        <template slot-scope="scope">
                            {{scope.$index+1}}
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="类别名"
                    >
                        <template slot-scope="scope">
                            <div @click="priceInput=false">
                                <el-input v-model="scope.row.catelogName"></el-input>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="图片"
                    >
                        <template slot-scope="scope">
                            <el-upload
                                    class="upload-demo"
                                    :action="fileurl"
                                    :on-success="handleAvatarSuccess"
                                    list-type="picture">
                                <el-button size="small" type="primary" @click="updateFile(scope.$index)">点击上传</el-button>
                            </el-upload>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="操作">
                        <template slot-scope="scope">
                            <el-button size="mini" type="danger" icon="el-icon-close" circle @click="removeTempData(scope.$index)"></el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div style="margin-top:10px;">
                    <el-button type="primary" size="mini" @click="saveData()">保存</el-button>
                </div>
            </el-col>

            <el-col :span="12" :offset="1">
                <el-table
                        :data="tableData"
                        style="width: 100%">
                    <el-table-column
                            label="序号"
                    >
                        <template slot-scope="scope">
                            {{scope.$index+1}}
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="类别名"
                    >
                        <template slot-scope="scope">
                            <div @click="priceInput=false">
                                <el-input :disabled="true" v-model="scope.row.catelogName"></el-input>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            label="图片"
                    >
                        <template slot-scope="scope">
                            <el-image
                                    style="width: 50px; height: 50px"
                                    :src="scope.row.img"
                                    fit="cover"></el-image>
                        </template>
                    </el-table-column>
                    <el-table-column
                            fixed="right"
                            label="操作">
                        <template slot-scope="scope">
                            <el-tooltip class="item" effect="dark" content="删除该分类会删除此分类下的商品信息" placement="top-start">
                                <el-button @click="deleteById(scope.row.id)" type="text" size="small">删除</el-button>
                            </el-tooltip>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-row>

    </div>
</template>

<script>
    import categoryApi from '../../../api/category.js';
    import constVal from '../../../api/const';

    export default {
        name: 'categoryManager',
        created() {
            this.getData();
            this.fileurl = constVal.FileUploadInterface();
        },
        data(){
            return{
                tableData:[],
                categoryList:[],
                imageUrl: '',
                fileurl:'',
                curIndex:0,
            }
        },
        methods:{
            updateFile(index){
              this.curIndex = index;
            },
            handleAvatarSuccess(res, file) {
                this.categoryList[this.curIndex].img = res.data.url
            },
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file);
            },
            getData(){
                categoryApi.getAll().then( res=>{
                    this.tableData = res.data.categorys;
                })
            },
            deleteById(id){
                categoryApi.deleteById(id).then(res=>{
                    if (res.success){
                        this.getData();
                    }else{
                        this.$message.error(res.message)
                    }
                })
            },
            saveData(){
                //校验
                for (let limitListElement of this.categoryList) {
                    if (limitListElement.catelogName == null){
                        this.$message.error("请输入完整数据")
                        return
                    }
                }
                categoryApi.saveCategory(this.categoryList).then(res=>{
                    if (res.success){
                        this.categoryList = [],
                        this.getData();
                    }else{
                        this.$message.error(res.message)
                    }
                })
            },
            addLimitStu() {
                const saleAttr = {
                    catelogName: null,
                }
                this.categoryList.push(saleAttr)
            },
            removeTempData(index) {
                this.categoryList.splice(index, 1)
            },
        }
    };
</script>

<style scoped>

</style>
