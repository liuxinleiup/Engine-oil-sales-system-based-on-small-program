<template>
  <div>
    <el-drawer
        title="物流信息"
        :visible.sync="drawer"
        :direction="direction">
      <div class="block">
        <el-input
            type="textarea"
            :rows="2"
            placeholder="更新物流信息"
            v-model="logistics.description">
        </el-input>
        <el-button style="width: 100%;margin-bottom: 20px" type="primary" @click="saveInfo()">保存</el-button>
        <el-divider content-position="left">贝贝物流，一家更快的物流公司</el-divider>
        <el-timeline>
          <el-timeline-item :timestamp="item.updateTime" placement="top" v-for="item in curInfo.info">
            <el-card>
              <h4>{{ item.description }}</h4>
              <p>{{ item.updateTime }}</p>
              <el-button @click="removeInfo(item.id)" type="danger" icon="el-icon-delete" circle></el-button>
            </el-card>
          </el-timeline-item>
        </el-timeline>
      </div>
    </el-drawer>

    <div class="crumbs">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item>
          <i class="el-icon-lx-cascades"></i> 物流管理
        </el-breadcrumb-item>
      </el-breadcrumb>
    </div>

    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="可接订单" name="first">
        <div class="container">
          <el-table
              :data="tableData"
              border
              class="table"
              header-cell-class-name="table-header"
          >
            <el-table-column prop="nickname" label="用户"></el-table-column>
            <el-table-column label="商品图片" align="center">
              <template slot-scope="scope">
                <el-image
                    class="table-td-thumb"
                    :src="scope.row.productCover"
                    :preview-src-list="[scope.row.productCover]"
                ></el-image>
              </template>
            </el-table-column>
            <el-table-column prop="productName" label="商品名称" :show-overflow-tooltip="true"></el-table-column>
            <el-table-column prop="gmtCreate" label="下单时间"></el-table-column>
            <el-table-column label="金额">
              <template slot-scope="scope">
                <span style="color: red">￥ {{ scope.row.totalFee }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="address" label="发货地址"></el-table-column>
            <el-table-column label="发货状态">
              <template slot-scope="scope">
                <el-tag>{{ scope.row.shipState | shipState }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="100" align="center">
              <template slot-scope="scope">
                <el-button
                    v-if="scope.row.status==1 && scope.row.shipState== 0 "
                    type="text"
                    icon="el-icon-position"
                    @click="jiedan(scope.row.id)"
                >接单
                </el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="pagination">
            <el-pagination
                background
                layout="total, prev, pager, next"
                :current-page="pageIndex"
                :page-size="pageSize"
                :total="pageTotal"
                @current-change="handlePageChange"
            ></el-pagination>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="已接订单" name="second">
        <div class="container">
          <el-table
              :data="tableData2"
              border
              class="table"
              header-cell-class-name="table-header"
          >
            <el-table-column prop="nickname" label="用户"></el-table-column>
            <el-table-column label="商品图片" align="center">
              <template slot-scope="scope">
                <el-image
                    class="table-td-thumb"
                    :src="scope.row.productCover"
                    :preview-src-list="[scope.row.productCover]"
                ></el-image>
              </template>
            </el-table-column>
            <el-table-column prop="productName" label="商品名称" :show-overflow-tooltip="true"></el-table-column>
            <el-table-column prop="gmtCreate" label="下单时间"></el-table-column>
            <el-table-column label="金额">
              <template slot-scope="scope">
                <span style="color: red">￥ {{ scope.row.totalFee }}</span>
              </template>
            </el-table-column>
            <el-table-column  label="发货地址">
              <template slot-scope="scope">
                <el-tag>{{scope.row.address.province+scope.row.address.detailAddress}}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="发货状态">
              <template slot-scope="scope">
                <el-tag>{{ scope.row.shipState | shipState }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="100" align="center">
              <template slot-scope="scope">
                <el-button
                    type="text"
                    icon="el-icon-position"
                    @click="drawer = true;queryInfoById(scope.row.id)"
                >更新物流信息
                </el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="pagination">
            <el-pagination
                background
                layout="total, prev, pager, next"
                :current-page="pageIndex2"
                :page-size="pageSize"
                :total="pageTotal2"
                @current-change="handlePageChange2"
            ></el-pagination>
          </div>
        </div>
      </el-tab-pane>
    </el-tabs>


    <el-dialog
        title="填写单号"
        :visible.sync="dialogVisible"
        width="30%">
      <el-input v-model="cur_row.trackNum"></el-input>
      <span slot="footer" class="dialog-footer">
    <el-button type="primary" @click="shipments()">保 存</el-button>
  </span>
    </el-dialog>


  </div>
</template>

<script>
import logistics from '../../api/logistics';

export default {
  name: 'logisticPage',
  data() {
    return {
      logistics: {},
      drawer: false,
      direction: 'rtl',
      activeName: 'first',
      pageIndex2: 1,
      tableData2: [],
      pageTotal2: null,
      conditionSearch: {},
      isDelete: false,
      tableData: [],
      multipleSelection: [],
      delList: [],
      pageTotal: 0,
      idx: -1,
      id: -1,
      pageIndex: 1,
      pageSize: 10,
      dialogVisible: false,
      cur_row: {},
      curInfo: {
        info: [],
        orderNo: ''
      }
    };
  },
  created() {
    //查询可接订单
    this.getData();
    //查询已接订单
    this.ordersReceived();
  },
  methods: {
    reset() {
      this.conditionSearch = {};
      this.getData();
    },
    removeInfo(id){
      logistics.removeInfo(id).then(res => {
        if (res.success) {
          this.$message({
            message: '操作成功',
            type: 'success'
          });
          this.queryInfoById(this.logistics.orderNo);
        }
      });
    },
    saveInfo() {
      this.logistics.orderNo = this.curInfo.orderNo;
      this.logistics.sorting = this.curInfo.info[this.curInfo.info.length - 1].sorting + 1;
      logistics.updateInfo(this.logistics).then(res => {
        if (res.success) {
          this.$message({
            message: '操作成功',
            type: 'success'
          });
          this.queryInfoById( this.logistics.orderNo);
          this.logistics.orderNo = '';
          this.logistics.sorting = null;
        }
      });
    },
    // 获取数据
    getData() {
      logistics.queryAll(this.pageIndex, this.pageSize).then(res => {
        if (res.success) {
          this.pageTotal = res.data.data.total;
          this.tableData = res.data.data.records;
        } else {
          this.$message.error(res.message);
        }
      });
    },
    ordersReceived() {
      logistics.ordersReceived(this.pageIndex2, this.pageSize).then(res => {
        if (res.success) {
          this.pageTotal2 = res.data.data.total;
          this.tableData2 = res.data.data.records;
        } else {
          this.$message.error(res.message);
        }
      });
    },
    // 分页导航
    handlePageChange(val) {
      this.pageIndex = val;
      this.getData();
    },
    handlePageChange2(val) {
      this.pageIndex2 = val;
      this.ordersReceived();
    },
    // 发货
    jiedan(id) {
      this.dialogVisible = false;
      logistics.receptionOrder(id).then(res => {
        if (res.success) {
          this.getData();
        } else {
          this.$message.error(res.message);
        }
      });
    },
    queryInfoById(id) {
      this.curInfo.info = [];
      this.curInfo.orderNo = '';
      logistics.queryInfoById(id).then(res => {
        console.log(res.data.list);
        this.curInfo.info = res.data.list;
        this.curInfo.orderNo = id;
      });
    },
    showDia(index, row) {
      this.dialogVisible = true;
      this.cur_row = row;
    },
    handleClick(tab, event) {
      if (this.activeName === 'first') {
        this.getData();
      } else {
        this.ordersReceived();

      }
    }
  },
  filters: {
    shipState: function(value) {
      if (value == 0) {
        return '未发货';
      } else if (value == 1) {
        return '已发货';
      } else if (value == 2) {
        return '已收货';
      }
    }
  }
};
</script>

<style scoped>
.handle-box {
  margin-bottom: 20px;
}

.handle-input {
  width: 300px;
  display: inline-block;
  margin-left: 10px;
}

.table {
  width: 100%;
  font-size: 14px;
}

.red {
  color: #ff0000;
}

.mr10 {
  margin-right: 10px;
}

.table-td-thumb {
  display: block;
  margin: auto;
  width: 40px;
  height: 40px;
}
</style>
