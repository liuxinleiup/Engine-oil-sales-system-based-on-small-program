<template>
  <div class="container">
    <el-form ref="form" :model="product" label-width="80px">
      <el-row>
        <el-col :span="10">
          <el-form-item style="margin-top: 15px">
            <el-button type="primary" @click="savePro">保存</el-button>
            <el-button>重置</el-button>
          </el-form-item>
          <el-divider></el-divider>
          <el-form-item label="选择分类">
            <el-select v-model="product.categoryId" placeholder="请选择分类">
              <el-option
                  v-for="item in categorys"
                  :label="item.catelogName"
                  :value="item.id">
              </el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="商品名">
            <el-input type="textarea" v-model="product.productName"></el-input>
          </el-form-item>
          <el-form-item label="是否上架">
            <el-switch v-model="product.isputaway"></el-switch>
          </el-form-item>
          <el-form-item label="价格">
            <el-input type="number" v-model="product.price"></el-input>
          </el-form-item>
          <el-form-item label="库存">
            <el-input type="number" v-model="product.stock"></el-input>
          </el-form-item>
          <el-form-item label="销量">
            <el-input type="number" v-model="product.sales"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="10" :offset="2">
          <el-upload
              :action="fileurl"
              list-type="picture-card"
              :file-list="fileList"
              :on-remove="handleRemove"
              :on-success="handleAvatarSuccess">
            <i class="el-icon-plus"></i>
          </el-upload>
        </el-col>
      </el-row>

      <el-divider content-position="left">商品详情</el-divider>
      <!--富文本编辑器组件-->
      <el-row v-loading="quillUpdateImg">
        <quill-editor
            v-model="detailContent"
            ref="myQuillEditor"
            :options="editorOption"
            @change="onEditorChange($event)"
            @ready="onEditorReady($event)"
        ></quill-editor>
      </el-row>


    </el-form>

    <!-- 图片上传组件辅助-->
    <el-upload
        v-show="false"
        class="avatar-uploader"
        :action="fileurl"
        name="file"
        :headers="header"
        :show-file-list="false"
        :on-success="uploadSuccess"
        :on-error="uploadError"
        :before-upload="beforeUpload"
    ></el-upload>


  </div>
</template>

<script>
import areaApi from '../../../api/area';

const toolbarOptions = [
  ["bold", "italic", "underline", "strike"], // toggled buttons
  ["blockquote", "code-block"],

  [{header: 1}, {header: 2}], // custom button values
  [{list: "ordered"}, {list: "bullet"}],
  [{script: "sub"}, {script: "super"}], // superscript/subscript
  [{indent: "-1"}, {indent: "+1"}], // outdent/indent
  [{direction: "rtl"}], // text direction

  [{size: ["small", false, "large", "huge"]}], // custom dropdown
  [{header: [1, 2, 3, 4, 5, 6, false]}],

  [{color: []}, {background: []}], // dropdown with defaults from theme
  [{font: []}],
  [{align: []}],
  ["link", "image", "video"],
  ["clean"] // remove formatting button
];

import {quillEditor} from "vue-quill-editor";
import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import "quill/dist/quill.bubble.css";
import constVal from '../../../api/const';
import productApi from '../../../api/product';

export default {
  name: 'addPro',
  components: {
    quillEditor
  },
  created() {
    var pid = this.$route.query.id;
    if (pid != undefined && pid != '') {
      this.getPro(pid)
      this.isEdit = true;//表示处于编辑状态
    }
    this.fileurl = constVal.FileUploadInterface();
    //获取分类
    this.getCategory();
    //获取分类
    this.getPattern();
    //获取地区
    this.getArea();
    //获取销售属性
    this.getSaleAttr();
  },
  data() {
    return {
      product: {
        isputaway: true,
        cover: '',
        sales: 0,
        images: [],
      },
      isEdit: false,//编辑和新增 状态
      fileurl: '',
      fileList: [],
      options: [],
      patterns: [],
      categorys: [],
      areas: [],
      quillUpdateImg: false, // 根据图片上传状态来确定是否显示loading动画，刚开始是false,不显示
      header: {token: sessionStorage.token}, // 有的图片服务器要求请求头需要有token之类的参数，写在这里
      detailContent: "", // 富文本内容
      editorOption: {
        placeholder: "",
        modules: {
          toolbar: {
            container: toolbarOptions, // 工具栏
            handlers: {
              image: function (value) {
                if (value) {
                  document.querySelector(".avatar-uploader input").click();
                } else {
                  this.quill.format("image", false);
                }
              }
            }
          }
        }
      } // 富文本编辑器配置
    };
  },
  methods: {
    // 上传图片前
    beforeUpload(res, file) {
      // 显示loading动画
      this.quillUpdateImg = true;
    },
    handleRemove(file, fileList) {
      this.product.images.splice(fileList.length, 1);
    },
    getPattern() {
      areaApi.getPatternAll().then(res => {
        this.patterns = res.data.patterns;
      })
    },
    // 上传图片成功
    uploadSuccess(res, file) {
      // res为图片服务器返回的数据
      // 获取富文本组件实例
      let quill = this.$refs.myQuillEditor.quill;
      // 如果上传成功
      if (res.code === 20000 && res.data.url !== null) {
        // 获取光标所在位置
        let length = quill.getSelection().index;
        // 插入图片  res.info为服务器返回的图片地址
        quill.insertEmbed(length, "image", res.data.url);
        // 调整光标到最后
        quill.setSelection(length + 1);
      } else {
        this.$message.error("图片插入失败");
      }
      // loading动画消失
      this.quillUpdateImg = false;
    },
    // 上传图片失败
    uploadError(res, file) {
      // loading动画消失
      this.quillUpdateImg = false;
      this.$message.error("图片插入失败");
    },
    onEditorReady(even) {
    },
    onEditorChange({editor, html, text}) {
      this.detailContent = html;
      this.product.detail = html;
    },
    handleAvatarSuccess(res) {
      this.product.images.push({
        photoUrl: res.data.url,
        spuId: ''
      });
    },
    savePro() {
      if (this.isEdit) {//修改
        productApi.update(this.product).then(res => {
          if (res.success) {
            this.$message.success("修改成功")
          } else {
            this.$message.error(res.message)
          }
        })
      } else {//新增
        productApi.saveProduct(this.product).then(res => {
          if (res.success) {
            this.$message.success("上传成功")
            this.product = {}
            this.detailContent = ''
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    getPro(pid) {
      productApi.getById(pid).then(res => {
        this.product = res.data.spuinfo;
        this.detailContent = this.product.detail
        for (let i = 0; i < this.product.images.length; i++) {
          var item = {
            name: this.product.images[i].id,
            url: this.product.images[i].photoUrl,
          }
          this.fileList.push(item);
        }
      })
    },
    getCategory() {
      productApi.getCategory().then(res => {
        this.categorys = res.data.categorys;
      })
    },
    getArea() {
      productApi.getArea().then(res => {
        this.areas = res.data.areas;
      })
    },
    getSaleAttr() {
      productApi.getSaleAttr().then(res => {
        this.saleAttrList = res.data.saleAttrList;
      })
    }
  }
};
</script>

<style scoped>
button.el-button.editor-btn.el-button--primary.el-button--small {
  float: right;
}

.el-upload--text {
  background-color: #fff;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  width: 360px;
  height: 30px;
  text-align: center;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.avatar-uploader .el-upload:hover {
  border-color: #409EFF;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}

.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>
