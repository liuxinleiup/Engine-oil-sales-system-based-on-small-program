<template>
    <div class="container">
        <div class="handle-box">
            <el-button
                    type="primary"
                    icon="el-icon-delete"
                    class="handle-del mr10"
                    @click="delAllSelection"
            >批量删除</el-button>
            <el-select style="width: 100px" v-model="conditionSearch.isputaway" placeholder="请选择">
                <el-option
                        label="下架"
                        value="false">
                </el-option>
                <el-option
                        label="上架"
                        value="true">
                </el-option>
                <el-option
                        label="全部"
                        value="">
                </el-option>
            </el-select>
            <el-select
                    style="margin-left: 10px"
                    v-model="conditionSearch.categoryId" placeholder="请选择分类">
                <el-option
                        v-for="item in categorys"
                        :label="item.catelogName"
                        :value="item.id">
                </el-option>
            </el-select>
<!--            <el-select-->
<!--                    style="margin-left: 10px;width: 180px"-->
<!--                    v-model="conditionSearch.areaId" placeholder="请选择地区">-->
<!--                <el-option-->
<!--                        v-for="item in areas"-->
<!--                        :label="item.areaName"-->
<!--                        :value="item.id">-->
<!--                </el-option>-->
<!--            </el-select>-->
            <el-input style="width: 170px" v-model="conditionSearch.productName" placeholder="产品名" class="handle-input mr10"></el-input>
            <el-button type="primary" icon="el-icon-search" @click="getProduct()">搜索</el-button>

            <router-link style="margin-left: 10px" :to="{path:'addPro'}">
                <el-button type="primary" icon="el-icon-plus">新增</el-button>
            </router-link>

            <el-button type="primary" icon="el-icon-refresh" @click="reset()" style="margin-left: 10px" >重置</el-button>


        </div>

        <el-table
                :data="tableData"
                border
                class="table"
                ref="multipleTable"
                header-cell-class-name="table-header"
                @selection-change="handleSelectionChange"
        >
            <el-table-column type="selection" width="55" align="center"></el-table-column>
            <el-table-column label="产品图" align="center">
                <template slot-scope="scope">
                    <el-image
                            class="table-td-thumb"
                            :src="scope.row.image"
                            :preview-src-list="[scope.row.image]"
                    ></el-image>
                </template>
            </el-table-column>
            <el-table-column prop="productName" label="产品名"  :show-overflow-tooltip="true"></el-table-column>
            <el-table-column  label="价格">
                <template slot-scope="scope">
                    <span style="color: red">￥ {{scope.row.price}}</span>
                </template>
            </el-table-column>
            <el-table-column prop="createTime" label="上传时间"></el-table-column>
            <el-table-column label="上架">
                <template slot-scope="scope">
                    <div @click="changeState(scope.row)">
                        <el-switch
                                v-model="scope.row.isputaway"
                                active-color="#13ce66"
                                inactive-color="#ff4949">
                        </el-switch>
                    </div>
                </template>
            </el-table-column>
            <el-table-column label="操作" width="180" align="center">
                <template slot-scope="scope">
                    <router-link style="margin-right: 15px" :to="{path:'addPro',query:{id:scope.row.id}}">
                        <el-button type="warning" icon="el-icon-edit" circle>
                        </el-button>
                    </router-link>
                    <el-button type="primary"
                               @click="showDetail(scope.row.detail)"
                               icon="el-icon-view" circle></el-button>
                    <el-button type="danger"
                               @click="handleDelete(scope.$index, scope.row)"
                               icon="el-icon-delete" circle></el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="pagination">
            <el-pagination
                    background
                    layout="total, prev, pager, next"
                    :current-page="pageIndex"
                    :page-size="pageSize"
                    :total="pageTotal"
                    @current-change="handlePageChange"
            ></el-pagination>
        </div>

        <el-dialog
                title="描述"
                :visible.sync="dialogVisible"
                width="80%">
            <span v-html="desc"></span>
            <span slot="footer" class="dialog-footer">
  </span>
        </el-dialog>

    </div>
</template>

<script>
    import productApi from '../../../api/product';


    export default {
        name: 'mall',
        data(){
            return{
                conditionSearch:{},
                tableData: [],
                multipleSelection: [],
                delList: [],
                categorys:[],
                areas:[],
                pageTotal: 0,
                idx: -1,
                id: -1,
                pageIndex: 1,
                pageSize: 10,
                dialogVisible : false,
                desc:''
            }
        },
        created() {
            this.getProduct();
            //获取分类
            this.getCategory();
            //获取地区
            this.getArea();
        },
        methods:{
            getProduct(){
                productApi.getProduct(this.conditionSearch, this.pageIndex, this.pageSize).then(res=>{
                    this.pageTotal = res.data.total;
                    this.tableData = res.data.rows;
                })
            },
            // 分页导航
            handlePageChange(val) {
                this.pageIndex = val;
                this.getProduct();
            },
            // 多选操作
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },
            //改变状态
            changeState(item){
                productApi.update(item).then(res=>{
                    this.getProduct();
                })
            },
            getCategory(){
                productApi.getCategory().then(res=>{
                    this.categorys = res.data.categorys;
                })
            },
            reset() {
                console.log("--------")
                this.conditionSearch = {}
                this.getProduct()
            },
            getArea(){
                productApi.getArea().then(res=>{
                    this.areas = res.data.areas;
                })
            },
            // 删除操作
            handleDelete(index, row) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    productApi.deleteById(row.id).then(res=>{
                        if (res.success){
                            this.$message.success('删除成功');
                            this.tableData.splice(index, 1);
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消操作'
                    });
                });
            },
            //多选
            delAllSelection() {
                const length = this.multipleSelection.length;
                var ids = new Array()
                for (let i = 0; i < length; i++) {
                    ids[i] = this.multipleSelection[i].id;
                }
                productApi.deleteByIds(ids).then(res=>{
                    if (res.success){
                        this.$message.success('删除成功');
                        this.multipleSelection = [];
                        this.getProduct();
                    }else{
                        this.$message.error(res.message);
                    }
                })
            },
            showDetail(des){
                this.dialogVisible =true;
                this.desc = des;
            }
        }

    };
</script>

<style scoped>
    .handle-box {
        margin-bottom: 20px;
    }

    .handle-select {
        width: 120px;
    }

    .handle-input {
        width: 300px;
        display: inline-block;
        margin-left: 10px;
    }
    .table {
        width: 100%;
        font-size: 14px;
    }
    .red {
        color: #ff0000;
    }
    .mr10 {
        margin-right: 10px;
    }
    .table-td-thumb {
        display: block;
        margin: auto;
        width: 40px;
        height: 40px;
    }
</style>
