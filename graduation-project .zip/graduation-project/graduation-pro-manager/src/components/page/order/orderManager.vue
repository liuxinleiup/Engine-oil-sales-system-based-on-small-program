<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-cascades"></i>
                </el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div class="handle-box">
                <el-input v-model="conditionSearch.nickname" style="width: 200px" placeholder="用户名" class="handle-input mr10"></el-input>
                <el-input v-model="conditionSearch.productName" style="width: 200px" placeholder="商品名"

                          class="handle-input mr10"></el-input>
                <el-select v-model="conditionSearch.shipState" placeholder="请选择">
                    <el-option
                            v-for="item in options"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                    </el-option>
                </el-select>
                <el-button type="primary" icon="el-icon-search" @click="getData()">搜索</el-button>
                <el-button type="danger" icon="el-icon-search" @click="reset()">重置</el-button>
            </div>
            <!--
            -->
            <el-table
                    :data="tableData"
                    border
                    class="table"
                    header-cell-class-name="table-header"
            >
                <el-table-column prop="orderNo" label="订单号"></el-table-column>
                <el-table-column prop="nickname" label="用户"></el-table-column>
                <el-table-column label="商品图片" align="center">
                    <template slot-scope="scope">
                        <el-image
                                class="table-td-thumb"
                                :src="scope.row.productCover"
                                :preview-src-list="[scope.row.productCover]"
                        ></el-image>
                    </template>
                </el-table-column>
                <el-table-column prop="productName" label="商品名称" :show-overflow-tooltip="true"></el-table-column>
                <el-table-column prop="gmtCreate" label="下单时间"></el-table-column>
                <el-table-column  label="金额">
                    <template slot-scope="scope">
                        <span style="color: red">￥ {{scope.row.totalFee}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="发货地址">
                  <template slot-scope="scope">
                    <el-tag>{{scope.row.address.province+scope.row.address.detailAddress}}</el-tag>
                  </template>
                </el-table-column>
                <el-table-column  label="发货状态">
                    <template slot-scope="scope">
                        <el-tag>{{scope.row.shipState | shipState}}</el-tag>
                    </template>
                </el-table-column>
                <el-table-column  label="订单状态">
                    <template slot-scope="scope">
                        <el-tag>{{scope.row.status | status}}</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="操作" width="100" align="center">
                    <template slot-scope="scope">
                        <el-button
                                type="text"
                                icon="el-icon-delete"
                                class="red"
                                @click="handleDelete(scope.$index, scope.row)"
                        >删除</el-button>
                        <el-button
                                v-if="scope.row.status==1 && scope.row.shipState== 0 "
                                type="text"
                                icon="el-icon-position"
                                @click="showDia(scope.$index, scope.row)"
                        >点击发货</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div class="pagination">
                <el-pagination
                        background
                        layout="total, prev, pager, next"
                        :current-page="pageIndex"
                        :page-size="pageSize"
                        :total="pageTotal"
                        @current-change="handlePageChange"
                ></el-pagination>
            </div>
        </div>


        <el-dialog
                title="填写单号"
                :visible.sync="dialogVisible"
                width="30%"
                :before-close="handleClose">
            <el-input v-model="cur_row.trackNum"></el-input>
            <span slot="footer" class="dialog-footer">
    <el-button type="primary" @click="shipments()">保 存</el-button>
  </span>
        </el-dialog>


    </div>
</template>

<script>
    import orderApi from '../../../api/order';

    export default {
        name: 'orderManager',
        data() {
            return {
                options: [{
                    value: 0,
                    label: '未发货'
                },{
                    value: 1,
                    label: '已发货'
                },{
                    value: 2,
                    label: '已收货'
                }],
                conditionSearch:{
                },
                isDelete:false,
                tableData: [],
                multipleSelection: [],
                delList: [],
                pageTotal: 0,
                idx: -1,
                id: -1,
                pageIndex: 1,
                pageSize: 10,
                dialogVisible: false,
                cur_row:{}
            };
        },
        created() {
            this.getData();
        },
        methods: {
            reset(){
              this.conditionSearch = {};
              this.getData();
            },
            // 获取数据
            getData() {
                orderApi.conditionSearch(this.conditionSearch, this.pageIndex, this.pageSize).then( res=>{
                    if (res.success){
                        this.pageTotal = res.data.total;
                        this.tableData = res.data.rows;
                    }else{
                        this.$message.error(res.message);
                    }
                })
            },
            // 删除操作
            handleDelete(index, row) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    orderApi.deleteById(row.id).then(res=>{
                        if (res.success){
                            this.$message.success('删除成功');
                            this.tableData.splice(index, 1);
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消操作'
                    });
                });
            },
            // 分页导航
            handlePageChange(val) {
                this.pageIndex = val;
                this.getData();
            },
            // 发货
            shipments() {
                this.dialogVisible = false
                orderApi.shipments(this.cur_row.id, this.cur_row.trackNum).then(res=>{
                    if (res.success){
                        this.$message.success('修改成功');
                        this.cur_row = {}
                        this.getData();
                    }else{
                        this.$message.error(res.message);
                    }
                })
            },
            showDia(index, row){
                this.dialogVisible = true;
                this.cur_row = row;
            }
        },
        filters: {
            shipState: function (value) {
               if (value == 0){
                   return "未发货"
               }else if (value == 1){
                   return "已发货"
               }else if (value == 2){
                   return "已收货"
               }
            },
            status: function (value) {
                return value==0?'未支付':'已支付'
            },
        },
    };
</script>

<style scoped>
    .handle-box {
        margin-bottom: 20px;
    }

    .handle-input {
        width: 300px;
        display: inline-block;
        margin-left: 10px;
    }
    .table {
        width: 100%;
        font-size: 14px;
    }
    .red {
        color: #ff0000;
    }
    .mr10 {
        margin-right: 10px;
    }
    .table-td-thumb {
        display: block;
        margin: auto;
        width: 40px;
        height: 40px;
    }
</style>
