<template>
    <div>
        <el-row>
            <!--用户信息-->
            <el-col :span="5" style="height: 100%">
                <el-row>
                    <el-col>
                        <div class="grid-content bg-purple">
                            <el-card class="box-card" >
                                <div slot="header" class="clearfix">
                                    <span>个人信息</span>
                                </div>
                                <el-image
                                        style="width: 100px; height: 100px;border-radius: 55px;margin-bottom: 15px;margin-left: 25%"
                                        :src="user.avatar"
                                        fit="contain"></el-image>
                                <div class=" text item">
                                    <p>用户名：{{user.nickname}}</p>
                                    <p>年龄：{{user.age}}</p>
                                    <p>性别：{{user.sex | sex}}</p>
                                    <p>身份：<el-tag type="info">{{user.identify | identify}}</el-tag>
                                        <el-tag v-if="user.teaCount=='0'?true : false" style="margin-left: 5px;cursor:pointer;" class="hover" type="danger"
                                                @click="changIdentity()">{{identityText}}
                                        </el-tag></p>
                                    <p>电话：{{user.mobile}}</p>
                                    <p>注册时间：{{user.gmtCreate}}</p>
                                    <p>点赞量：<el-tag type="danger">{{user.thumb}}</el-tag></p>
                                    <p>已有教练：{{user.teaCount}}人</p>
                                    <p >
                                        <el-button v-if="user.teaCount != 0 ?true: false"
                                                   @click="lookTeaInfo()"
                                                   style="width: 100%;margin-top: 15px">查看他的教练</el-button>

                                    </p>
                                </div>
                            </el-card>
                        </div>
                    </el-col>
                    <!--教练信息-->
                    <el-col style="margin-top: 10px"  >
                        <div class="grid-content bg-purple" >
                            <el-card class="box-card" v-show="lookTrue" v-for="item in teas" style="margin-bottom: 10px">
                                <div class=" text item">
                                    <el-image
                                            style="width: 50px; height: 50px;border-radius: 55px;margin-bottom: 15px;margin-left: 35%"
                                            :src="item.avatar"
                                            fit="contain"></el-image>
                                    <p>用户名：{{item.nickname}}</p>
                                    <p>性别：{{item.sex | sex}}</p>
                                    <p>电话：{{item.mobile}}</p>
                                    <p>点赞量：{{item.thumb}}</p>
                                </div>
                            </el-card>
                        </div>
                    </el-col>
                </el-row>
            </el-col>

            <!--成绩分析-->
            <el-col :span="18" style="margin-left: 15px"><div class="grid-content bg-purple-light">
                <el-card class="box-card" >
                    <div slot="header" class="clearfix">
                        <span>成绩分析</span>
                        <el-select  @change="changName" v-model="cur_step" style="margin-left:15px;width: 40%" placeholder="请选择阶数">
                            <el-option
                                    v-for="item in rubiks"
                                    :key="item.id"
                                    :label="item.name"
                                    :value="item.id">
                            </el-option>
                        </el-select>
                        <el-button style="margin-left: 15px" @click="getAchieveAnalyze()" type="primary" plain>查询</el-button>
                    </div>

                    <div>
                        <span v-if="isData">{{hint}}</span>
                        <el-row v-if="!isData">
                            <el-col :span="11">
                                <el-table
                                        border
                                        :data="achievement.tablesData"
                                        style="width: 100%">
                                    <el-table-column
                                            prop="tagName"
                                            width="93"
                                            label=""
                                    >
                                    </el-table-column>
                                    <el-table-column
                                            prop="recent"
                                            width="120"
                                            label="最近一次">
                                    </el-table-column>
                                    <el-table-column
                                            prop="best"
                                            width="120"
                                            label="最优成绩"
                                    >
                                    </el-table-column>
                                    <el-table-column
                                            prop="worst"
                                            label="最差成绩"
                                            width="120">
                                    </el-table-column>
                                </el-table>
                            </el-col>
                            <el-col :span="6" style="margin-left: 15px">
                                <el-card shadow="never" class="box-card">
                                    <p>练习总次数：<el-tag type="success">{{achievement.count}} 次</el-tag></p>
                                    <p>排名：<el-tag >第 {{achievement.rank}} 名</el-tag></p>
                                    <p>超越人数：<el-tag type="warning">{{achievement.surpass}} 人</el-tag></p>
                                    <p>是否新手：<el-tag type="warning">{{achievement.isnew | isnew}} </el-tag></p>
                                    <p>成绩是否认证：<el-tag type="danger">{{achievement.isauthentication | isauthentication}}</el-tag></p>
                                    <router-link v-if="achievement.isauthentication == '0' " :to="{path:'approve', query:{id:user.id+'_'+cur_step}}"><el-button size="small">点击认证({{cur_step_name}})</el-button></router-link>
                                    <router-link v-else tag="div"  :to="{path:'creDeatil', query:{uid:user.id,rid:cur_step}}">
                                        <el-button  type="primary">查看认证</el-button>
                                    </router-link>

                                </el-card>
                            </el-col>
                            <el-col :span="6" style="margin-left: 15px">
                                <el-card  shadow="never" class="box-card">
                                    <p>练习总时间：<el-tag type="success">{{achievement.counttime}}</el-tag></p>
                                    <p>dnf：<el-tag >共{{achievement.dnfcount}}次</el-tag></p>
                                    <p>还原次数：<el-tag type="warning">{{achievement.dnfcount}} / {{achievement.count}}</el-tag></p>
                                </el-card>
                            </el-col>
                        </el-row>
                    </div>



                </el-card>


                <el-card v-if="!isData" class="box-card" style="margin-top: 15px">
                    <schart ref="bar" class="schart" canvasId="bar" :options="options"></schart>
                </el-card>


            </div></el-col>

        </el-row>
    </div>
</template>

<script>
    import userApi from '../../../api/user';
    import rubikApi from '../../../api/rubik';
    import achieveApi from '../../../api/stepAchieve';
    import teacherApi from '../../../api/teacher';
    import Schart from 'vue-schart';
    export default {
        name: 'userDetail',
        created() {
            var uid = this.$route.query.id;
            this.getData(uid);
        },
        data(){
            return{
                user:{},
                rubiks: [],
                cur_step: '',//当前阶数
                cur_step_name: '',//当前阶数
                hint:'',
                isData:false,//是否有数据
                achievement:{},
                lookTrue:false,
                options: {
                    type: 'line',
                    labels: [],
                    title: {
                        text: '最近50次练习记录'
                    },
                    showValue:false,
                    xRorate: 70,
                    datasets: [
                        {
                            label: '单次',
                            data: []
                        },
                        {
                            label: 'ao5',
                            data: []
                        },
                        {
                            label: 'ao12',
                            data: []
                        },
                        {
                            label: 'ao50',
                            data: []
                        },
                        {
                            label: 'ao100',
                            data: []
                        }
                    ]
                },
                identityText:'',
                teas:[]
            }
        },
        methods:{
            //获取用户信息
            getData(uid){
                userApi.getById(uid).then( res=>{
                    this.user = res.data.user
                    if (this.user.identify == '1'){
                        this.identityText = '设为教练'
                    }else{
                        this.identityText = '设为学员/用户'
                    }
                    this.getRubik();
                })
            },
            //获取魔方
            getRubik(){
                rubikApi.getAll().then( res=>{
                    this.rubiks = res.data.data;
                    this.cur_step = this.rubiks[0].id;
                    this.cur_step_name = this.rubiks[0].name;
                    this.getAchieveAnalyze();
                })
            },
            //获取成绩
            getAchieveAnalyze(){
                achieveApi.getAchieveAnalyze(this.user.id, this.cur_step).then( res=>{
                    if (!res.success){
                        this.isData = true;
                        this.hint = res.message
                    }else{
                        this.isData = false;
                        this.achievement = res.data.data

                        for (var i = 1; i <= 50; i++){
                            this.options.labels[i-1] = i+''
                        }

                        //向图表添加数据
                        this.options.datasets[0].data = res.data.data.charts.single
                        this.options.datasets[1].data = res.data.data.charts.ao5
                        this.options.datasets[2].data = res.data.data.charts.ao12
                        this.options.datasets[3].data = res.data.data.charts.ao50
                        this.options.datasets[4].data = res.data.data.charts.ao100
                    }
                })
            },
            //改变身份
            changIdentity(){
                this.$confirm('此操作将改变用户身份和权限，是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    //判断用户当前权限发送不同请求
                    if (this.user.identify === '1'){//设为教练
                        teacherApi.becometea(this.user.id).then(res=>{
                            if (res.success){
                                this.$message.success("修改成功！");
                                this.user.identify = '2'
                                this.identityText = '设为学员/用户'
                            }else{
                                this.$message.error(res.message);
                            }
                        })
                    }else{//设为学员
                        teacherApi.removeidentity(this.user.id).then(res=>{
                            if (res.success){
                                this.$message.success("修改成功！");
                                this.user.identify = '1'
                                this.identityText = '设为教练'
                            }else{
                                this.$message.error(res.message);
                            }
                        })
                    }
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消操作'
                    });
                });
            },
            //查看教练信息
            lookTeaInfo(){
                this.lookTrue = true;
                teacherApi.lookTeaInfo(this.user.id).then( res=>{
                    this.teas = res.data.info;
                });
            },
            changName(){
                for (let i = 0; i < this.rubiks.length; i++){
                    if (this.rubiks[i].id === this.cur_step){
                        this.cur_step_name = this.rubiks[i].name
                    }
                }
            }

        },
        filters: {
            identify: function (value) {
                return value=='1'?'学员/用户':'教练'
            },
            sex: function (value) {
                return value=='1'?'女':'男'
            },
            isnew: function (value) {
                return value=='0'?'否':'是'
            },
            isauthentication: function (value) {
                return value=='0'?'否':'是'
            }
        },
        components: {
            Schart
        },

    };
</script>

<style scoped>
    .hover:hover{
        background: #ff6d6b;
        color: #faf8ff;
    }
    .box-card {
        width: 100%;
    }
    .text {
        font-size: 14px;
    }
    p {
        margin-bottom: 15px;
    }
    .clearfix:before,
    .clearfix:after {
        display: table;
        content: "";
    }
    .clearfix:after {
        clear: both
    }
    .schart {
        width: 100%;
        height: 300px;
    }
</style>
