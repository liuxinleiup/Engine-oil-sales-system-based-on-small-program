<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-cascades"></i> 用户管理
                </el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div class="handle-box">
                <el-button
                        :loading="isDelete"
                        type="primary"
                        icon="el-icon-delete"
                        class="handle-del mr10"
                        @click="delAllSelection"
                >批量删除</el-button>

                <el-input v-model="conditionSearch.nickname" placeholder="用户名" class="handle-input mr10"></el-input>
                <el-button type="primary" icon="el-icon-search" @click="getData()">搜索</el-button>
            </div>
            <el-table
                    :data="tableData"
                    border
                    class="table"
                    ref="multipleTable"
                    header-cell-class-name="table-header"
                    @selection-change="handleSelectionChange"
            >
                <el-table-column type="selection" width="55" align="center"></el-table-column>
                <el-table-column label="头像(查看大图)" align="center">
                    <template slot-scope="scope">
                        <el-image
                                class="table-td-thumb"
                                :src="scope.row.avatar"
                                :preview-src-list="[scope.row.avatar]"
                        ></el-image>
                    </template>
                </el-table-column>
                <el-table-column prop="nickname" label="用户名"></el-table-column>
                <el-table-column prop="mobile" label="电话"></el-table-column>
                <el-table-column prop="age" label="年龄"></el-table-column>
                <el-table-column label="性别" align="center">
                <template slot-scope="scope">
                    {{scope.row.sex | sex }}
                </template>
            </el-table-column>
                <el-table-column prop="gmtCreate" label="注册时间"></el-table-column>
                <el-table-column label="操作" width="180" align="center">
                    <template slot-scope="scope">
                        <el-button
                                type="text"
                                icon="el-icon-delete"
                                class="red"
                                @click="handleDelete(scope.$index, scope.row)"
                        >删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div class="pagination">
                <el-pagination
                        background
                        layout="total, prev, pager, next"
                        :current-page="pageIndex"
                        :page-size="pageSize"
                        :total="pageTotal"
                        @current-change="handlePageChange"
                ></el-pagination>
            </div>
        </div>

    </div>
</template>

<script>
    import userApi from '../../../api/user';

    export default {
        name: 'userManager',
        data() {
            return {
                conditionSearch:{
                    identify:'',
                },
                isDelete:false,
                tableData: [],
                multipleSelection: [],
                delList: [],
                pageTotal: 0,
                idx: -1,
                id: -1,
                pageIndex: 1,
                pageSize: 10
            };
        },
        created() {
            this.getData();
        },
        methods: {
            // 获取数据
            getData() {
                userApi.conditionSearch(this.conditionSearch, this.pageIndex, this.pageSize).then( res=>{
                    if (res.success){
                        this.pageTotal = res.data.total;
                        this.tableData = res.data.rows;
                    }else{
                        this.$message.error(res.message);
                    }
                })
            },
            // 删除操作
            handleDelete(index, row) {
                this.$confirm('确定要删除吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    userApi.deleteById(row.id).then(res=>{
                        if (res.success){
                            this.$message.success('删除成功');
                            this.tableData.splice(index, 1);
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消操作'
                    });
                });
            },
            // 多选操作
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },
            delAllSelection() {
                this.isDelete = true;
                const length = this.multipleSelection.length;
                var ids = new Array()
                for (let i = 0; i < length; i++) {
                    ids[i] = this.multipleSelection[i].id;
                }
                userApi.deleteByIds(ids).then(res=>{
                    if (res.success){
                        this.$message.success('删除成功');
                        this.multipleSelection = [];
                        this.getData();
                    }else{
                        this.$message.error(res.message);
                    }
                    this.isDelete = false;
                })
            },
            // 分页导航
            handlePageChange(val) {
                this.pageIndex = val;
                this.getData();
            }
        },
        filters: {
            identify: function (value) {
                return value=='1'?'学员/用户':'教练'
            },
            sex: function (value) {
                return value=='1'?'女':'男'
            },
        },
    };
</script>

<style scoped>
    .handle-box {
        margin-bottom: 20px;
    }

    .handle-select {
        width: 120px;
    }

    .handle-input {
        width: 300px;
        display: inline-block;
        margin-left: 10px;
    }
    .table {
        width: 100%;
        font-size: 14px;
    }
    .red {
        color: #ff0000;
    }
    .mr10 {
        margin-right: 10px;
    }
    .table-td-thumb {
        display: block;
        margin: auto;
        width: 40px;
        height: 40px;
    }
</style>
