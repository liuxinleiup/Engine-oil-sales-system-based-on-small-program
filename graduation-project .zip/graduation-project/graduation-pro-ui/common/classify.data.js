export default [{
	"name": "女装",
	"foods": [{
			"name": "A字裙",
			"key": "A字裙",
			"icon": "https://cdn.uviewui.com/uview/common/classify/1/1.jpg",
			"cat": 10
		},
		{
			"name": "T恤",
			"key": "T恤",
			"icon": "https://cdn.uviewui.com/uview/common/classify/1/2.jpg",
			"cat": 10
		}
	]
}]
