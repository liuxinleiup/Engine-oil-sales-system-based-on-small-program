/**
 *  baseUrl : api调用服务器域名
 */
let baseUrl = "http://localhost:8888/";
// 下面这个判断是判断环境切换请求的网络地址，不需要的可以删除
if (process.env.NODE_ENV === "development") {
  baseUrl = "http://localhost:8888/";	
}