<template>
	<view style="padding: 50rpx;">
		<u-time-line>
			<u-time-line-item nodeTop="2" v-for="item in curInfo">
				<!-- 此处自定义了左边内容，用一个图标替代 -->
				<template v-slot:node>
					<view class="u-node" style="background: #19be6b;">
						<!-- 此处为uView的icon组件 -->
						<u-icon name="pushpin-fill" color="#fff" :size="24"></u-icon>
					</view>
				</template>
				<template v-slot:content>
					<view>
						<view class="u-order-desc">
							{{item.description}}
						</view>
						<view class="u-order-time">{{item.updateTime}}</view>
					</view>
				</template>
			</u-time-line-item>
			
		</u-time-line>
	</view>
</template>

<script>
	import apis from "@/pages/api/servixe"
	export default {
		onLoad(option) {
			this.getData(option.id);
		},
		data() {
			return {
curInfo:[],
			}
		},
		methods: {
			getData(id) {
				apis.queryInfoById(id).then(res => {
					console.log(res.data.list);
					this.curInfo = res.data.list;
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.u-node {
		width: 44rpx;
		height: 44rpx;
		border-radius: 100rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background: #d0d0d0;
	}

	.u-order-title {
		color: #333333;
		font-weight: bold;
		font-size: 32rpx;
	}

	.u-order-desc {
		color: rgb(150, 150, 150);
		font-size: 28rpx;
		margin-bottom: 6rpx;
	}

	.u-order-time {
		color: rgb(200, 200, 200);
		font-size: 26rpx;
	}
</style>
