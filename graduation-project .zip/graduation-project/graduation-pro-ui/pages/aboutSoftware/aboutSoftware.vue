<template>
	<view style="background-color: #fff;">
		<view style="padding: 15px 35px;">
			<u-time-line>
				<u-time-line-item nodeTop="4">
					<!-- 此处自定义了左边内容，用一个图标替代 -->
					<template v-slot:node>
						<view class="u-node" style="background: #19be6b;">
							<!-- 此处为uView的icon组件 -->
							<u-icon name="pushpin-fill" color="#fff" :size="24"></u-icon>
						</view>
					</template>
					<template v-slot:content>
						<view>
							<view class="u-order-title">结束</view>
							<view class="u-order-desc">测试结束，并修复bug，项目编写完毕</view>
							<view class="u-order-time">2022-4-10 12:12</view>
						</view>
					</template>
				</u-time-line-item>
				<u-time-line-item nodeTop="2">
					<!-- 此处自定义了左边内容，用一个图标替代 -->
					<template v-slot:node>
						<view class="u-node" style="background: #19be6b;">
							<!-- 此处为uView的icon组件 -->
							<u-icon name="pushpin-fill" color="#fff" :size="24"></u-icon>
						</view>
					</template>
					<template v-slot:content>
						<view>
							<view class="u-order-title">测试</view>
							<view class="u-order-desc">前后台整合完毕，项目开始进入测试阶段并逐渐完善</view>
							<view class="u-order-time">2022-4-06 12:12</view>
						</view>
					</template>
				</u-time-line-item>
				<u-time-line-item>
					<!-- 此处没有自定义左边的内容，会默认显示一个点 -->
					<template v-slot:content>
						<view>
							<view class="u-order-desc">项目平台开始逐步成形，前后台逐步进行开发</view>
							<view class="u-order-time">2022-2-06</view>
						</view>
					</template>
				</u-time-line-item>
				<u-time-line-item>
					<template v-slot:node>
						<view class="u-node" style="background: #19be6b;">
							<!-- 此处为uView的icon组件 -->
							<u-icon name="pushpin-fill" color="#fff" :size="24"></u-icon>
						</view>
					</template>
					<!-- 此处没有自定义左边的内容，会默认显示一个点 -->
					<template v-slot:content>
						<view>
							<view class="u-order-title">初创</view>
							<view class="u-order-desc">2022年1月正式开始搭建项目</view>
							<view class="u-order-time">2022-1-10 22:30</view>
						</view>
					</template>
				</u-time-line-item>
			</u-time-line>
		</view>
	</view>
</template>

<style lang="scss" scoped>
	page {
		padding-top: 20px;
		background-color: #FFFFFF;
	}

	.u-node {
		width: 44rpx;
		height: 44rpx;
		border-radius: 100rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background: #d0d0d0;
	}

	.u-order-title {
		color: #333333;
		font-weight: bold;
		font-size: 32rpx;
	}

	.u-order-desc {
		color: rgb(150, 150, 150);
		font-size: 28rpx;
		margin-bottom: 6rpx;
	}

	.u-order-time {
		color: rgb(200, 200, 200);
		font-size: 26rpx;
	}
</style>
