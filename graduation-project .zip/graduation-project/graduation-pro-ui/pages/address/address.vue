<template>
	<view>
		<view class="item  bg-white margin-bottom-sm" v-for="(res, index) in siteList" :key="res.id" >
			<view class="top">
				<view class="name">{{ res.name }}</view>
				<view class="phone">{{ res.mobile }}</view>
				<u-tag style="margin-left: 20rpx;" text="默认" mode="light" type="success" v-if="res.isDefault" />
			</view>
			<u-switch color="red" active-color="red" style="margin-top: 15rpx;float: right;" 
			@change="changDefault(res.isDefault, res.id)"
			v-model="res.isDefault"></u-switch>
			<view class="bottom">
				{{res.province}}{{res.detailAddress}}
				<u-icon @click="deleteById(res.id)" name="trash-fill" :size="40" color="#999999"></u-icon>
			</view>
		</view>
		<view class="addSite" @click="toAddSite">
			<view class="add">
				<u-icon name="plus" color="#ffffff" class="icon" :size="30"></u-icon>新建收货地址
			</view>
		</view>
	</view>
</template>

<script>
	import apis from "@/pages/api/servixe"
export default {
	data() {
		return {
			siteList: [],
			nickname:''
		};
	},
	onLoad() {
		this.nickname = uni.getStorageSync("nickname")
		this.getData();
	},
	onShow(){
		this.getData();
	},
	methods: {
		getData() {
			apis.getAddress(uni.getStorageSync("uid")).then(res=>{
				this.siteList = res.data.address
				console.log(this.siteList)
			})
		},
		toAddSite(){
			uni.redirectTo({
			    url: '/pages/address/addSite'
			});
		},
		//改变默认
		changDefault(isDefault, aid){
			apis.setDefualt(aid).then(res=>{
				this.getData();
			})
			//从新请求数据
		},
		deleteById(aid){
			//删除地址
			apis.deletAddress(aid).then(res=>{
				this.getData();
			})
		}
	}
};
</script>

<style lang="scss" scoped>
.item {
	padding: 40rpx 20rpx;
	.top {
		display: flex;
		font-weight: bold;
		font-size: 34rpx;
		.phone {
			margin-left: 60rpx;
		}
		.tag {
			display: flex;
			font-weight: normal;
			align-items: center;
			text {
				display: block;
				width: 60rpx;
				height: 34rpx;
				line-height: 34rpx;
				color: #ffffff;
				font-size: 20rpx;
				border-radius: 6rpx;
				text-align: center;
				margin-left: 30rpx;
				background-color:rgb(49, 145, 253);
			}
			.red{
				background-color:red
			}
		}
	}
	.bottom {
		display: flex;
		margin-top: 20rpx;
		font-size: 28rpx;
		justify-content: space-between;
		color: #999999;
	}
}
.addSite {
	display: flex;
	justify-content: space-around;
	width: 600rpx;
	line-height: 100rpx;
	position: absolute;
	bottom: 30rpx;
	left: 80rpx;
	background-color: red;
	border-radius: 60rpx;
	font-size: 30rpx;
	.add{
		display: flex;
		align-items: center;
		color: #ffffff;
		.icon{
			margin-right: 10rpx;
		}
	}
}
</style>
