/**
 *  baseUrl : api调用服务器域名
 */
export let baseUrl = "http://localhost:8888/costume/";
