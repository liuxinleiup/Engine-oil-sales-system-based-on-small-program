//这里我只是布置了需要用到的，如果要添加别的方法，请随意
import { baseUrl } from '@/pages/api/env'
export const request = (prams) => {
	return new Promise((resolve, reject) => {
		let url = baseUrl + prams.url;
		return uni.request({
			url: url,
			data: prams.data,
			method:prams.method,
			dataType: 'json',
			success: (res) => {
				resolve(res.data);
			},
			fail: (err) => {
				reject(err);
			},
			complete: () => {
			}
		});
	})
}

