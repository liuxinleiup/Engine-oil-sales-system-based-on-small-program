import { request } from '@/pages/api/request'

export default {
	queryInfoById(id){
		 return request({
		            url: `logistics-info/queryInfoById/${id}`,
		            method: 'get',
		        });
	},
	//查询分类
	getClassfiyAll() {
		return request({
			url: `category`,
			method: 'get'
		});
	},
	//删除订单
	deleteOrderById(id) {
		return request({
			url: `t-order/${id}`,
			method: 'delete'
		});
	},
	//修改userInfo
	updateUserInfo(user) {
		return request({
			url: `user/updateinfo`,
			method: 'put',
			data:user
		});
	},
	//查询banner
	getBanner(){
		return request({
			url: `banner/getAllBanner`,
			method: 'get'
		});
	},
	//查询评论
	queryComment(fid){
		return request({
			url: `comment/getcomment/${fid}/1/100000`,
			method: 'get'
		});
	},
	findUserById(uid){
		return request({
			url: `user/${uid}`,
			method: 'get'
		});
	},
	//随机查询
	getRandomPro() {
		return request({
			url: `spu-info/random`,
			method: 'get'
		});
	},
	//随机查询
	recommendspu() {
		return request({
			url: `spu-info/recommendspu`,
			method: 'get'
		});
	},
	//排序
	classfiyQuery(type, page, size) {
		return request({
			url: `spu-info/sort/${type}/${page}/${size}`,
			method: 'get'
		});
	},
	//条件分页查询
	conditionSearch(spuInfo, page, size){
		return request({
			url: `spu-info/${page}/${size}`,
			method: 'post',
			data:spuInfo
		});
	},
	//条件分页查询
	findById(fid){
		return request({
			url: `spu-info/${fid}`,
			method: 'get'
		});
	},
	//查询所有数据
	getAllByClassfiy(){
		return request({
			url: `spu-info/getAllByClassfiy`,
			method: 'get'
		});
	},
	//登陆
	login(user){
		return request({
			url: `user/wx/login`,
			method: 'post',
			data:user
		});
	},
	//获取所有地址
	getAddress(uid){
		return request({
			url: `address/getAll/${uid}`,
			method: 'get'
		});
	},
	//设置默认地址
	setDefualt(aid){
		return request({
			url: `address/setDefualt/${aid}`,
			method: 'put'
		});
	},
	//获取默认地址
	getDefaultAddress(uid){
		return request({
			url: `address/${uid}`,
			method: 'get'
		});
	},
	//保存地址
	saveAddress(address){
		return request({
			url: `address/add`,
			method: 'post',
			data:address
		});
	},
	//改变默认
	//删除地址
	deletAddress(aid){
		return request({
			url: `address/${aid}`,
			method: 'delete',
		});
	},
	//创建订单
	creatOrder(spuid, userid, aid){
		return request({
			url: `t-order/createOrder/${spuid}/${userid}/${aid}`,
			method: 'post'
		});
	},
	//批量创建订单
	batchCreateOrders(orders){
		return request({
			url: `t-order/batchCreateOrders`,
			method: 'post',
			data:orders
		});
	},
	//查询订单
	getOrderByNo(orderId){
		return request({
			url: `t-order/getOrderInfo/${orderId}`,
			method: 'get',
		});
	},
	//批量查询订单
	getBatchOrder(nos){
		return request({
			url: `t-order/getBatchOrder`,
			method: 'post',
			data:nos
		});
	},
	//根据状态查询订单
	queryByStatus(uid, status){
		return request({
			url: `order/queryByStatus/${uid}/${status}`,
			method: 'get',
		});
	},
	//根据状态查询订单
	alredyFinish(uid){
		return request({
			url: `t-order/alredyFinish/${uid}`,
			method: 'get',
		});
	},
	//待支付
	penOrder(uid){
		return request({
			url: `t-order/penOrder/${uid}`,
			method: 'get',
		});
	},
	//待发货
	delivered(uid){
		return request({
			url: `t-order/delivered/${uid}`,
			method: 'get',
		});
	},
	//待收货
	received(uid){
		return request({
			url: `t-order/received/${uid}`,
			method: 'get',
		});
	},
	//待评价
	comment(uid){
		return request({
			url: `t-order/comment/${uid}`,
			method: 'get',
		});
	},
	//支付
	pay(no,couponid){
		return request({
			url: `t-order/pay/${no}/${couponid}`,
			method: 'post',
		});
	},
	//收货
	delivery(orderNo){
		return request({
			url: `t-order/receipt/${orderNo}`,
			method: 'get',
		});
	},
	//评论
	saveComment(comment){
		return request({
			url: `comment`,
			method: 'post',
			data:comment
		});
	},
	//保存到购物车
	saveCart(uid, spuid){
		return request({
			url: `cart/saveCart/${uid}/${spuid}`,
			method: 'get'
		});
	},
	//获取购物车
	getCart(uid){
		return request({
			url: `cart/queryCart/${uid}`,
			method: 'get',
		});
	},
	//获取购物车
	removeCart(id){
		return request({
			url: `cart/deleteCart/${id}`,
			method: 'delete',
		});
	},
	//删除分类
	removeClassfiy(id){
		return request({
			url: `classfiy/${id}`,
			method: 'delete',
		});
	},
	//保存分类
	saveClassfiy(classfiy){
		return request({
			url: `classfiy`,
			method: 'post',
			data:classfiy
		});
	},
	//保存商品
	savefood(food,state){
		return request({
			url: `food/savefood/${state}`,
			method: 'post',
			data:food
		});
	},
	//保存商品
	deleteFood(id){
		return request({
			url: `food/deleteById/${id}`,
			method: 'delete'
		});
	},
	//获取用户
	getUsers(page, size){
		return request({
			url: `user/getAll/${page}/${size}`,
			method: 'get'
		});
	},
	//删除用户
	deleteUser(uid){
		return request({
			url: `user/deleteUser/${uid}`,
			method: 'delete'
		});
	},
	//查询可抢订单
	canGrabOrder(){
		return request({
			url: `order/canGrabOrder`,
			method: 'get'
		});
	},
	//查询可抢订单
	qiangdan(uid, no){
		return request({
			url: `order/grabvOrder/${uid}/${no}`,
			method: 'get'
		});
	},
	//查询可抢订单
	queryHistoryOrder(uid, state){
		return request({
			url: `order/queryHistoryOrder/${uid}/${state}`,
			method: 'get'
		});
	},
	//查询可抢订单
	deleteByMan(no){
		return request({
			url: `order/deleyeByMan/${no}`,
			method: 'delete'
		});
	},
	//删除用户
	deleyeByUser(no){
		return request({
			url: `order/deleyeByUser/${no}`,
			method: 'delete'
		});
	},
	//
	changeIdentify(user, state){
		return request({
			url: `user/changeIdentify/${state}`,
			method: 'put',
			data:user
		});
	},
	//添加到推荐
	addRecommend(id){
		return request({
			url: `food/addRecommend/${id}`,
			method: 'get'
		});
	},
	//查询推荐
	getReFood(page, size){
		return request({
			url: `food/queryRecommendFood/${page}/${size}`,
			method: 'get'
		});
	},
	//查询推荐
	cancelRed(id){
		return request({
			url: `food/cancelRed/${id}`,
			method: 'delete'
		});
	},
	//查询推荐
	regsiterUser(user){
		return request({
			url: `user/register`,
			method: 'post',
			data:user
		});
	},
	//清除购物车
	clearCart(uid){
		return request({
			url: `cart/clear/${uid}`,
			method: 'delete'
		});
	},
	//查询优惠券
	getCoupons(uid){
		return request({
			url: `coupon/conditionSearch/${uid}`,
			method: 'post'
		});
	},
	//条件查询优惠券
	conditionCoupon(coupon, page, size){
		return request({
			url: `coupon/conditionSearch/${page}/${size}`,
			method: 'post',
			data:coupon
		});
	},
	  //查询该商品下的优惠券
	getCouponBySpuid(spuid){
		return request({
			url: `coupon/getCouponBySpuid/${spuid}`,
			method: 'post',
		});
	},
	//领取优惠券
	getCoupon(relation){
		return request({
			url: `coupon/getCoupon`,
			method: 'post',
			data:relation
		});
	},
	//查询已领取
	getAllCoupon(uid){
		return request({
			url: `coupon/getAllCoupon/${uid}`,
			method: 'post',
		});
	},
	getMyCoupon(id){
		return request({
			url: `coupon/conditionSearch/${id}`,
			method: 'post',
		});
	}
}
