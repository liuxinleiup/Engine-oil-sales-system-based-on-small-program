<template>
	<view style="margin-left: 10px;margin-right: 10px;">
		<u-navbar :is-back="false" title="购物车"></u-navbar>
		<view v-for="item in cart" class="order">
			<u-row>
				<u-col span="4">
					<image :src="item.spuInfo.image" style="width: 100%;height: 200rpx;"></image>
				</u-col>
				<u-col span="8">
					<view>{{item.spuInfo.productName}}</view>
					<u-number-box v-model="item.quantity" :disabled="true" style="margin: 10rpx 0;"></u-number-box>
					<view style="color: #ff765d;margin: 15rpx 0;">￥{{item.spuInfo.price}}</view>
					<view style="color: #727873;font-size: 25rpx;">{{item.spuInfo.createTime}}</view>
					<u-icon style="" @tap="removeCart(item.id)" name="trash-fill" size="35" color="#ff765d" ></u-icon>
				</u-col>
			</u-row>
		</view>
		<uni-view v-if="cart.length>0" data-v-cf183850="" class="cu-bar bg-white tabbar border shop">
			<uni-view @tap="show=true" data-v-cf183850="" class="bg-orange submit" >一键结算</uni-view>
			<uni-view data-v-cf183850="" class="bg-red submit" @tap="clearCart()">清空购物车</uni-view>
		</uni-view>
		<view v-else>
			<view class="page-box">
				<view>
					<view class="centre">
						<image src="https://cdn.uviewui.com/uview/template/taobao-order.png" mode=""></image>
						<view class="explain">
							您还没有相关的数据
							<view class="tips">可以去看看有那些想买的</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<u-modal v-model="show" :show-cancel-button="true" confirm-text="确定" title="购买确认" @cancel="cancel" @confirm="confirm">
			<view class="u-update-content">
				<rich-text :nodes="content"></rich-text>
			</view>
		</u-modal>
		<tabbar></tabbar>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import apis from "@/pages/api/servixe"
	import tabbar from '../common/tabbar/tabbar.vue'
	export default {
		components: {
			tabbar
		},
		data() {
			return {
				cart: [],
				show: false,
				// 传递给uni-app"rich-text"组件的内容，可以使用"<br>"进行换行
				content: `
									您确认要一键结算吗？一旦确定将会创建订单并且取消购物车！~
								`,
			}
		},
		onShow() {
			this.getData();
		},
		methods: {
			cancel() {
				this.show = false;
			},
			confirm() {
				this.creatOrder();
			},
			creatOrder() {
				let orders = [];
				for (var i = 0; i < this.cart.length; i++) {
					let order = {
						productId: this.cart[i].spuid,
						memberId: this.cart[i].userid
					}
					orders.push(order)
				}
				apis.batchCreateOrders(orders).then(res => {
					if (res.success) {
						//删除购物车
						for (var i = 0; i < this.cart.length; i++) {
							this.removeCart(this.cart[i].id)
						}
						uni.navigateTo({
							url: '/pages/product/creatorder?orders=' + res.data.nos
						});
					}else{
						this.$refs.uToast.show({
							title: res.message,
							type: 'error',
						})
					}
				})
				
			},
			getData() {
				apis.getCart(uni.getStorageSync("uid")).then(res => {
					this.cart = res.data.carts;
				})
			},
			removeCart(id) {
				apis.removeCart(id).then(res => {
					this.getData();
				})
			},
			gotoHome() {
				uni.redirectTo({
					url: "/pages/index/index"
				})
			},
			clearCart() {
				apis.clearCart(uni.getStorageSync("uid")).then(res => {
					if (res.success) {
						this.$refs.uToast.show({
							title: '清除成功',
							type: 'success',
						})
						this.cart = []
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.u-full-content {
		background-color: #00C777;
	}

	.u-update-content {
		font-size: 26rpx;
		color: $u-content-color;
		line-height: 1.7;
		padding: 30rpx;
	}

	page {
		background: #eeeeee;
		
	}

	.centre {
		text-align: center;
		margin: 200rpx auto;
		font-size: 32rpx;

		image {
			width: 164rpx;
			height: 164rpx;
			border-radius: 50%;
			margin-bottom: 20rpx;
		}

		.tips {
			font-size: 24rpx;
			color: #999999;
			margin-top: 20rpx;
		}

		.btn {
			margin: 80rpx auto;
			width: 200rpx;
			border-radius: 32rpx;
			line-height: 64rpx;
			color: #ffffff;
			font-size: 26rpx;
			background: linear-gradient(270deg, rgba(249, 116, 90, 1) 0%, rgba(255, 158, 1, 1) 100%);
		}
	}

	.order {
		width: 100%;
		background-color: #ffffff;
		margin: 15rpx auto;
		border-radius: 20rpx;
		box-sizing: border-box;
		padding: 20rpx;
		font-size: 28rpx;
		.top {
			display: flex;
			justify-content: space-between;

			.left {
				display: flex;
				align-items: center;

				.store {
					margin: 0 10rpx;
					font-size: 32rpx;
					font-weight: bold;
				}
			}

			.right {
				color: $u-type-warning-dark;
			}
		}
	}
</style>
