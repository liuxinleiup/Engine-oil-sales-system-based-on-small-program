<template>
	<view>
		<view class="cu-chat">
			<view v-for="item in msgs">
				<view class="cu-item self" v-if="item.isme">
					<view class="main">
						<view class="content bg-green shadow" v-if="item.type==='text'">
							<text>{{item.msg}}</text>
						</view>
						<image v-else-if="item.type==='img'" :src="item.msg" class="radius" mode="widthFix"></image>
						<view v-else class="content shadow" @click="playVoice(item.message)">
							<text class="cuIcon-sound text-xxl padding-right-xl"> </text>
						</view>
					</view>
					<image class="cu-avatar radius" :src="item.avatar"></image>
					<view class="date">{{item.date}}</view>
				</view>
				<view class="cu-item" v-else>
					<image class="cu-avatar radius" :src="item.avatar"></image>
					<view class="main">
						<view class="content bg-green shadow" v-if="item.type==='text'">
							<text>{{item.msg}}</text>
						</view>
						<image v-else-if="item.type==='img'" :src="item.msg" class="radius" mode="widthFix"></image>
						<view v-else class="content shadow" @click="playVoice(item.msg)">
							<text class="cuIcon-sound text-xxl padding-right-xl"> </text>
						</view>
					</view>
					<view class="date">{{item.date}}</view>
				</view>
			</view>
		</view>

		<view class="cu-bar foot input" :style="[{bottom:InputBottom+'px'}]">

			<input v-model="keyword" class="solid-bottom" :adjust-position="false" :focus="false" maxlength="300"
				cursor-spacing="10" @focus="InputFocus" @blur="InputBlur"></input>

			<button class="cu-btn bg-green shadow" @click="sendText">发送</button>
		</view>


	</view>
</template>

<script>
	import apis from "@/pages/api/servixe"
	import {
		baseUrl
	} from "@/pages/api/env"
	const recorderManager = uni.getRecorderManager();
	const innerAudioContext = uni.createInnerAudioContext();
	innerAudioContext.autoplay = true;
	var _this;
	export default {
		onLoad() {
			this.uid = uni.getStorageSync('uid');
			this.connectSocketInit(); //socket相关操作
		},
		beforeDestroy() {
			this.closeSocket();
		},

		data() {
			return {
				uploadUrl: '',
				InputBottom: 0,
				keyword: '',
				avatar: null,
				msgs: [{
					avatar: 'https://gulipro-edu.oss-cn-beijing.aliyuncs.com/images/kefu.jpeg',
					isme: false,
					type: 'text',
					msg: '有什么问题可以给我留言，我看到后会及时回复你的！',
					data: null,
				}],
				socketTask: null,
				// 确保websocket是打开状态
				is_open_socket: false,
				uid: ''

			};
		},
		methods: {
			InputFocus(e) {
				this.InputBottom = e.detail.height
			},
			InputBlur(e) {
				this.InputBottom = 0
			},
			sendText(text) {
				let msg = {
					fromUid: this.uid,
					toUid: '000',
					name: uni.getStorageSync('nickname'),
					msg: this.keyword,
					type: 'text',
					avatar: uni.getStorageSync('avatar'),
					isme: true
				}
				let _this = this;
				this.socketTask.send({
					data: JSON.stringify(msg),
					async success() {
						console.log("消息发送成功");
						console.log(msg)
						_this.msgs.push(msg);
						_this.keyword = ''
					},
				});
			},
			// 进入这个页面的时候创建websocket连接【整个页面随时使用】
			connectSocketInit() {
				//获取UID
				let uid = uni.getStorageSync('uid');
				// 创建一个this.socketTask对象【发送、接收、关闭socket都由这个对象操作】
				this.socketTask = uni.connectSocket({
					// 【非常重要】必须确保你的服务器是成功的,如果是手机测试千万别使用ws://127.0.0.1:9099【特别容易犯的错误】
					url: `ws://localhost:8888/chat/${uid}`,
					success(data) {},
				});
				// 消息的发送和接收必须在正常连接打开中,才能发送或接收【否则会失败】
				this.socketTask.onOpen((res) => {
					this.is_open_socket = true;
					// 注：只有连接正常打开中 ，才能正常收到消息
					this.socketTask.onMessage((res) => {
						console.log("及收到消息")
						console.log(res)
						let msgs = JSON.parse(res.data);
						for (var i = 0; i < msgs.length; i++) {
							msgs[i].isme = false;
							msgs[i].type = 'text'
						}
						for (var i = 0; i < msgs.length; i++) {
							this.msgs.push(msgs[i])
						}
					});
				})
			},
			// 关闭websocket【离开这个页面的时候执行关闭】
			closeSocket() {
				this.socketTask.close({
					success(res) {
						this.is_open_socket = false;
						console.log("关闭成功", res)
					},
					fail(err) {
						console.log("关闭失败", err)
					}
				})
			},
		}
	}
</script>

<style>
	page {
		padding-bottom: 100upx;
	}
</style>
