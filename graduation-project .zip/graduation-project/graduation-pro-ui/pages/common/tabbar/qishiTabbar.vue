<template>
	<view>
		<u-tabbar v-model="current" :list="list" @change="change()"></u-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [{
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: '抢单',
						isDot: true,
						customIcon: false,
						pagePath:'/pages/knight/knight'
					},
					{
						iconPath: "account",
						selectedIconPath: "account-fill",
						text: '我的',
						isDot: false,
						customIcon: false,
						pagePath:'/pages/knight/center'
					},
				],
				current: 0
			}
		},
		methods: {
			change(index){
				if(index===0){
					uni.redirectTo({
						url: '/pages/knight/knight'
					})
				}else{
					uni.redirectTo({
						url:'/pages/knight/center'
					})
				}
			}
		}
	}
</script>

<style>

</style>
