<template>
	<view>
		<u-tabbar v-model="current" :list="list" ></u-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [{
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: '首页',
						isDot: true,
						customIcon: false,
						pagePath:'/pages/index/index'
					},
					{
						iconPath: "shopping-cart",
						selectedIconPath: "shopping-cart-fill",
						text: '购物车',
						customIcon: false,
						pagePath:'/pages/cart/cart'
					},
					{
						iconPath: "account",
						selectedIconPath: "account-fill",
						text: '我的',
						isDot: false,
						customIcon: false,
						pagePath:'/pages/usercenter/usercenter'
					}
					],
				current: 0
			}
		},
		methods: {

		}
	}
</script>

<style>

</style>
