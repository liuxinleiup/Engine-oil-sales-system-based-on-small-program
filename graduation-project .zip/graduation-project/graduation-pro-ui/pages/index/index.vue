<template>
	<view class="content">

		<uni-view data-v-cf183850="" class="cu-bar bg-cyan search">
			<uni-view data-v-cf183850="" class="search-form radius">
				<uni-text data-v-cf183850="" class="cuIcon-search"><span></span></uni-text>
				<uni-input data-v-cf183850="">
					<div class="uni-input-wrapper">
						<form action="" class="uni-input-form">
							<input v-model="keyword" maxlength="140" step="" enterkeyhint="search" autocomplete="off"
								type="search" class="uni-input-input">
						</form>
					</div>
				</uni-input>
			</uni-view>
			<uni-view data-v-cf183850="" @tap="search" class="action">
				<uni-text data-v-cf183850="" class="cuIcon-search"><span></span></uni-text>
				<uni-text data-v-cf183850=""><span>搜索</span></uni-text>
			</uni-view>
		</uni-view>
		<!-- 分类 -->
		<u-row style="margin-top: 10px;">
			<u-grid :col="3">
				<u-grid-item v-for="item in classfiy" @tap="gotoClassfiy">
					<image :src="item.img" style="width: 150rpx;height: 150rpx;">
					</image>
					<view class="grid-text">{{ item.catelogName }}</view>
				</u-grid-item>
			</u-grid>
		</u-row>

		<!-- 轮播图 -->
		<view class="wrap">
			<u-swiper :list="banners" name="imageUrl"></u-swiper>
		</view>

		<view class="cu-bar bg-white">
			<view class="action">
				<text class="cuIcon-titles text-green"></text>
				<text class="text-xl text-bold">为你优选</text>
			</view>
		</view>
		<!-- 商品 -->
		<u-row>
			<u-col class=" bg-white solid-bottom" span="4" v-for="item in randomPro" @tap="goToFoodDetail(item.id)"
				style="background-color: #ffffff;">
				<u-image width="100%" height="100px" :src="item.image" style="margin: 0 auto;">
				</u-image>
				<view style="width: 100%;height: 50rpx;
					white-space:nowrap;overflow: hidden;
					text-overflow: ellipsis;">{{ item.productName }}</view>
				<view style="color: #ff5766;">￥{{ item.price }}</view>
			</u-col>
		</u-row>

		<!-- 附近好货 -->
		<view style="margin:15rpx 0;">
			<u-subsection :list="sortList" :current="0" @change="sectionChange"></u-subsection>
		</view>
		
		<view>
			<uni-view data-v-0e259fc1="" class="padding margin-botton solid-bottom"
				style="margin-bottom: 3px;padding: 15px 15px;" @tap="goToFoodDetail(item.id)"
				v-for="item in classfiyPro">
				<view>
					<u-row style="padding: 10rpx 10;">
						<u-col span="4">
							<u-image style="border-radius: 15rpx;" width="100%" height="200rpx" :src="item.image">
							</u-image>
						</u-col>
						<u-col span="8">
							<view style="font-size:18px;color: #1d1210;width: 100%;height: 50rpx;
							white-space:nowrap;overflow: hidden;
							text-overflow: ellipsis;">{{ item.productName }}</view>
							<view style="font-size:15px;color: #ff866f;">￥{{ item.price }}</view>
							<uni-view data-v-85e0946e="" class="cu-tag radius bg-yellow margin-bottom" style="margin-top: 5px;">本地超高人气商品</uni-view>
							<view>
							<uni-view data-v-85e0946e="" class="cu-tag bg-red radius sm">浏览量{{item.visitor===null?0:item.visitor}}</uni-view>
							<uni-view data-v-85e0946e="" class="cu-tag bg-red radius sm">月销{{item.sales}}</uni-view>
							</view>
						</u-col>
					</u-row>
				</view>
			</uni-view>
		</view>
		<view class="hover_ball_cell"
			:style="{ width: `${diameter}px`, height: `${diameter}px`, top: `${top}px`, left: `${left}px` }"
			@touchmove="touchmove" @touchend="touchend" @touchcancel="touchcancel" @tap="onTap"
			:animation="ballAnimation">
			<view class="wave">
			</view>
		</view>

		<!-- 导航栏 -->
		<tabbar></tabbar>
	</view>
</template>

<script>
	import tabbar from '../common/tabbar/tabbar.vue'
	import apis from "@/pages/api/servixe"

	export default {
		components: {
			tabbar
		},
		data() {
			return {
				diameter: 0,
				top: 348,
				left: 414,
				isMove: false,
				ballAnimation: {},
				timeout: null,
				modile: {},
				banners: [],
				keyword: '',
				randomPro: [],
				classfiy: [],
				type: 3,
				page: 1,
				size: 10,
				classfiyPro: [],
				list: [],
				curNow: 0,
				sortList: [{
						name: '综合排序'
					},
					{
						name: '价格排序'
					},
					{
						name: '最新上架'
					},
					{
						name: '销量最高'
					}
				],
			}
		},
		onLoad() {
			let _this = this;
			_this.modile = uni.getSystemInfoSync();
			_this.top = _this.modile.safeArea.top;
			_this.left = _this.modile.safeArea.left;
			_this.diameter = _this.modile.screenHeight / 15;
			this.getClassfiy();
			this.getRandomPro();
			this.getBanner();
			this.classfiyQuery();
		},
		methods: {
			getBanner() {
				apis.getBanner().then(res => {
					this.banners = res.data.list;
				})
			},
			goToFoodDetail(fid) {
				//在起始页面跳转到test.vue页面并传递参数
				uni.navigateTo({
					url: `../product/product?fid=${fid}`
				});
			},
			//切换商品
			sectionChange(index) {
				this.type = index + 1;
				this.classfiyQuery();
			},
			//获取分类
			getClassfiy() {
				apis.getClassfiyAll().then(res => {
					this.classfiy = res.data.categorys;
				})
			},
			getRandomPro() {
				apis.getRandomPro().then(res => {
					this.randomPro = res.data.list;
					console.log(this.randomPro)
				})
			},
			//分类查询
			classfiyQuery() {
				apis.classfiyQuery(this.type, this.page, this.size).then(res => {
					this.classfiyPro = res.data.list;
				})
			},
			gotoClassfiy() {
				uni.navigateTo({
					url: `../product/index1`,
				});
			},
			search() {
				uni.navigateTo({
					url: `../search/search?keyword=${this.keyword}`,
				});
			},
			onTap() {
				let _this = this;
				let x = '0';
				if (2 * _this.left >= _this.modile.safeArea.width) {
					x = '-100%';
				}
				let create = uni.createAnimation({
					duration: 0
				});
				create.translate(x).step();
				_this.ballAnimation = create.export();
				_this.overBall();
				uni.navigateTo({
					url: '../usercenter/couponcenter'
				});
			},
			touchmove(e) {
				let _this = this;
				_this.isMove = true;
				if (_this.timeout != null) {
					clearTimeout(_this.timeout);
					_this.timeout = null;
				}
				var touch = e.touches[0] || e.changedTouches[0];
				_this.left = touch.clientX;
				_this.top = touch.clientY;
			},
			touchend(e) {
				let _this = this;
				if (!_this.isMove) {
					return;
				}
				_this.finish(e);
			},
			touchcancel(e) {
				let _this = this;
				if (!_this.isMove) {
					return;
				}
				_this.finish(e);
			},
			finish(e) {
				let _this = this;
				_this.isMove = false;
				var touch = e.touches[0] || e.changedTouches[0];
				_this.left = touch.clientX;
				_this.top = touch.clientY;
				let x = '0';
				if (2 * _this.left + _this.diameter >= _this.modile.safeArea.width) {
					_this.left = _this.modile.safeArea.width;
					x = '-100%';
				} else {
					_this.left = _this.modile.safeArea.left;
				}
				if (_this.top > _this.modile.safeArea.height + _this.modile.safeAreaInsets.bottom) {
					_this.top = _this.modile.safeArea.height + _this.modile.safeAreaInsets.bottom;
				} else if (_this.top < -_this.diameter / 2) {
					_this.top = -_this.diameter / 2;
				}
				let create = uni.createAnimation({
					duration: 0
				});
				create.translate(x).step();
				_this.ballAnimation = create.export();
				_this.overBall();
			},
			overBall() {
				let _this = this;
				_this.timeout = setTimeout(() => {
					_this.timeout = null;
					let create = uni.createAnimation({
						duration: 400,
						timingFunction: 'ease-in'
					});
					create.translate('-50%').step();
					_this.ballAnimation = create.export();
				}, 1200);
			}
		}
	}
</script>

<style scoped lang="scss">
	page {
		background-color: #ffffff;
	}

	.hover_ball_cell {
		position: fixed;
		overflow: hidden;
		border-radius: 50%;
		background: #ffffff;
		transform: translate(-50%, 0);
		padding: 4rpx;
		box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(218, 244, 209, 1.0);

		.wave {
			background-image: url(../../static/优惠券.png);
			background-repeat: no-repeat;
			background-size: 50px;
			position: relative;
			width: 100%;
			height: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			border-radius: 50%;
		}
	}

	.content {
		padding: 0 rpx 10 rpx;
		background-color: #ffffff;
	}

	.grid-text {
		font-size: 28 rpx;
		margin-top: 4 rpx;
		color: $u-type-info;
	}

	.wrap {
		padding: 10 rpx 0 rpx;
	}

	.card {
		box-shadow: 0 2px 3px 0 rgba(0, 0, 0, 0.2);
		transition: 0.3s;
		border-radius: 5px;
	}

	.order {
		width: 710rpx;
		background-color: #ffffff;
		margin: 20rpx auto;
		border-radius: 20rpx;
		box-sizing: border-box;
		padding: 20rpx;
		font-size: 28rpx;

		.top {
			display: flex;
			justify-content: space-between;

			.left {
				display: flex;
				align-items: center;

				.store {
					margin: 0 10rpx;
					font-size: 32rpx;
					font-weight: bold;
				}
			}

			.right {
				color: $u-type-warning-dark;
			}
		}

		.item {
			display: flex;
			margin: 20rpx 0 0;

			.left {
				margin-right: 20rpx;

				image {
					width: 200rpx;
					height: 200rpx;
					border-radius: 10rpx;
				}
			}

			.content {
				.title {
					font-size: 28rpx;
					line-height: 50rpx;
				}

				.type {
					margin: 10rpx 0;
					font-size: 24rpx;
					color: $u-tips-color;
				}

				.delivery-time {
					color: #e5d001;
					font-size: 24rpx;
				}
			}

			.right {
				margin-left: 10rpx;
				padding-top: 20rpx;
				text-align: right;

				.decimal {
					font-size: 24rpx;
					margin-top: 4rpx;
				}

				.number {
					color: $u-tips-color;
					font-size: 24rpx;
				}
			}
		}

		.total {
			margin-top: 20rpx;
			text-align: right;
			font-size: 24rpx;

			.total-price {
				font-size: 32rpx;
			}
		}

		.bottom {
			display: flex;
			margin-top: 40rpx;
			padding: 0 10rpx;
			justify-content: space-between;
			align-items: center;

			.btn {
				line-height: 52rpx;
				width: 160rpx;
				border-radius: 26rpx;
				border: 2rpx solid $u-border-color;
				font-size: 26rpx;
				text-align: center;
				color: $u-type-info-dark;
			}

			.evaluate {
				color: $u-type-warning-dark;
				border-color: $u-type-warning-dark;
			}
		}
	}
</style>
