<template>
	<view class="wrap">
		<view class="top"></view>
		<view class="content">
			<view class="title">{{text}}</view>
			<u-field class="u-border-bottom" v-model="mobile" label="手机号" placeholder="请填写手机号">
			</u-field>
			<u-field v-model="pwd" type="password" label="密码" placeholder="请填写密码">
			</u-field>
			<button style="background-color: rgb(255, 153, 0);color: white;" @click="login()">登陆</button>
			<view class="alternative">
							<view class="password">密码登录</view>
									<view class="issue" @click="show = !show">注册</view>
			</view>
		</view>
		<view class="buttom">
			<view class="loginType">
				<view class="wechat item">
					<view class="icon" @click="showHint">
						<u-icon size="70" name="weixin-fill" color="rgb(83,194,64)"></u-icon>
					</view>
					微信
				</view>
				<view class="QQ item" @click="gotoHome()">
					<view class="icon">
						<u-icon size="70" name="home-fill" color="rgb(235, 193, 134)"></u-icon>
					</view>
					主页
				</view>
				<view class="QQ item" @click="showHint">
					<view class="icon">
						<u-icon size="70" name="qq-fill" color="rgb(17,183,233)"></u-icon>
					</view>
					QQ
				</view>

			</view>
			<view class="hint">
				登录代表同意
				<text class="link">用户协议、隐私政策，</text>
				并授权使用点评账号信息（如昵称、头像、收获地址）以便您统一管理
			</view>
		</view>
		<view>
			<u-toast ref="uToast" />
		</view>
		<view>
			<u-top-tips ref="uTips"></u-top-tips>
		</view>

		<!-- 注册 -->
		<u-popup v-model="show" mode="bottom">
			<view style="padding: 20px 15px;">
				<u-form :model="user" ref="uForm">
					<u-form-item label="昵称" label-width="130rpx">
						<u-input v-model="user.nickname" />
					</u-form-item>
					<u-form-item label="手机号" label-width="130rpx">
						<u-input type="number" v-model="user.mobile" />
					</u-form-item>
					<u-form-item label="性别">
						<u-radio-group v-model="user.sex">
							<u-radio v-for="(item, index) in radioList" :name="item.name" :disabled="item.disabled">
								{{ item.name }}
							</u-radio>
						</u-radio-group>
					</u-form-item>
					<u-form-item label="年龄" label-width="130rpx">
						<u-input v-model="user.age" />
					</u-form-item>
					<u-form-item label="密码" label-width="130rpx">
						<u-input v-model="user.password" type="password" />
					</u-form-item>
					<u-form-item label="确认密码" label-width="130rpx">
						<u-input v-model="user.repwd" type="password" />
					</u-form-item>
				</u-form>
				<u-button size="medium" :ripple="true" ripple-bg-color="rgb(255, 193, 0)" @click="regsiterUser()" style="width: 100%;margin-top: 15px;color: #FFFFFF;background-color: rgb(255, 153, 0);">
					注册</u-button>
			</view>
		</u-popup>
	</view>
</template>

<script>
	import apis from "@/pages/api/servixe"
	export default {
		data() {
			return {
				tel: '',
				mobile: '',
				pwd: '',
				identfiy: 1,
				text: '一家专注于机油的平台',
				show: false,
				radioList: [{
					name: '男',
					disabled: false
				}, {
					name: '女',
					disabled: false
				}],
				user: {
					mobile: '',
					password: '',
					nickname: '',
					sex: '',
					repwd: ''
				}
			}
		},
		computed: {
			inputStyle() {
				let style = {};
				if (this.tel) {
					style.color = "#fff";
					style.backgroundColor = this.$u.color['warning'];
				}
				return style;
			}
		},
		methods: {
			submit() {
				if (this.$u.test.mobile(this.tel)) {
					this.$u.route({
						url: 'pages/template/login/code'
					})
				}
			},
			showHint() {
				this.$refs.uToast.show({
					title: '此功能开发中',
					type: 'success',
					url: '/pages/user/index'
				})
			},
			gotoHome() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			regsiterUser() {
				if (this.user.password != this.user.repwd) {
					this.$refs.uTips.show({
						title: '两次输入的密码不一致',
						type: 'error',
						duration: '2300'
					})
					return;
				}
				apis.regsiterUser(this.user).then(res => {
					if (res.success) {
						this.$refs.uTips.show({
							title: '注册成功',
							type: 'success',
							duration: '2300'
						})
						this.user = {}
					} else {
						this.$refs.uTips.show({
							title: res.message,
							type: 'error',
							duration: '2300'
						})
					}
					this.show = false;
				})
			},
			login() {
				if (this.mobile.length != 11) {
					this.$refs.uTips.show({
						title: '请输入正确的手机格式',
						type: 'error',
						duration: '2300'
					})
					return;
				}
				if (this.pwd.length == 0) {
					this.$refs.uTips.show({
						title: '请输入密码',
						type: 'error',
						duration: '2300'
					})
					return;
				}
				apis.login({
					mobile: this.mobile,
					password: this.pwd
				}).then(res => {
					if (!res.success) {
						this.$refs.uTips.show({
							title: res.message,
							type: 'error',
							duration: '2300'
						})
					} else {
						console.log(res.data.userinfo)
						//存储用户信息
						uni.setStorageSync('uid', res.data.userinfo.id);
						uni.setStorageSync('nickname', res.data.userinfo.nickname);
						uni.setStorageSync('moeny', res.data.userinfo.money);
						uni.setStorageSync('phone', res.data.userinfo.mobile);
						uni.setStorageSync('avatar', res.data.userinfo.avatar);
						//跳转到首页
						uni.switchTab({
							url: '/pages/index/index'
						});

					}
				})
			}
		}
	};
</script>

<style lang="scss" scoped>
	page{
		background-color: #FFFFFF;
	}
	.wrap {
		font-size: 28rpx;

		.content {
			width: 600rpx;
			margin: 80rpx auto 0;

			.title {
				text-align: left;
				font-size: 60rpx;
				font-weight: 500;
				margin-bottom: 100rpx;
			}

			input {
				text-align: left;
				margin-bottom: 10rpx;
				padding-bottom: 6rpx;
			}

			.tips {
				color: $u-type-info;
				margin-bottom: 60rpx;
				margin-top: 8rpx;
			}

			.getCaptcha {
				background-color: rgb(253, 243, 208);
				color: $u-tips-color;
				border: none;
				font-size: 30rpx;
				padding: 12rpx 0;

				&::after {
					border: none;
				}
			}

			.alternative {
				color: $u-tips-color;
				display: flex;
				justify-content: space-between;
				margin-top: 30rpx;
			}
		}

		.buttom {
			.loginType {
				display: flex;
				padding: 350rpx 150rpx 150rpx 150rpx;
				justify-content: space-between;

				.item {
					display: flex;
					flex-direction: column;
					align-items: center;
					color: $u-content-color;
					font-size: 28rpx;
				}
			}

			.hint {
				padding: 20rpx 40rpx;
				font-size: 20rpx;
				color: $u-tips-color;

				.link {
					color: $u-type-warning;
				}
			}
		}
	}
</style>
