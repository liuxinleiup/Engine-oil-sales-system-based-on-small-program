<template>
	<view>
		<view class="order" style="margin-top: 25px;">
			<u-row>
				<u-col span="2">
					<u-icon name="car-fill" color="#ff765d" size="78"></u-icon>
				</u-col>
				<u-col span="9">
					<view style="font-size: 20px;">{{address.name}} {{address.mobile}}</view>
					<view>{{address.province}}</view>
					<view>{{address.detailAddress}}</view>
				</u-col>
			</u-row>
		</view>

		<view class="order" v-if="!isBatch">
			<u-row>
				<u-col span="3">
					<image :src="order.productCover" style="height: 200rpx;width: 100%;"></image>
				</u-col>
				<u-col span="9">
					<view>商品名称：{{order.productName}}</view>
					<view style="color: #ff765d;margin: 15rpx 0;">￥{{order.totalFee}}</view>
					<u-number-box v-model="order.productQuantity" :disabled="true" @change="valChange"></u-number-box>
					<view style="margin: 15rpx 0;">
						<u-tag :text="order.gmtCreate" mode="light" type="success" />
					</view>
					<view style="color: #a8a6a7;">订单号：{{order.orderNo}}</view>
				</u-col>
			</u-row>
			<view>
				<u-toast ref="uToast" />
			</view>

		</view>

		<view class="order" v-for="item in ordersData" v-else>
			<u-row>
				<u-col span="3">
					<image :src="item.productCover" style="height: 200rpx;width: 100%;"></image>
				</u-col>
				<u-col span="9">
					<view>商品名称：{{item.productName}}</view>
					<view style="color: #ff765d;margin: 15rpx 0;">￥{{item.totalFee}}</view>
					<u-number-box v-model="item.productQuantity" :disabled="true" @change="valChange"></u-number-box>
					<!-- <view style="margin: 15rpx 0;">
						<u-tag :text="item.productTypename" mode="light" type="success" />
					</view> -->
					<view style="color: #a8a6a7;">{{item.gmtCreate}}11</view>
				</u-col>
			</u-row>
			<view>
				<u-toast ref="uToast" />
			</view>
		</view>

		<!-- 优惠券 -->
		<view class="taobao" v-for="(item, index) in coupons"
		 :class="{'bg-green':(add_class==index)}" @click="selectCoupon(index, item.id)">
			<view class="ticket">
				<view class="left">
					<image class="picture" src="../../static/暂无优惠券可用.png" mode="widthFix"></image>
					<view class="introduce">
						<view class="top">
							￥
							<text class="big">{{item.amount}}</text>
							{{item.couponName}}
						</view>
						<view class="type">{{item.note}}</view>

						<text class="tag  cuIcon-title text-green" v-if="item.useType===0">全场通用</text>
						<text class="tag  cuIcon-title text-green"
							v-if="item.useType===1">{{item.category.catelogName}}</text>
						<text class="tag  cuIcon-title text-green" v-if="item.useType===2"
							>{{item.spuInfo.productName}}</text>
						<view class="date u-line-1">{{item.enableStartTime+" / "+item.enableEndTime}}</view>
					</view>
				</view>
			</view>
		</view>

		<u-button style="width: 710rpx;	margin: 20rpx auto;" @click="showPop(true)" type="success">支付</u-button>
		<u-keyboard default="" ref="uKeyboard" mode="number" :mask="true" :mask-close-able="false" :dot-enabled="false"
			v-model="show" :safe-area-inset-bottom="true" :tooltip="false" @change="onChange" @backspace="onBackspace">
			<view>
				<view class="u-text-center u-padding-20 money">
					<text>{{total}}</text>
					<text class="u-font-20 u-padding-left-10">元</text>
					<view class="u-padding-10 close" data-flag="false" @click="showPop(false)">
						<u-icon name="close" color="#333333" size="28"></u-icon>
					</view>
				</view>
				<view class="u-flex u-row-center">
					<u-message-input mode="box" :maxlength="6" :dot-fill="true" v-model="password"
						:disabled-keyboard="true" @finish="finish"></u-message-input>
				</view>
				<view class="u-text-center u-padding-top-10 u-padding-bottom-20 tips">模拟支付，密码随意</view>
			</view>
		</u-keyboard>

	</view>
</template>

<script>
	import apis from "@/pages/api/servixe"
	export default {
		data() {
			return {
				order: {},
				address: {},
				show: false,
				password: '',
				isBatch: false,
				orders: [],
				ordersData: [],
				coupons: [],
				total: 0,
				add_class:null,
				cheapMoney:0,
			}
		},
		onLoad(option) {
			this.orders = option.orders;
			if (this.orders == undefined) {
				this.getOrder(option.orderNo);
			} else {
				//批量查询订单并且显示
				this.isBatch = true;
				this.getBatchOrder();
			}
		},
		methods: {
			selectCoupon(index, couponId){
				//判断是否符合条件
				if(this.order.totalFee > this.coupons[index].minPoint){
					this.add_class = index
					this.cheapMoney = this.coupons[index].amount;
					this.order.couponId = couponId
				}else{
					//给出提示
					uni.showToast({
						icon: 'error',
						title: '不满足优惠条件'
					})
				}
				
			},
			getMyCoupon() {
				apis.getAllCoupon(uni.getStorageSync("uid")).then(res => {
					let mycoupon = res.data.coupons
					console.log(mycoupon)
					apis.getCouponBySpuid(this.order.productId).then(res => {
						let spu_coupons = res.data.rows
						console.log(spu_coupons)
						for (var i = 0; i < mycoupon.length; i++) {
							for (var j = 0; j < spu_coupons.length; j++) {
								if (mycoupon[i].id === spu_coupons[j].id) {
									this.coupons.push(mycoupon[i])
								}
							}
						}
					})
				})
			},
			getOrder(orderNo) {
				apis.getOrderByNo(orderNo).then(res => {
					this.order = res.data.item;
					this.address = res.data.item.address;
					this.getMyCoupon()
				})
			},
			getBatchOrder() {
				let orderNos = this.orders.split(',');
				apis.getBatchOrder(orderNos).then(res => {
					this.ordersData = res.data.order;
					//查询默认地址
					apis.getDefaultAddress(uni.getStorageSync("uid")).then(res => {
						this.address = res.data.address;
					})
				})
			},
			payFood() {
				if (!this.isBatch) {
					apis.pay(this.order.id, this.order.couponId===null?'':this.order.couponId).then(res => {
						if (res.success) {
							uni.hideLoading();
							this.show = false;
							uni.showToast({
								icon: 'success',
								title: '支付成功'
							})
							let moeny = uni.getStorageSync("moeny");
							uni.setStorageSync("moeny", moeny - this.order.productPrice)
							setTimeout(() => {
								//跳转到订单页面
								uni.redirectTo({
									url: `/pages/usercenter/orders/orders`,
								});
							}, 2000);
						}
					})
				} else {
					for (var i = 0; i < this.ordersData.length; i++) {
						apis.pay(this.ordersData[i].id).then(res => {
							if (res.success) {
								uni.hideLoading();
								this.show = false;
								uni.showToast({
									icon: 'success',
									title: '支付成功'
								})

							}
						})
					}
					let moeny = uni.getStorageSync("moeny");
					uni.setStorageSync("moeny", moeny - this.total)
					setTimeout(() => {
						//跳转到订单页面
						uni.redirectTo({
							url: `/pages/usercenter/orders/orders`,
						});
					}, 2000);
				}
			},
			onChange(val) {
				if (this.password.length < 6) {
					this.password += val;
				}

				if (this.password.length >= 6) {
					this.pay();
				}
			},
			onBackspace(e) {
				if (this.password.length > 0) {
					this.password = this.password.substring(0, this.password.length - 1);
				}
			},
			pay() {
				uni.showLoading({
					title: '支付中'
				})
				this.payFood();
			},
			showPop(flag = true) {
				this.password = '';
				this.show = flag;
				if (this.isBatch) {
					let count = 0;
					for (let i = 0; i < this.ordersData.length; i++) {
						count += this.ordersData[i].totalFee;
					}
					this.total = count;
				} else {
					this.total = this.order.totalFee;
				}
				this.total = this.total - this.cheapMoney;
				
			},
			finish() {}
		}
	}
</script>

<style lang="scss">
	page {
		background: #fdfaf8;
	}
	.bg-green {
		background-color: #18B566;
		color: #FFFFFF;
	}
	.taobao {
		width: 710rpx;
		margin: 0 auto;
		margin-bottom: 10rpx;
		// background-color: white;
		padding: 10rpx 10rpx 10rpx;
		border-radius: 10rpx;
		

		.title {
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin-bottom: 20rpx;
			font-size: 30rpx;

			.left {
				display: flex;
				align-items: center;
			}

			.store {
				font-weight: 500;
			}

			.buddha {
				width: 70rpx;
				height: 70rpx;
				border-radius: 10rpx;
				margin-right: 10rpx;
			}

			.entrance {
				color: $u-type-info;
				border: solid 2rpx $u-type-info;
				line-height: 48rpx;
				padding: 0 30rpx;
				background: none;
				border-radius: 15px;
			}
		}

		.ticket {

			.left {
				padding: 30rpx 20rpx;
				background-color: rgb(255, 245, 244);
				border-radius: 20rpx;
				border-right: dashed 2rpx rgb(224, 215, 211);
				display: flex;

				.picture {
					width: 40%;
					border-radius: 20rpx;
				}

				.introduce {
					margin-left: 10rpx;
					width: 100%;

					.top {
						color: $u-type-warning;
						font-size: 28rpx;

						.big {
							font-size: 60rpx;
							font-weight: bold;
							margin-right: 10rpx;
						}
					}

					.type {
						font-size: 28rpx;
						color: $u-type-info-dark;
					}

					.date {
						margin-top: 10rpx;
						font-size: 20rpx;
						color: $u-type-info-dark;
					}
				}
			}
		}
	}

	.order {
		width: 710rpx;
		background-color: #ffffff;
		margin: 20rpx auto;
		border-radius: 20rpx;
		box-sizing: border-box;
		padding: 20rpx;
		font-size: 28rpx;

		.top {
			display: flex;
			justify-content: space-between;

			.left {
				display: flex;
				align-items: center;

				.store {
					margin: 0 10rpx;
					font-size: 32rpx;
					font-weight: bold;
				}
			}

			.right {
				color: $u-type-warning-dark;
			}
		}
	}

	.money {
		font-size: 80rpx;
		color: $u-type-warning;
		position: relative;

		.close {
			position: absolute;
			top: 20rpx;
			right: 20rpx;
			line-height: 28rpx;
			font-size: 28rpx;
		}
	}

	.tips {
		color: $u-tips-color;
	}
</style>
