<template>
	<view style="background-color: #FFF;">
		<u-navbar :is-back="true" title="商品详情" title-color="#FFFFFf" :background="background"></u-navbar>
		<view class="content">
			<!-- 正文内容 -->
			<image :src="food.image" style="width: 100%;height: 700rpx;"></image>
			<view>
				<view class="bg-white " style="padding: 15px 15px;">
					<view class="coupon" v-if="coupons.length > 0" @tap="gotoCoupon">
						本单可减 > > > > > > > 立即领券
					</view>
					<u-tag :text="food.typeName" mode="light" type="success" />
					<view style="font-size: 40rpx;">{{food.productName}}</view>
					<view style="font-size: 40rpx; color: #fe7149;font-weight:bold;">￥{{food.price}}</view>
					<u-line color="#d4d1d6" />
					<view>浏览量：{{food.visitor}}</view>
					<u-line color="#d4d1d6" />
					<view>购买量：{{food.sales}}</view>
					<u-line color="#d4d1d6" />
					<view>上架时间：{{food.createTime}}</view>
				</view>
				<uni-view data-v-cf183850="" class="cu-bar bg-white tabbar border shop">
					<uni-button data-v-cf183850="" class="action" @tap="gotoChat()">
						<uni-view data-v-cf183850="" class="cuIcon-service text-green">
							<uni-view data-v-cf183850="" class="cu-tag badge"></uni-view>
						</uni-view>客服
					</uni-button>
					<uni-view data-v-cf183850="" class="bg-orange submit" @tap="saveCart(food.id)">加入购物车</uni-view>
					<uni-view data-v-cf183850="" class="bg-red submit" @tap="creatOrder">立即购买</uni-view>
				</uni-view>
				
				<view class="cu-bar bg-white">
					<view class="action">
						<text class="cuIcon-titles text-green"></text>
						<text class="text-xl text-bold">商品详情</text>
					</view>
				</view>

				<scroll-view scroll-x class="bg-white nav">
					<view class="flex text-center">
						<view class="cu-item flex-sub" :class="index==TabCur?'text-orange cur':''"
							v-for="(item,index) in tabs" :key="index" @tap="tabSelect" :data-id="index">
							{{item.name}}
						</view>
					</view>
				</scroll-view>

				<view v-if="TabCur===0" class="card" style="font-size: 30rpx;width: 100%;">
					<u-parse :html="food.detail"></u-parse>
				</view>
				<uni-view v-else data-v-3e7bf6ca="" class="cu-list menu-avatar comment solids-top">
					<uni-view v-for="item in comments" data-v-3e7bf6ca="" class="cu-item">
						<image class="cu-avatar radius"
							src="https://ossweb-img.qq.com/images/lol/img/champion/Morgana.png"></image>
						<uni-view data-v-3e7bf6ca="" class="content">
							<uni-view data-v-3e7bf6ca="" class="text-grey">{{item.nickname}}</uni-view>
							<uni-view data-v-3e7bf6ca="" class="bg-grey padding-sm radius margin-top-sm  text-sm">
								<uni-view data-v-3e7bf6ca="" class="flex">
									<uni-view data-v-3e7bf6ca="" class="flex-sub">{{item.content}}</uni-view>
								</uni-view>
							</uni-view>
							<uni-view data-v-3e7bf6ca="" class="margin-top-sm flex justify-between">
								<uni-view data-v-3e7bf6ca="" class="text-gray text-df">{{item.publishtime}}</uni-view>
								<uni-view data-v-3e7bf6ca="">
									<uni-text data-v-3e7bf6ca="" class="cuIcon-appreciatefill text-red"><span></span>
									</uni-text>
									<uni-text data-v-3e7bf6ca="" class="cuIcon-messagefill text-gray margin-left-sm">
										<span></span>
									</uni-text>
								</uni-view>
							</uni-view>
						</uni-view>
					</uni-view>
				</uni-view>
			</view>
			<u-toast ref="uToast" />
		</view>
	</view>
</template>

<script>
	import apis from "@/pages/api/servixe"
	export default {
		data() {
			return {
				tabs: [{
						name: '商品详情'
					},
					{
						name: '评论'
					},
				],
				background: {
					// 渐变色
					backgroundImage: 'linear-gradient(45deg, rgb(28, 187, 180), rgb(141, 198, 63))'
				},
				food: {},
				comments: [],
				TabCur: 0,
				coupons: [],
				scrollLeft: 0
			}
		},
		onLoad(option) {
			this.getData(option.fid);
			this.getCoupon(option.fid);
		},
		methods: {
			gotoCoupon() {
				uni.navigateTo({
					url: '../usercenter/couponcenter'
				})
			},
			//查询是否有可用优惠券
			getCoupon(id) {
				apis.getCouponBySpuid(id).then(res => {
					this.coupons = res.data.rows
				})
			},
			tabSelect(e) {
				this.TabCur = e.currentTarget.dataset.id;
				this.scrollLeft = (e.currentTarget.dataset.id - 1) * 60
			},
			gotoChat() {
				uni.navigateTo({
					url: '/pages/chat/chat',
				});

			},
			//保存到购物车
			saveCart() {
				let islogin = uni.getStorageSync("uid");
				if (islogin == '') {
					this.$refs.uToast.show({
						title: '请先登陆',
						type: 'error',
						url: '/pages/login/login'
					})
					return;
				}
				apis.saveCart(uni.getStorageSync("uid"), this.food.id).then(res => {
					if (res.success) {
						uni.showToast({
							icon: 'success',
							title: '加入购物车成功'
						})
					}
				})
			},
			//根据ID查询
			getData(fid) {
				apis.findById(fid).then(res => {
					//查询评论
					apis.queryComment(fid).then(res => {
						console.log(res.data.comments)
						this.comments = res.data.comments
					})
					this.food = res.data.spuinfo;
					this.food.id = fid
					let detail = this.food.detail.replace(regex, `<img style="max-width: 100%; height: auto"`);
					this.list.detail = detail
				})
			},
			creatOrder() {
				//判断是否登陆
				let islogin = uni.getStorageSync("uid");
				if (islogin == '') {
					this.$refs.uToast.show({
						title: '请先登陆',
						type: 'error',
						url: '/pages/login/login'
					})
					return;
				}
				//判断是否有默认地址
				apis.getDefaultAddress(uni.getStorageSync("uid")).then(res => {
					this.address = res.data.address;
					if (this.address == null) {
						this.$refs.uToast.show({
							title: '请先去个人中心设置默认地址',
							type: 'error',
							url: '/pages/usercenter/usercenter'
						})
						return;
					} else {
						apis.creatOrder(this.food.id, uni.getStorageSync("uid"), this.address.id).then(res => {
							if (res.success) {
								console.log(res.data)
								uni.navigateTo({
									url: '/pages/product/creatorder?orderNo=' + res.data.orderId
								});
							} else {
								this.$refs.uToast.show({
									title: res.message,
									type: 'error'
								})
							}
						})
					}
				})

			}
		}
	}
</script>

<style>
	page {
		background-color: #FFFFFF;
	}

	.coupon {
		background-color: #FF2658;
		height: auto;
		width: 100%;
		margin: 0 auto;
		border-radius: 6px;
		color: #FFFFFF;
		margin-bottom: 15px;
		padding: 10px 10px;
	}

	.comment {
		width: 100%;
		box-shadow: 0 1px 8px 0 rgba(0, 0, 0, 0.2);
		transition: 0.3s;
		border-radius: 5px;
		padding: 15rpx 10rpx;
	}

	.content {
		font-size: 18px;
	}

	.polaroid {
		width: 250px;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
		text-align: center;
		display: inline-block;
		background-color: #FFF;
	}

	.container {
		padding: 10px;
	}

	/*文字卡片*/
	.card {
		width: 250px;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
		text-align: center;
		display: inline-block;
		background-color: #FFF;
	}

	.header {
		background-color: #4CAF50;
		color: white;
		padding: 10px;
		font-size: 40px;
	}

	.box {
		margin: 20upx 0;
	}

	.box view.cu-bar {
		margin-top: 20upx;
	}

	.container {
		padding: 10px;
	}

	/*投影卡片*/

	#boxshadow {
		position: relative;
		-moz-box-shadow: 1px 2px 4px rgba(0, 0, 0, 0.5);
		-webkit-box-shadow: 1px 2px 4px rgba(0, 0, 0, .5);
		box-shadow: 1px 2px 4px rgba(0, 0, 0, .5);
		padding: 10px;
		background: white;
		width: 400px;
	}

	/* Make the image fit the box */
	#boxshadow img {
		width: 100%;
	}

	#boxshadow::after {
		content: '';
		position: absolute;
		z-index: -1;
		/* hide shadow behind image */
		-webkit-box-shadow: 0 5px 30px rgba(0, 0, 0, 0.3);
		-moz-box-shadow: 0 5px 30px rgba(0, 0, 0, 0.3);
		box-shadow: 0 5px 30px rgba(0, 0, 0, 0.3);
		width: 80%;
		left: 10%;
		/* one half of the remaining 30% */
		height: 100px;
		bottom: 0;
	}

	body {
		background-color: #999;
	}

	.card {
		text-align: left;
		box-shadow: 0 4px 5px 0 rgba(1, 0, 0, 0.2);
		transition: 0.3s;
		width: 100%;
		border-radius: 5px;
	}

	.card:hover {
		box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
	}
</style>
