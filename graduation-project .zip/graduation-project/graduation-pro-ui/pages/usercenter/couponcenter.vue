<template>
	<view class="u-wrap">
		<u-toast ref="uToast" />
		<view v-for="(item,index) in coupons" style="margin-bottom: 15px;">
			<view class="jingdong" v-if="item.showType==='仿京东'">
				<view class="left">
					<view class="sum">
						￥
						<text class="num">{{item.amount}}.00</text>
					</view>
					<view class="type">{{item.couponName}}</view>
				</view>
				<view class="right">
					<view class="top">
						<view class="title">
							<text class="tag" v-if="item.useType===0">全场通用</text>
							<text class="tag" v-if="item.useType===1">{{item.category.catelogName}}</text>
							<text class="tag" v-if="item.useType===2">{{item.spuInfo.productName}}</text>
							<text>{{item.note}}</text>
						</view>
						<view class="bottom">
							<view class="date u-line-1">{{item.enableStartTime+" / "+item.enableEndTime}}</view>
							<view class="immediate-use" v-if="!item.isGet" @click="getCoupon(index,item)">立即领取</view>
							<view class="immediate-use" v-else @click="getCoupon(index,item)">立即使用</view>
						</view>
					</view>
					<view class="tips">
						<view class="explain">
							<u-icon name="zhuanfa" class="transpond" :size="24"></u-icon>
							<text>可赠送</text>
						</view>
					</view>
				</view>
			</view>
			<view class="taobao" v-else>
				<view class="ticket">
					<view class="left">
						<image class="picture" src="../../static/暂无优惠券可用.png" mode="widthFix"></image>

						<view class="introduce">
							<view class="top">
								￥
								<text class="big">{{item.amount}}</text>
								{{item.couponName}}
							</view>
							<view class="type">{{item.note}}</view>

							<text class="tag  cuIcon-title text-green" v-if="item.useType===0">全场通用</text>
							<text class="tag  cuIcon-title text-green"
								v-if="item.useType===1">{{item.category.catelogName}}</text>
							<text class="tag  cuIcon-title text-green" v-if="item.useType===2"
								@click="gotoSpuinfo(item)">{{item.spuInfo.productName}}</text>
							<view class="date u-line-1">{{item.enableStartTime+" / "+item.enableEndTime}}</view>

						</view>
					</view>
					<view class="right">
						<view class="use" :round="true" @click="getCoupon(index,item)" v-if="!item.isGet">立即领取</view>
						<view class="use" :round="true" @click="getCoupon(index,item)" v-else>立即使用</view>
					</view>

				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import apis from "@/pages/api/servixe"
	export default {
		onLoad() {
			this.getCoupons();
		},
		data() {
			return {
				coupons: []
			}
		},
		methods: {
			//获取未领取的优惠券
			getCoupons() {
				apis.getCoupons(uni.getStorageSync("uid")).then(res => {
					this.coupons = res.data.coupons
				})
			},
			//商品详情页
			gotoSpuinfo(coupon) {

			},
			//领取优惠券
			getCoupon(index, coupon) {
				let param = {
					couponId: coupon.id,
					userId: uni.getStorageSync("uid")
				}
				apis.getCoupon(param).then(res => {
					if (res.success) {
						this.coupons[index].isGet = true
						this.$refs.uToast.show({
							title: '领取成功',
							type: 'success'
						})
					} else {
						this.$refs.uToast.show({
							title: res.message,
							type: 'error'
						})
					}
				})
			}
		}
	};
</script>

<style lang="scss" scoped>
	page {
		padding-top: 100px;
		height: 100%;
		background-image: url(../../static/couponbk.png);
		background-repeat: no-repeat;
		background-position: left top;
	}

	.u-wrap {
		padding: 24rpx;
	}

	.jingdong {
		width: 700rpx;
		height: auto;
		background-color: #ffffff;
		display: flex;

		.left {
			padding: 0 30rpx;
			background-color: rgb(95, 148, 224); //rgb(94, 152, 225);
			text-align: center;
			font-size: 28rpx;
			color: #ffffff;

			.sum {
				margin-top: 50rpx;
				font-weight: bold;
				font-size: 32rpx;

				.num {
					font-size: 80rpx;
				}
			}

			.type {
				margin-bottom: 50rpx;
				font-size: 24rpx;
			}
		}

		.right {
			padding: 20rpx 20rpx 0;
			font-size: 28rpx;

			.top {
				border-bottom: 2rpx dashed $u-border-color;

				.title {
					margin-right: 60rpx;
					line-height: 40rpx;

					.tag {
						padding: 4rpx 20rpx;
						background-color: rgb(73, 154, 201);
						border-radius: 20rpx;
						color: #ffffff;
						font-weight: bold;
						font-size: 24rpx;
						margin-right: 10rpx;
					}
				}

				.bottom {
					display: flex;
					margin-top: 20rpx;
					align-items: center;
					justify-content: space-between;
					margin-bottom: 10rpx;

					.date {
						font-size: 20rpx;
						flex: 1;
					}

					.immediate-use {
						height: auto;
						padding: 0 20rpx;
						font-size: 24rpx;
						border-radius: 40rpx;
						line-height: 40rpx;
						color: rgb(117, 142, 165);
						border: 2rpx solid rgb(117, 142, 165);
					}
				}
			}

			.tips {
				width: 100%;
				line-height: 50rpx;
				display: flex;
				align-items: center;
				justify-content: space-between;
				font-size: 24rpx;

				.transpond {
					margin-right: 10rpx;
				}

				.explain {
					display: flex;
					align-items: center;
				}

				.particulars {
					width: 30rpx;
					height: 30rpx;
					box-sizing: border-box;
					padding-top: 8rpx;
					border-radius: 50%;
					background-color: $u-type-info-disabled;
					text-align: center;
				}
			}
		}
	}

	.taobao {
		margin-top: 40rpx;
		width: 700rpx;
		background-color: white;
		padding: 30rpx 20rpx 20rpx;
		border-radius: 20rpx;

		.title {
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin-bottom: 20rpx;
			font-size: 30rpx;

			.left {
				display: flex;
				align-items: center;
			}

			.store {
				font-weight: 500;
			}

			.buddha {
				width: 70rpx;
				height: 70rpx;
				border-radius: 10rpx;
				margin-right: 10rpx;
			}

			.entrance {
				color: $u-type-info;
				border: solid 2rpx $u-type-info;
				line-height: 48rpx;
				padding: 0 30rpx;
				background: none;
				border-radius: 15px;
			}
		}

		.ticket {
			display: flex;

			.left {
				width: 70%;
				padding: 30rpx 20rpx;
				background-color: rgb(255, 245, 244);
				border-radius: 20rpx;
				border-right: dashed 2rpx rgb(224, 215, 211);
				display: flex;

				.picture {
					width: 172rpx;
					border-radius: 20rpx;
				}

				.introduce {
					margin-left: 10rpx;

					.top {
						color: $u-type-warning;
						font-size: 28rpx;

						.big {
							font-size: 60rpx;
							font-weight: bold;
							margin-right: 10rpx;
						}
					}

					.type {
						font-size: 28rpx;
						color: $u-type-info-dark;
					}

					.date {
						margin-top: 10rpx;
						font-size: 20rpx;
						color: $u-type-info-dark;
					}
				}
			}

			.right {
				width: 30%;
				padding: 40rpx 20rpx;
				background-color: rgb(255, 245, 244);
				border-radius: 20rpx;
				display: flex;
				align-items: center;

				.use {
					height: auto;
					padding: 0 20rpx;
					font-size: 24rpx;
					border-radius: 40rpx;
					color: #ffffff !important;
					background-color: $u-type-warning !important;
					line-height: 40rpx;
					color: rgb(117, 142, 165);
					margin-left: 20rpx;
				}
			}
		}
	}
</style>
