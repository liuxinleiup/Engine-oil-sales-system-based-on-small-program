<template>
	<view>
		<view class="wrap">
			<view class="u-tabs-box">
				<u-tabs-swiper activeColor="#f29100" ref="tabs" :list="list" :current="current" @change="change" :is-scroll="false"
				 swiperWidth="750"></u-tabs-swiper>
			</view>
			<swiper class="swiper-box" :current="swiperCurrent" @transition="transition" @animationfinish="animationfinish">
				<swiper-item class="swiper-item">
					<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="getOrderList1(0)">
						<view class="page-box">
							<view class="order" v-for="(item, index) in data1" :key="item.id">
								<view class="top">
									<view class="left">
										<u-icon name="home" :size="30" color="rgb(94,94,94)"></u-icon>
										<view class="store">畅享购</view>
										<u-icon name="arrow-right" color="rgb(203,203,203)" :size="26"></u-icon>
									</view>
									<view class="right">{{item.gmtCreate}}</view>
								</view>
								<view class="item">
									<view class="left">
										<image :src="item.productCover" mode="aspectFill"></image>
									</view>
									<view class="content">
										<view class="title u-line-2">{{ item.productName }}
										</view>
										<view class="price"> ￥{{ priceInt(item.totalFee) }}</view>
										<view class="type">{{ item.productTypename }}</view>
									</view>
								</view>
								<view class="total">
									共1件商品 合计:
									<text class="total-price">
										￥{{ item.totalFee }}
									</text>
								</view>
								<view class="bottom">
									<view class="more">
										<u-icon name="more-dot-fill" color="rgb(203,203,203)"></u-icon>
									</view>
									<view @click="deleteOrderById(item)" class="evaluate btn">取消订单</view>
									<view @click="goToFoodDetail(item.productId)" class="evaluate btn">查看</view>
									<view @click="goTopay(item)" class="evaluate btn">支付</view>
								</view>
							</view>
							<u-loadmore :status="loadStatus[0]" bgColor="#f2f2f2"></u-loadmore>
						</view>
					</scroll-view>
				</swiper-item>
				<swiper-item class="swiper-item">
					<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="getOrderList2(1)">
						<view class="page-box">
							<view class="order" v-for="(item, index) in data2" :key="item.id">
								<view class="top">
									<view class="left">
										<u-icon name="home" :size="30" color="rgb(94,94,94)"></u-icon>
										<view class="store">畅享购</view>
										<u-icon name="arrow-right" color="rgb(203,203,203)" :size="26"></u-icon>
									</view>
									<view class="right">{{item.gmtCreate}}</view>
								</view>
								<view class="item">
									<view class="left">
										<image :src="item.productCover" mode="aspectFill"></image>
									</view>
									<view class="content">
										<view class="title u-line-2">{{ item.productName }}
										</view>
										<view class="price"> ￥{{ priceInt(item.totalFee) }}</view>
										<view class="type">{{ item.productTypename }}</view>
									</view>
								</view>
								<view class="total">
									共1件商品 合计:
									<text class="total-price">
										￥{{ item.totalFee }}
									</text>
								</view>
								<view class="bottom">
									<view class="more">
										<u-icon name="more-dot-fill" color="rgb(203,203,203)"></u-icon>
									</view>
									<view @click="goToFoodDetail(item.productId)" class="evaluate btn">查看</view>
								</view>
							</view>
							<u-loadmore :status="loadStatus[0]" bgColor="#f2f2f2"></u-loadmore>
						</view>
					</scroll-view>
				</swiper-item>
				<swiper-item class="swiper-item">
					<scroll-view scroll-y style="height: 100%;width: 100%;">
						<view class="page-box">
							<view class="page-box">
								<view class="order" v-for="(item, index) in data3" :key="item.id">
									<view class="top">
										<view class="left">
											<u-icon name="home" :size="30" color="rgb(94,94,94)"></u-icon>
											<view class="store">畅享购</view>
											<u-icon name="arrow-right" color="rgb(203,203,203)" :size="26"></u-icon>
										</view>
										<view class="right">{{item.gmtCreate}}</view>
									</view>
									<view class="item">
										<view class="left">
											<image :src="item.productCover" mode="aspectFill"></image>
										</view>
										<view class="content">
											<view class="title u-line-2">{{ item.productName }}
											</view>
											<view class="price"> ￥{{ priceInt(item.totalFee) }}</view>
											<view class="type">{{ item.productTypename }}</view>
										</view>
									</view>
									<view class="total">
										共1件商品 合计:
										<text class="total-price">
											￥{{ item.totalFee }}
										</text>
									</view>
									<view class="bottom">
										<view class="more">
											<u-icon name="more-dot-fill" color="rgb(203,203,203)"></u-icon>
										</view>
										<view @click="delivery(item.id)" class="evaluate btn">确认收货</view>
										<view @click="lookWuliu(item.id)" class="evaluate btn">查看物流信息</view>
									</view>
								</view>
								<u-loadmore :status="loadStatus[0]" bgColor="#f2f2f2"></u-loadmore>
							</view>
						</view>
					</scroll-view>
				</swiper-item>
				<swiper-item class="swiper-item">
					<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="reachBottom">
						<view class="page-box">
							<view class="order" v-for="(item, index) in data4" :key="item.id">
								<view class="top">
									<view class="left">
										<u-icon name="home" :size="30" color="rgb(94,94,94)"></u-icon>
										<view class="store">畅享购</view>
										<u-icon name="arrow-right" color="rgb(203,203,203)" :size="26"></u-icon>
									</view>
									<view class="right">{{item.gmtCreate}}</view>
								</view>
								<view class="item">
									<view class="left">
										<image :src="item.productCover" mode="aspectFill"></image>
									</view>
									<view class="content">
										<view class="title u-line-2">{{ item.productName }}
										</view>
										<view class="price"> ￥{{ priceInt(item.totalFee) }}</view>
										<view class="type">{{ item.productTypename }}</view>
									</view>
								</view>
								<view class="total">
									共1件商品 合计:
									<text class="total-price">
										￥{{ item.totalFee }}
									</text>
								</view>
								<view class="bottom">
									<view class="more">
										<u-icon name="more-dot-fill" color="rgb(203,203,203)"></u-icon>
									</view>
									<view @click="showCommentDia(item.productId, item.id)" class="evaluate btn">评论</view>
								</view>

							</view>
							<u-loadmore :status="loadStatus[0]" bgColor="#f2f2f2"></u-loadmore>
						</view>
					</scroll-view>
				</swiper-item>
				<swiper-item class="swiper-item">
					<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="reachBottom">
						<view class="page-box">
							<view class="order" v-for="(item, index) in data5" :key="item.id">
								<view class="top">
									<view class="left">
										<u-icon name="home" :size="30" color="rgb(94,94,94)"></u-icon>
										<view class="store">畅享购</view>
										<u-icon name="arrow-right" color="rgb(203,203,203)" :size="26"></u-icon>
									</view>
									<view class="right">{{item.gmtCreate}}</view>
								</view>
								<view class="item">
									<view class="left">
										<image :src="item.productCover" mode="aspectFill"></image>
									</view>
									<view class="content">
										<view class="title u-line-2">{{ item.productName }}
										</view>
										<view class="price"> ￥{{ priceInt(item.totalFee) }}</view>
										<view class="type">{{ item.productTypename }}</view>
									</view>
								</view>
								<view class="total">
									共1件商品 合计:
									<text class="total-price">
										￥{{ item.totalFee }}
									</text>
								</view>
								<view class="bottom">
									<view class="more">
										<u-icon name="more-dot-fill" color="rgb(203,203,203)"></u-icon>
									</view>
									<view @click="deleteByUser(item.id)" class="btn">删除</view>
									<view @click="goToFoodDetail(item.productId)" class="evaluate btn">查看</view>
								</view>

							</view>
							<u-loadmore :status="loadStatus[0]" bgColor="#f2f2f2"></u-loadmore>
						</view>
					</scroll-view>
				</swiper-item>
			</swiper>
			<u-modal v-model="showComment" show-cancel-button="true" @confirm="publishComment">
				<u-input v-model="comment" type="textarea" placeholder="客观评价，文明发言" />
			</u-modal>
			<u-popup v-model="show" mode="center" border-radius="14">
				<view class="content">确认要要收货吗？</view>
				<view class="confrim-btn">
					<u-button @click="shouhuo()">确定</u-button>
				</view>
			</u-popup>
		</view>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import apis from "@/pages/api/servixe"
	export default {
		data() {
			return {
				orderList: [
					[],
					[],
					[],
					[]
				],
				showComment: false,
				content: '客观评价，文明发言：',
				show: false,
				data1: [],
				data2: [],
				data3: [],
				data5: [],
				comment: '',
				data4: [],
				list: [{
						name: '待付款'
					},
					{
						name: '待发货'
					},
					{
						name: '待收货'
					},
					{
						name: '待评价'
					},
					{
						name: '已完成'
					}
				],
				current: 0,
				swiperCurrent: 0,
				tabsHeight: 0,
				dx: 0,
				proId: '',
				orderNo: '',
				loadStatus: ['loadmore', 'loadmore', 'loadmore', 'loadmore'],
			};
		},
		onShow() {
			this.getOrderList1(0);
			this.getOrderList2(1);
			this.getOrderList3(2);
			this.getOrderList4(3);
			this.getOrderList5(4);
		},
		onLoad() {
			this.getOrderList1(0);
			this.getOrderList2(1);
			this.getOrderList3(2);
			this.getOrderList4(3);
			this.getOrderList5(4);
		},
		computed: {
			// 价格小数
			priceDecimal() {
				return val => {
					return val;
				};
			},
			// 价格整数
			priceInt() {
				return val => {
					return val;
				};
			}
		},
		methods: {
			//查看物流信息
			lookWuliu(id){
				uni.navigateTo({
					url: `/pages/Wuliu/Wuliu?id=${id}`,
				});
			},
			goTopay(item){
				uni.navigateTo({
					url: '/pages/product/creatorder?orderNo=' + item.id
				});
			},
			deleteOrderById(item){
				apis.deleteOrderById(item.id).then(res=>{
					this.getOrderList1(0);
				})
			},
			copyNumber(item){
				uni.setClipboardData({
								data: item.trackNum
							});
							uni.showToast({
								icon: 'success',
								title: '复制成功：'+item.trackNum
							})
			},
			deleteByUser(id) {
				apis.deleyeByUser(id).then(res => {
					uni.showToast({
						icon: 'success',
						title: '删除成功'
					})
					this.getOrderList1(0);
					this.getOrderList2(1);
					this.getOrderList3(2);
					this.getOrderList4(3);
					this.getOrderList5(4);
				})
			},
			delivery(orderNo) {
				this.show = true;
				this.orderNo = orderNo;
			},
			showCommentDia(proId, orderNo) {
				this.proId = proId;
				this.orderNo = orderNo;
				this.showComment = true;
			},
			publishComment() {
				let comment = {
					nickname: uni.getStorageSync("nickname"),
					uid: uni.getStorageSync("uid"),
					content: this.comment,
					spuId: this.proId,
					orderNo: this.orderNo
				}
				apis.saveComment(comment).then(res => {
					if (res.success) {
						this.$refs.uToast.show({
							title: '评论成功',
							type: 'success'
						})
						this.showComment = false;
						this.proId = '',
							this.orderNo = '',
							this.getOrderList1(0);
						this.getOrderList2(1);
						this.getOrderList3(2);
						this.getOrderList4(3);
					} else {
						this.$refs.uToast.show({
							title: res.message,
							type: 'success'
						})
					}
				})
			},
			shouhuo() {
				apis.delivery(this.orderNo).then(res => {
					if (res.success) {
						this.$refs.uToast.show({
							title: '收货成功',
							type: 'success'
						})
						this.show = false;
						this.orderNo = '',
						this.getOrderList1(0);
						this.getOrderList2(1);
						this.getOrderList3(2);
						this.getOrderList4(3);
						this.getOrderList5(4);
					} else {
						this.$refs.uToast.show({
							title: res.message,
							type: 'success'
						})
					}

				})
			},
			reachBottom() {

			},
			//查询待支付
			getOrderList1(status) {
				apis.penOrder(uni.getStorageSync("uid")).then(res => {
					this.data1 = res.data.orders;
					console.log(res.data)
				})
				this.loadStatus.splice(this.current, 1, "loadmore")
			},
			getOrderList2(status) {
				apis.delivered(uni.getStorageSync("uid")).then(res => {
					this.data2 = res.data.orders;
				})
				this.loadStatus.splice(this.current, 1, "loadmore")
			},
			getOrderList3(status) {
				apis.received(uni.getStorageSync("uid")).then(res => {
					this.data3 = res.data.orders;
				})
				this.loadStatus.splice(this.current, 1, "loadmore")
			},
			getOrderList4(status) {
				apis.comment(uni.getStorageSync("uid")).then(res => {
					this.data4 = res.data.orders;
				})
				this.loadStatus.splice(this.current, 1, "loadmore")
			},
			getOrderList5(status) {
				apis.alredyFinish(uni.getStorageSync("uid")).then(res => {
					this.data5 = res.data.orders;
				})
				this.loadStatus.splice(this.current, 1, "loadmore")
			},
			// 总价
			totalPrice(item) {
				let price = 0;
				return 3;
			},
			// 总件数
			totalNum(item) {
				let num = 0;
				return 4;
			},
			// tab栏切换
			change(index) {
				this.swiperCurrent = index;
				switch (index) {
					case 0:
						this.getOrderList1(0);
						break;
					case 1:
						this.getOrderList2(1);
						break;
					case 2:
						this.getOrderList3(2);
						break;
					case 3:
						this.getOrderList4(3);
						break;
					case 4:
						this.getOrderList5(4);
						break;
				}
			},
			goToFoodDetail(fid) {
				//在起始页面跳转到test.vue页面并传递参数
				uni.navigateTo({
					url: `../../product/product?fid=${fid}`
				});
			},
			transition({
				detail: {
					dx
				}
			}) {
				this.$refs.tabs.setDx(dx);
			},
			animationfinish({
				detail: {
					current
				}
			}) {
				this.$refs.tabs.setFinishCurrent(current);
				this.swiperCurrent = current;
				this.current = current;
			}
		}
	};
</script>

<style>
	/* #ifndef H5 */
	page {
		height: 100%;
		background-color: #f2f2f2;
	}

	/* #endif */
</style>

<style lang="scss" scoped>
	.content {
		padding: 24rpx;
		text-align: center;
	}

	.order {
		width: 710rpx;
		background-color: #ffffff;
		margin: 20rpx auto;
		border-radius: 20rpx;
		box-sizing: border-box;
		padding: 20rpx;
		font-size: 28rpx;

		.top {
			display: flex;
			justify-content: space-between;

			.left {
				display: flex;
				align-items: center;

				.store {
					margin: 0 10rpx;
					font-size: 32rpx;
					font-weight: bold;
				}
			}

			.right {
				color: $u-type-warning-dark;
			}
		}

		.item {
			display: flex;
			margin: 20rpx 0 0;

			.left {
				margin-right: 20rpx;

				image {
					width: 200rpx;
					height: 200rpx;
					border-radius: 10rpx;
				}
			}

			.content {
				.title {
					font-size: 28rpx;
					line-height: 50rpx;
				}

				.type {
					margin: 10rpx 0;
					font-size: 24rpx;
					color: $u-tips-color;
				}

				.delivery-time {
					color: #e5d001;
					font-size: 24rpx;
				}
			}

			.right {
				margin-left: 10rpx;
				padding-top: 20rpx;
				text-align: right;

				.decimal {
					font-size: 24rpx;
					margin-top: 4rpx;
				}

				.number {
					color: $u-tips-color;
					font-size: 24rpx;
				}
			}
		}

		.total {
			margin-top: 20rpx;
			text-align: right;
			font-size: 24rpx;

			.total-price {
				font-size: 32rpx;
			}
		}

		.bottom {
			display: flex;
			margin-top: 40rpx;
			padding: 0 10rpx;
			justify-content: space-between;
			align-items: center;

			.btn {
				line-height: 52rpx;
				width: 160rpx;
				border-radius: 26rpx;
				border: 2rpx solid $u-border-color;
				font-size: 26rpx;
				text-align: center;
				color: $u-type-info-dark;
			}

			.evaluate {
				color: $u-type-warning-dark;
				border-color: $u-type-warning-dark;
			}
		}
	}

	.centre {
		text-align: center;
		margin: 200rpx auto;
		font-size: 32rpx;

		image {
			width: 164rpx;
			height: 164rpx;
			border-radius: 50%;
			margin-bottom: 20rpx;
		}

		.tips {
			font-size: 24rpx;
			color: #999999;
			margin-top: 20rpx;
		}

		.btn {
			margin: 80rpx auto;
			width: 200rpx;
			border-radius: 32rpx;
			line-height: 64rpx;
			color: #ffffff;
			font-size: 26rpx;
			background: linear-gradient(270deg, rgba(249, 116, 90, 1) 0%, rgba(255, 158, 1, 1) 100%);
		}
	}

	.wrap {
		display: flex;
		flex-direction: column;
		height: calc(100vh - var(--window-top));
		width: 100%;
	}

	.swiper-box {
		flex: 1;
	}

	.swiper-item {
		height: 100%;
	}
</style>
