<template>
	<view>
		<u-navbar :is-back="false"  title="个人中心"></u-navbar>
		<view class="u-flex user-box u-p-l-30 u-p-r-20 u-p-b-30" @click="goToUserinfo()">
			<view class="u-m-r-10">
				<u-avatar :src="pic" size="140"></u-avatar>
			</view>
			<view class="u-flex-1">
				<view class="u-font-18 u-p-b-20">{{nickname!=null?nickname:phone}}</view>
				<view class="u-font-14 u-tips-color">余额:￥{{moeny}}</view>
			</view>
			<view class="u-m-l-10 u-p-10">
				<u-icon name="scan" color="#969799" size="28"></u-icon>
			</view>
			<view class="u-m-l-10 u-p-10">
				<u-icon name="arrow-right" color="#969799" size="28"></u-icon>
			</view>
		</view>
		<u-toast ref="uToast" />
		<view class="u-m-t-20">
			<u-cell-group>
				<u-cell-item icon="shopping-cart-fill" @click="gotOrder" title="我的订单"></u-cell-item>
			</u-cell-group>
		</view>
		
		<view class="u-m-t-20">
			<u-cell-group>
				<u-cell-item @click="toAddress" icon="map-fill" title="我的地址"></u-cell-item>
				<u-cell-item icon="coupon-fill" title="领劵中心" @click="gotoCoupon"></u-cell-item>
			</u-cell-group>
			<u-cell-group>
				<u-cell-item icon="bookmark-fill" @click="about" title="关于软件"></u-cell-item>
			</u-cell-group>
		</view>
	
		
		
		<view class="u-m-t-20">
			<u-cell-group>
				<u-cell-item icon="setting" title="退出" @click="loginOut"></u-cell-item>
			</u-cell-group>
		</view>
		<!-- 导航栏 -->
		<tabbar></tabbar>
	</view>
</template>

<script>
	import tabbar from '../common/tabbar/tabbar.vue'
	export default {
		components: {
			tabbar
		},
		data() {
			return {
				pic:'https://thirdwx.qlogo.cn/mmopen/vi_32/0AjchbVq5LibpBibswz8iaQ1APhgzr5PWx2wbZRR9r2N2y6JlsnGohVCEPyiamxYYC6gB3cIo3vSC1l4IGF7AQZcCg/132',
				show:true,
				nickname:'',
				phone:'',
				moeny:0
			} 
		},
		onShow(){
			//判断用户是否登陆
			if(uni.getStorageSync("uid")==undefined || uni.getStorageSync("uid").trim()==""){
				uni.navigateTo({
				    url: '../login/login'
				});
			}
			this.nickname = uni.getStorageSync("nickname");
			this.phone = uni.getStorageSync("phone");
			this.moeny = uni.getStorageSync("moeny");
			this.pic = uni.getStorageSync("avatar");
		},
		onLoad() {
			
		},
		methods: {
			loginOut(){
				uni.removeStorageSync('uid');
				uni.removeStorageSync('nickname');
				uni.removeStorageSync('phone');
				uni.removeStorageSync('moeny');
				//跳转到登陆
				uni.redirectTo({
				    url: '../login/login'
				});
			},
			toAddress(){
				uni.navigateTo({
				    url: '/pages/address/address'
				});
			},
			gotoCoupon(){
				uni.navigateTo({
				    url: '/pages/usercenter/couponcenter'
				});
			},
			gotOrder(){
				uni.navigateTo({
				    url: '/pages/usercenter/orders/orders'
				});
			},
			about(){
				uni.navigateTo({
				    url: '/pages/aboutSoftware/aboutSoftware'
				});
			},
			goToUserinfo(){
				let uid = uni.getStorageSync("uid");
				uni.navigateTo({
				    url: `/pages/usercenter/userinfo/userinfo?uid=${uid}`
				});
			}
		},
		
	}
</script>

<style lang="scss">
page{
	background-color: #ededed;
}

.camera{
	width: 54px;
	height: 44px;
	
	&:active{
		background-color: #ededed;
	}
}
.user-box{
	background-color: #fff;
}
</style>
