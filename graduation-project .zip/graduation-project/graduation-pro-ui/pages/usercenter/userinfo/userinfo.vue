<template>
	<view style="margin-right: 10px;margin-left: 10px;">
		<view>
			<u-top-tips ref="uTips"></u-top-tips>
		</view>
		<u-navbar :is-back="true"  title="个人信息"></u-navbar>
		<u-form :model="user" ref="uForm" style="padding: 20rpx;">
			<u-form-item label="姓名">
				<u-input v-model="user.nickname" />
			</u-form-item>
			<u-form-item label="余额">
				<u-input v-model="user.money" type="number" />
			</u-form-item>
			<u-form-item label="手机">
				<u-input v-model="user.mobile" type="number" />
			</u-form-item>
			<u-form-item label="头像">
				<u-upload ref="uUpload" :file-list="fileList" max-count="1" @on-success="success" :action="action" :auto-upload="true"></u-upload>
			</u-form-item>
			<u-form-item label="性别">
				<u-radio-group v-model="user.sex">
					<u-radio v-for="(item, index) in radioList" :name="item.name" :disabled="item.disabled">
						{{ item.name }}
					</u-radio>
				</u-radio-group>
			</u-form-item>
			<u-form-item label="密码" label-width="130rpx">
				<u-input v-model="user.password" type="password" />
			</u-form-item>
			<u-form-item label="确认密码" label-width="130rpx">
				<u-input v-model="user.repwd" type="password" />
			</u-form-item>
			<button class="cu-btn bg-green" style="width: 100%;margin-top: 15px;" @tap="saveUserInfo()" >保存</button>
		</u-form>
	</view>
</template>

<script>
	import apis from "@/pages/api/servixe"
	export default {
		onLoad(option) {
			this.getUserInfo(option.uid);
		},
		data() {
			return {
				user: {
					nickname: '',
					avatar: '',
					sex: '',
					password:'',
					repwd:'',
					mobile:'',
					id:'',
					money:0,
				},

				radioList: [{
					name: '男',
					disabled: false
				}, {
					name: '女',
					disabled: false
				}],
				radio: '',
				fileList: [],
				action: 'http://localhost:8888/costume/file/upload',
			}
		},
		methods: {
			getUserInfo(id) {
				apis.findUserById(id).then(res => {
					this.user = res.data.user;
					let item = {
						url: this.user.avatar
					}
					this.fileList = []
					this.fileList[0] = item
				})
			},
			success(data, index, lists, name) {
				this.user.avatar = data.data.url
			},
			saveUserInfo() {
				//判断密码是否一致
				if (this.user.password != this.user.repwd) {
					this.$refs.uTips.show({
						title: '两次输入的密码不一致',
						type: 'error',
						duration: '2300'
					})
					return;
				}
				apis.updateUserInfo(this.user).then(res=>{
					if(res.success){
						this.$refs.uTips.show({
							title: '修改成功',
							type: 'success',
							duration: '1000'
						})
						//修改本地存储
						uni.setStorageSync('uid', this.user.id);
						uni.setStorageSync('nickname', this.user.nickname);
						uni.setStorageSync('moeny', this.user.money);
						uni.setStorageSync('phone', this.user.mobile);
						uni.setStorageSync('avatar', this.user.avatar);
					}
				})
			}
		}
	}
</script>

<style>
page{
	background-color: #FFFFFF;

}
</style>
