package com.biyesheji.costume.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CostumeException extends RuntimeException{
    int code;
    String msg;
}
