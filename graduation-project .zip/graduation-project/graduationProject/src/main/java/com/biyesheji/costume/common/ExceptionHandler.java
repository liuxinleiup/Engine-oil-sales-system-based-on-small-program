package com.biyesheji.costume.common;


import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
@Slf4j
public class ExceptionHandler {

    //自定义异常处理器
    @org.springframework.web.bind.annotation.ExceptionHandler(MagicException.class)
    @ResponseBody
    public R error(MagicException e){
        e.printStackTrace();
        log.error(e.getMsg());
        return R.error().code(e.getCode()).message(e.getMsg());
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(Exception.class)
    @ResponseBody
    public R error(Exception e){
        e.printStackTrace();
        log.error(e.getMessage(), e);
        return R.error().message("对不起，服务器内部错误~");
    }

}
