package com.biyesheji.costume.common;

public interface ResultCode {

    Integer SUCCESS = 20000;

    Integer ERROR = 20001;
}
