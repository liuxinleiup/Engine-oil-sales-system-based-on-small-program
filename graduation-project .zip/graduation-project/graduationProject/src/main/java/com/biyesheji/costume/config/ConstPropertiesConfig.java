package com.biyesheji.costume.config;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

@Component
public class ConstPropertiesConfig implements InitializingBean {

    private String endpoint = "oss-cn-beijing.aliyuncs.com";
    private String keyid = "LTAI4GAZQbQvSrTqy2oPmq7q";
    private String keysecret = "xoDPxmG0lXkZoFCWIvpSTLGf0TjaA0";
    private String bucktname = "gulipro-edu";

    public static String END_POINT;
    public static String ACCESS_KEY_ID;
    public static String ACCESS_KEY_SECRET;
    public static String BUCKET_NAME;

    @Override
    public void afterPropertiesSet() throws Exception {
        END_POINT = endpoint;
        ACCESS_KEY_ID = keyid;
        ACCESS_KEY_SECRET = keysecret;
        BUCKET_NAME = bucktname;
    }
}
