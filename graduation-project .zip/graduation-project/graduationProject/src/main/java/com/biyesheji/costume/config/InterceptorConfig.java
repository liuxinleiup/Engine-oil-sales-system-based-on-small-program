package com.biyesheji.costume.config;


import com.biyesheji.costume.handler.ParamInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

public class InterceptorConfig extends WebMvcConfigurationSupport {

    public void addInterceptors(InterceptorRegistry registry) {
        //此处配置拦截路径
        registry.addInterceptor(new ParamInterceptor())
                .addPathPatterns("/**")
                .excludePathPatterns(
                        "/costume/admin/login",
                        "/api/user/wx/**",
                        "/costume/file/*",
                        "/costume/bk/**"
                        );
    }

}
