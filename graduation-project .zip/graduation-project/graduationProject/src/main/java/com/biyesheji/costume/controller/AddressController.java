package com.biyesheji.costume.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.Address;
import com.biyesheji.costume.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.Path;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2020-11-19
 */
@RestController
@RequestMapping("/costume/address")
public class AddressController {

    @Autowired
    private AddressService addressService;

    //新增收货地址
    @PostMapping("add")
    public R addAddress(@RequestBody Address address){
        addressService.save(address);
        return R.ok();
    }

    //查询用户默认地址
    @GetMapping("{uid}")
    public R getDefaultAddress(@PathVariable String uid){
        Address address = addressService.getDefaultAddress(uid);
        return R.ok().data("address", address);
    }


    //查询用户所有地址
    @GetMapping("getAll/{uid}")
    public R getAllByUid(@PathVariable String uid){
        QueryWrapper<Address> wrapper = new QueryWrapper<>();
        wrapper.eq("userid", uid);
        return R.ok().data("address", addressService.list(wrapper));
    }

    //设为默认
    @PutMapping("setDefualt/{aid}")
    public R setDefualt(@PathVariable Integer aid){
        Address address = addressService.getById(aid);

        //取消默认
        QueryWrapper<Address> wrapper = new QueryWrapper<>();
        wrapper.eq("userid",address.getUserid());
        addressService.list(wrapper).forEach(item->{
            item.setIsDefault(false);
            addressService.updateById(item);
        });

        //设为默认
        address.setIsDefault(true);
        addressService.updateById(address);
        return R.ok();
    }

    //删除地址
    @DeleteMapping("{aid}")
    public R deleteById(@PathVariable Integer aid){
        addressService.removeById(aid);
        return R.ok();
    }
}

