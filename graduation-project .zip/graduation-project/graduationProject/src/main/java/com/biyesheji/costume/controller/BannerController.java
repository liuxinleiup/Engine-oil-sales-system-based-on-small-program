package com.biyesheji.costume.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.Banner;
import com.biyesheji.costume.service.BannerService;
import com.biyesheji.costume.service.OSService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 首页banner表 前端控制器
 * </p>
 *
 * @author xyh
 * @since 2020-09-28
 */
@RestController
@RequestMapping("/costume/banner")
public class BannerController {

    @Autowired
    private BannerService bannerService;
    @Autowired
    private OSService osService;

    //查询所有banner
    @GetMapping("getAllBanner")
    public R getAllBanner() {
        List<Banner> list = bannerService.selectAllBanner();
        return R.ok().data("list",list);
    }


    //1 分页查询banner
    @GetMapping("pageBanner/{page}/{limit}")
    public R pageBanner(@PathVariable Integer page, @PathVariable Integer limit) {
        Page<Banner> pageBanner = new Page<>(page,limit);
        bannerService.page(pageBanner,null);
        return R.ok().data("items",pageBanner.getRecords()).data("total",pageBanner.getTotal());
    }

    //2 添加banner
    @PostMapping("addBanner")
    public R addBanner(@RequestBody Banner banner) {
        banner.setGmtCreate(new Date());
        bannerService.save(banner);
        return R.ok();
    }

    @ApiOperation(value = "获取Banner")
    @GetMapping("get/{id}")
    public R get(@PathVariable String id) {
        Banner banner = bannerService.getById(id);
        return R.ok().data("item", banner);
    }

    @ApiOperation(value = "修改Banner")
    @PutMapping("update")
    public R updateById(@RequestBody Banner banner) {
        bannerService.updateById(banner);
        return R.ok();
    }

    @ApiOperation(value = "删除Banner")
    @DeleteMapping("remove/{id}")
    public R remove(@PathVariable String id) {
        String url = bannerService.getById(id).getImageUrl();
        bannerService.removeById(id);
        return R.ok();
    }

}

