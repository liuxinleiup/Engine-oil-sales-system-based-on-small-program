package com.biyesheji.costume.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.Cart;
import com.biyesheji.costume.pojo.SpuInfo;
import com.biyesheji.costume.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2020-11-21
 */
@RestController
@RequestMapping("/costume/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    //添加商品到购物车
    @GetMapping("saveCart/{uid}/{spuid}")
    public R saveCart(@PathVariable String uid,
                      @PathVariable Integer spuid){
        cartService.saveCart(uid, spuid);
        return R.ok().message("保存成功");
    }

    //删除购物车
    @DeleteMapping("deleteCart/{id}")
    public R deleteCart(@PathVariable Integer id){
        cartService.removeById(id);
        return R.ok().message("删除成功");
    }

    //查询购物车
    @GetMapping("queryCart/{uid}")
    public R queryCart(@PathVariable String uid){
        List<Cart> data = cartService.queryCart(uid);
        return R.ok().data("carts", data);
    }

    @DeleteMapping("clear/{userid}")
    public R clear(@PathVariable String userid){
        cartService.remove(new QueryWrapper<Cart>().eq("userid", userid));
        return R.ok().message("删除成功");
    }

}

