package com.biyesheji.costume.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.Category;
import com.biyesheji.costume.pojo.SpuInfo;
import com.biyesheji.costume.service.CategoryService;
import com.biyesheji.costume.service.SpuImagesService;
import com.biyesheji.costume.service.SpuInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2020-11-16
 */
@RestController
@RequestMapping("/costume/category")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;
    @Autowired
    private SpuInfoService spuInfoService;

    //查询所有分类
    @GetMapping
    public R getAll(){
        return R.ok().data("categorys", categoryService.list(null));
    }

    //删除分类
    @DeleteMapping("{id}")
    public R deleteById(@PathVariable Integer id){
        categoryService.removeById(id);
        QueryWrapper<SpuInfo> wrapper = new QueryWrapper<>();
        wrapper.eq("category_id", id);
        spuInfoService.remove(wrapper);
        return R.ok();
    }

    //批量保存
    @PostMapping("add")
    public R add(@RequestBody List<Category> categories){
        categoryService.saveBatch(categories);
        return R.ok();
    }

    //新增分类
    @PostMapping
    public R add(@RequestBody Category category){
        categoryService.save(category);
        return R.ok();
    }

}

