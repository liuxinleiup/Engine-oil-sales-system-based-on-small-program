package com.biyesheji.costume.controller;


import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.Comment;
import com.biyesheji.costume.pojo.TOrder;
import com.biyesheji.costume.service.CommentService;
import com.biyesheji.costume.service.TOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2020-11-19
 */
@RestController
@RequestMapping("/costume/comment")
public class CommentController {

    @Autowired
    private CommentService commentService;
    @Autowired
    private TOrderService orderService;


    //发表评论
    @PostMapping
    public R saveComment(@RequestBody Comment comment) {
        comment.setPublishtime(new Date());
        //图片处理
        String json = JSON.toJSONString(comment.getImages());
        comment.setPhotos(json);
        commentService.save(comment);
        //将订单修改状态
        TOrder order = orderService.getById(comment.getOrderNo());
        order.setShipState(3);
        orderService.updateById(order);
        return R.ok();
    }

    //删除评论
    @DeleteMapping("{id}")
    public R deleteById(@PathVariable String id) {
        commentService.removeById(id);
        return R.ok();
    }

    //分页查询商品评论
    @GetMapping("getcomment/{id}/{page}/{size}")
    public R getComment(@PathVariable Integer id,
                        @PathVariable Integer page,
                        @PathVariable Integer size) {
        Page<Comment> comment = commentService.getComment(id, page, size);
        return R.ok().data("comments", comment.getRecords()).data("total", comment.getTotal());
    }

}

