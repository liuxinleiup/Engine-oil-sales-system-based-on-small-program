package com.biyesheji.costume.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.Coupon;
import com.biyesheji.costume.pojo.CouponUserRelation;
import com.biyesheji.costume.pojo.CouponVO;
import com.biyesheji.costume.pojo.User;
import com.biyesheji.costume.service.CouponService;
import com.biyesheji.costume.service.CouponUserRelationService;
import io.swagger.models.auth.In;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2022-05-04
 */
@RestController
@RequestMapping("/costume/coupon")
public class CouponController {

    @Autowired
    private CouponService couponService;
    @Autowired
    private CouponUserRelationService relationService;

    //查询已领取的优惠券
    @PostMapping("getAllCoupon/{uid}")
    public R getAllCoupon(@PathVariable String uid){
            //查询
            List<Coupon> coupons = couponService.conditionSearch(new Coupon(), 1, 1000).getRecords();
            coupons = couponService.packageData(coupons);

            //查询已领取优惠券
            List<Coupon> getCoupons = relationService.list(
                    new QueryWrapper<CouponUserRelation>().eq("user_id", uid)
            ).stream().map(item -> couponService.getById(item.getCouponId())).collect(Collectors.toList());

            List<CouponVO> data = new ArrayList<>();

            for (Coupon getCoupon : getCoupons) {
                CouponVO vo = new CouponVO();
                BeanUtils.copyProperties(getCoupon, vo);
                vo.setIsGet(false);
                data.add(vo);
            }
            return R.ok().data("coupons", data);
    }


    //添加优惠券
    @PostMapping("saveCoupon")
    public R saveCoupon(@RequestBody Coupon coupon) {
        couponService.save(coupon);
        return R.ok();
    }

    //删除优惠券
    @DeleteMapping("deleteByids")
    public R deleteByids(@RequestBody List<Integer> ids){
        couponService.removeByIds(ids);
        return R.ok();
    }


    //条件查询优惠券
    @PostMapping("conditionSearch/{page}/{size}")
    public R conditionSearch(@RequestBody Coupon coupon,
                             @PathVariable Integer page,
                             @PathVariable Integer size) {

        Page<Coupon> pageinfo = couponService.conditionSearch(coupon, page, size);
        return R.ok().data("total", pageinfo.getTotal()).data("rows", pageinfo.getRecords());
    }

    //查询该商品下的优惠券
    @PostMapping("getCouponBySpuid/{spuid}")
    public R getCouponBySpuid(@PathVariable Integer spuid) {
        List<Coupon> data = couponService.getCouponBySpuid(spuid);
        return R.ok().data("rows", data);
    }

    //用户查询优惠券
    @PostMapping("conditionSearch/{uid}")
    public R userConditionSearch(@PathVariable String uid) {
        List<CouponVO> data = couponService.userConditionSearch(uid);
        return R.ok().data("coupons",data);
    }

    //领取优惠券
    @PostMapping("getCoupon")
    public R getCoupon(@RequestBody CouponUserRelation relation) {

        relationService.getCoupon(relation);

        return R.ok();
    }
}

