package com.biyesheji.costume.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 优惠券与产品关联 前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2022-05-04
 */
@RestController
@RequestMapping("/costume/coupon-user-relation")
public class CouponUserRelationController {


    //查询该用户有否有优惠券


    //使用优惠券



}

