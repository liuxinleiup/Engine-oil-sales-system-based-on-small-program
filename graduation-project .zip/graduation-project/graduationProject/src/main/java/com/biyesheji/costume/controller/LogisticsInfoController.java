package com.biyesheji.costume.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.Address;
import com.biyesheji.costume.pojo.LogisticsInfo;
import com.biyesheji.costume.pojo.SpuInfo;
import com.biyesheji.costume.pojo.TOrder;
import com.biyesheji.costume.service.AddressService;
import com.biyesheji.costume.service.LogisticsInfoService;
import com.biyesheji.costume.service.TOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.Path;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 * 物流信息 前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2021-04-10
 */
@RestController
@RequestMapping("/costume/logistics-info")
public class LogisticsInfoController {

    @Autowired
    private TOrderService orderService;
    @Autowired
    private LogisticsInfoService infoService;
    @Autowired
    private AddressService addressService;


    //物流公司查询可接订单
    @GetMapping("queryAll/{pageIndex}/{size}")
    public R queryAll(@PathVariable Integer pageIndex, @PathVariable Integer size) {
        QueryWrapper<TOrder> wrapper = new QueryWrapper<>();
        wrapper.eq("ship_state", 0).eq("status", 1);
        Page<TOrder> page = new Page<>(pageIndex, size);
        orderService.page(page, wrapper);
        page.getRecords().forEach(item->{
            Address add = addressService.getById(item.getAddressId());
            item.setAddress(add);
        });
        return R.ok().data("data", page);
    }

    //查询已接订单
    @GetMapping("ordersReceived/{pageIndex}/{size}")
    public R ordersReceived(@PathVariable Integer pageIndex, @PathVariable Integer size) {
        QueryWrapper<TOrder> wrapper = new QueryWrapper<>();
        wrapper.eq("ship_state", 1).eq("status", 1);
        Page<TOrder> page = new Page<>(pageIndex, size);
        orderService.page(page, wrapper);
        page.getRecords().forEach(item->{
            Address add = addressService.getById(item.getAddressId());
            item.setAddress(add);
        });
        return R.ok().data("data", page);
    }

    //接单
    @GetMapping("receptionOrder/{orderNo}")
    public R receptionOrder(@PathVariable String orderNo) {
        //随机生成快递单号
        String uuid = UUID.randomUUID().toString();
        //修改
        TOrder order = new TOrder();
        order.setId(orderNo);
        order.setShipState(1);
        order.setTrackNum(uuid);
        orderService.updateById(order);
        //更新一次物流信息
        LogisticsInfo info = new LogisticsInfo();
        info.setUpdateTime(new Date());
        info.setDescription("快递公司已收货，待发送");
        info.setOrderNo(orderNo);
        info.setSorting(1);
        infoService.save(info);
        return R.ok();
    }

    //更新物流信息
    @PostMapping("updateInfo")
    public R updateInfo(@RequestBody LogisticsInfo info) {
        info.setUpdateTime(new Date());
        infoService.save(info);
        return R.ok();
    }

    //根据订单号查询物流信息
    @GetMapping("queryInfoById/{id}")
    public R queryInfoById(@PathVariable String id) {
        List<LogisticsInfo> list = infoService.list(
                new QueryWrapper<LogisticsInfo>()
                        .eq("order_no", id)
                        .orderByDesc("sorting")
        );
        return R.ok().data("list", list);
    }

    //根据订单号查询物流信息
    @DeleteMapping("removeInfo/{id}")
    public R removeInfo(@PathVariable Integer id) {
       infoService.removeById(id);
        return R.ok();
    }

}

