package com.biyesheji.costume.controller;

import com.biyesheji.costume.common.R;
import com.biyesheji.costume.service.OSService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/**
 * 文件上传控制器
 */
@RestController
@RequestMapping("/costume/file")
public class OSSController {

    @Autowired
    private OSService service;

    @PostMapping("upload")
    public R upload(MultipartFile file){
        System.out.println(file.getOriginalFilename()+"----------");
        String uploadUrl  = null;
        try {
            uploadUrl = service.upload(file);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return R.ok().data("url",uploadUrl);
    }

    //删除图片
    @DeleteMapping
    public R deleteFile(@RequestParam String fileUrl){
        service.deleteFile(fileUrl);
        return R.ok();
    }

}
