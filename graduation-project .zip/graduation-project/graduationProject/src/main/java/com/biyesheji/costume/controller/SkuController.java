package com.biyesheji.costume.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 库存单元表 前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2020-11-16
 */
@RestController
@RequestMapping("/costume/sku-info")
public class SkuController {



}

