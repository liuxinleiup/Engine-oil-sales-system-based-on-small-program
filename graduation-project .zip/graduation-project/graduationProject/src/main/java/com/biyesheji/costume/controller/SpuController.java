package com.biyesheji.costume.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.SpuImages;
import com.biyesheji.costume.pojo.SpuInfo;
import com.biyesheji.costume.pojo.SpuinfoVO;
import com.biyesheji.costume.service.SpuImagesService;
import com.biyesheji.costume.service.SpuInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.Path;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2020-11-15
 */
@RestController
@RequestMapping("/costume/spu-info")
public class SpuController {

    @Autowired
    private SpuInfoService spuInfoService;
    @Autowired
    private SpuImagesService imagesService;

    //保存spu信息
    @RequestMapping("saveSpuInfo")
    @ResponseBody
    public R saveSpuInfo(@RequestBody SpuInfo spuInfo){
        spuInfoService.saveSpuInfo(spuInfo);
        return R.ok();
    }

    //分页 条件查询spu
    @PostMapping("{page}/{size}")
    public R getSpuList(@RequestBody SpuInfo spuInfo,
                        @PathVariable Integer page,
                        @PathVariable Integer size){
        Page<SpuInfo> data = spuInfoService.getSpuList(spuInfo, page, size);
        return R.ok().data("rows", data.getRecords()).data("total", data.getTotal());
    }

    //根据ID查询
    @GetMapping("{id}")
    public R getById(@PathVariable String id){
        SpuInfo spuInfo = spuInfoService.getByIdSpu(id);
        try {
            spuInfo.setVisitor(spuInfo.getVisitor() + 1);
        }catch (Exception e){
            spuInfo.setVisitor(0);
        }
        spuInfoService.updateById(spuInfo);
        QueryWrapper<SpuImages> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("spu_id", spuInfo.getId());
        List<SpuImages> list = imagesService.list(queryWrapper);
        spuInfo.setImages(list);
        return R.ok().data("spuinfo", spuInfo);
    }


    //删除
    @DeleteMapping("{id}")
    public R deleteById(@PathVariable Integer id){
        spuInfoService.removeById(id);
        QueryWrapper<SpuImages> wrapper = new QueryWrapper<>();
        wrapper.eq("spu_id", id);
        imagesService.remove(wrapper);
        return R.ok();
    }

    //修改
    @PutMapping("updateSpu")
    public R updateSpu(@RequestBody SpuInfo spuInfo){
        spuInfoService.updateById(spuInfo);
        List<SpuImages> images = spuInfo.getImages();
        QueryWrapper<SpuImages> wrapper = new QueryWrapper<>();
        wrapper.eq("spu_id", spuInfo.getId());
        imagesService.remove(wrapper);
        images.forEach(item-> item.setSpuId(spuInfo.getId()));
        imagesService.saveBatch(images);
        return R.ok();
    }

    //获取推荐商品(随机4条数据)
    @GetMapping("recommendspu")
    public R getRecommendSpu(){
        List<SpuInfo> spus = spuInfoService.getRecommendSpu();
        return R.ok().data("spuinfos", spus);
    }

    //根据销量分页查询商品
    @GetMapping("bysales/{page}/{size}")
    public R bySales(@PathVariable Integer page, @PathVariable Integer size){
        List<SpuInfo> spus = spuInfoService.bySales(page, size);
        return R.ok().data("spuinfos", spus);
    }

    //根据价格（升序或降序）分页查询商品
    @GetMapping("byprice/{page}/{size}/{state}")
    public R byPrice(@PathVariable Integer page,
                     @PathVariable Integer size,
                     @PathVariable Integer state){
        List<SpuInfo> spus = spuInfoService.byPrice(page, size, state);
        return R.ok().data("spuinfos", spus);
    }

    //根据价格/时间/销量排序
    //2价格 3时间 4销量
    @GetMapping("sort/{type}/{page}/{size}")
    public R queryByType(@PathVariable Integer type,
                         @PathVariable Integer page,
                         @PathVariable Integer size){
        List<SpuInfo> list = null;
        if (type == 1){
            list = spuInfoService.getRecommendSpu();
        }else{
            list = spuInfoService.queryByType(type, page, size);
        }
        return R.ok().data("list", list);
    }



    //随机获取三个商品信息
    @GetMapping("random")
    public R random(){
        List<SpuInfo> list = spuInfoService.random();
        return R.ok().data("list", list);
    }


    //查询所有数据_根据分类查询
    @GetMapping("getAllByClassfiy")
    public R getAllByClassfiy(){
        List<SpuinfoVO> foodVOS = spuInfoService.getAllByClassfiy();
        return R.ok().data("list", foodVOS);
    }
}

