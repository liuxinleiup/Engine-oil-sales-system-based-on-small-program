package com.biyesheji.costume.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.common.MagicException;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.Address;
import com.biyesheji.costume.pojo.TOrder;
import com.biyesheji.costume.service.AddressService;
import com.biyesheji.costume.service.TOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 订单 前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2020-11-19
 */
@RestController
@RequestMapping("/costume/t-order")
public class TOrderController {

    @Autowired
    private TOrderService orderService;
    @Autowired
    private AddressService addressService;

    //创建订单
    @PostMapping("createOrder/{spuid}/{userid}/{aid}")
    public R saveOrder(@PathVariable Integer spuid,
                       @PathVariable String userid,
                       @PathVariable Integer aid) {
        //创建订单，返回订单号
        String orderNo = orderService.createOrders(spuid, userid, aid);
        return R.ok().data("orderId",orderNo);
    }
    //批量创建订单
    @PostMapping("batchCreateOrders")
    public R batchCreateOrders(@RequestBody List<TOrder> orders) {
        List<String> orderNos = new ArrayList<>();
        Address address = addressService.getDefaultAddress(orders.get(0).getMemberId());
        if (null == address) throw new MagicException(20001, "请添加默认收货地址");
        for (TOrder order : orders) {
            String orderNo = orderService.createOrders(order.getProductId(),
                    order.getMemberId(), address.getId());
            orderNos.add(orderNo);
        }
        return R.ok().data("nos", orderNos);
    }

    //根据订单号查询订单
    @PostMapping("getBatchOrder")
    public R getBatchOrder(@RequestBody List<String> nos) {

        List<TOrder> orders = new ArrayList<>();
        for (String no : nos) {
            TOrder order = orderService.getById(no);
            Address address = addressService.getById(order.getAddressId());
            order.setAddress(address);
            orders.add(order);
        }
        return R.ok().data("order", orders);
    }


    //分页多条件查询订单
    @PostMapping("conditionSearch/{page}/{size}")
    public R conditionSearch(@RequestBody TOrder order,
                             @PathVariable Integer page,
                             @PathVariable Integer size){
        Page<TOrder> orderPage = orderService.conditionSearch(order, page, size);
        return R.ok().data("total", orderPage.getTotal()).data("rows", orderPage.getRecords());
    }

    //查询订单
    @GetMapping("getOrderInfo/{orderId}")
    public R getOrderInfo(@PathVariable String orderId) {

        TOrder order = orderService.getById(orderId);
        //查询地址
        Address address = addressService.getById(order.getAddressId());
        order.setAddress(address);
        return R.ok().data("item",order);
    }

    //使用优惠券支付
    @PostMapping("pay/{orderNo}/{couponId}")
    public R payMentUseCoupon(@PathVariable String orderNo,
                     @PathVariable(required = false) Integer couponId){
        orderService.payMent(orderNo, couponId);
        return R.ok().message("支付成功");
    }

    //支付
    @PostMapping("pay/{orderNo}")
    public R payMent(@PathVariable String orderNo){
        orderService.payMent(orderNo);
        return R.ok().message("支付成功");
    }

    //查询待支付订单
    @GetMapping("penOrder/{uid}")
    public R penOrder(@PathVariable String uid){
        QueryWrapper<TOrder> wrapper = new QueryWrapper<>();
        wrapper.eq("member_id", uid).eq("status", 0);
        List<TOrder> list = orderService.list(wrapper);
        return R.ok().data("orders", list);
    }

    //发货
    @GetMapping("ship/{orderNo}/{trackNum}")
    public R ship(@PathVariable String orderNo, @PathVariable String trackNum){
        TOrder order = orderService.getById(orderNo);
        order.setShipState(1);
        order.setTrackNum(trackNum);
        orderService.updateById(order);
        return R.ok();
    }

    //确认收货
    @GetMapping("receipt/{orderNo}")
    public R receipt(@PathVariable String orderNo){
        TOrder order = orderService.getById(orderNo);
        order.setShipState(2);
        orderService.updateById(order);
        return R.ok();
    }

    //查询待发货订单
    @GetMapping("delivered/{uid}")
    public R delivered(@PathVariable String uid){
        QueryWrapper<TOrder> wrapper = new QueryWrapper<>();
        wrapper.eq("member_id", uid).eq("ship_state",0).eq("status",1);
        List<TOrder> list = orderService.list(wrapper);
        return R.ok().data("orders", list);
    }

    //查询待收货订单
    @GetMapping("received/{uid}")
    public R received(@PathVariable String uid){
        QueryWrapper<TOrder> wrapper = new QueryWrapper<>();
        wrapper.eq("member_id", uid).eq("ship_state",1).eq("status",1);
        List<TOrder> list = orderService.list(wrapper);
        return R.ok().data("orders", list);
    }

    //查询待评价商品
    @GetMapping("comment/{uid}")
    public R comment(@PathVariable String uid){
        QueryWrapper<TOrder> wrapper = new QueryWrapper<>();
        wrapper.eq("member_id", uid).eq("ship_state",2).eq("status",1);
        List<TOrder> list = orderService.list(wrapper);
        return R.ok().data("orders", list);
    }

    //查询已完成订单
    @GetMapping("alredyFinish/{uid}")
    public R alredyFinish(@PathVariable String uid){
        QueryWrapper<TOrder> wrapper = new QueryWrapper<>();
        wrapper.eq("member_id", uid).eq("ship_state",3).eq("status",1);
        List<TOrder> list = orderService.list(wrapper);
        return R.ok().data("orders", list);
    }

    //删除订单
    @DeleteMapping("{oid}")
    public R deleteById(@PathVariable String oid){
        orderService.removeById(oid);
        return R.ok();
    }
}

