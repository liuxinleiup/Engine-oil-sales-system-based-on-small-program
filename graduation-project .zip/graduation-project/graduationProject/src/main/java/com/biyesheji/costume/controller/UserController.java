package com.biyesheji.costume.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.User;
import com.biyesheji.costume.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author ${author}
 * @since 2020-11-16
 */
@RestController
@RequestMapping("/costume/user")
public class UserController {

    @Autowired
    private UserService userService;

    //根据ID查询
    @GetMapping("{userid}")
    public R getById(@PathVariable String userid){
        User user = userService.getById( userid );
        return R.ok().data("user", user);
    }

    //修改
    @PutMapping("updateinfo")
    public R updateUserInfo(@RequestBody User user){
//        userService.updateUserInfo(user);
        userService.updateById(user);
        return R.ok();
    }

    //删除学员信息
    @DeleteMapping("{userid}")
    public R deleteById(@PathVariable String userid){
        userService.removeById(userid);
        return R.ok();
    }

    //删除
    @DeleteMapping("deleteByids")
    public R deleteByids(@RequestBody List<String> ids){
        for (int i = 0; i < ids.size(); i++) {
            userService.removeById(ids.get(i));
        }
        return R.ok();
    }

    //多条件分页查询学员信息(admin)
    @PostMapping("conditionlist/{page}/{size}")
    public R conditionSearch(@RequestBody User user,
                             @PathVariable Integer page,
                             @PathVariable Integer size){
        Page<User> pageinfo = userService.conditionSearch(user, page, size);
        return R.ok().data("total", pageinfo.getTotal()).data("rows", pageinfo.getRecords());
    }

    //注册
    @PostMapping("register")
    public R register(@RequestBody User user){
        userService.register(user);
        return R.ok();
    }

}

