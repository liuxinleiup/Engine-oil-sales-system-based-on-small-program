package com.biyesheji.costume.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.biyesheji.costume.common.CostumeException;
import com.biyesheji.costume.common.MagicException;
import com.biyesheji.costume.common.R;
import com.biyesheji.costume.config.ConstantWxConfig;
import com.biyesheji.costume.pojo.User;
import com.biyesheji.costume.service.UserService;
import com.biyesheji.costume.utils.AesCbcUtil;
import com.biyesheji.costume.utils.HttpClientUtils;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;


@RestController  //只是请求地址，不需要返回数据
@RequestMapping("/costume/user/wx")
public class WxApiController {

    @Autowired
    private UserService userService;

//    /**
//     * 微信用户登录详情
//     */
//    @PostMapping("login")
//    public R login(@RequestBody JSONObject data) {
//        try {
//            //1 获取code值，临时票据，类似于验证码
//            String encryptedData = data.getString("encryptedData");
//            String iv = data.getString("iv");
//            String code = data.getString("code");
//
//            if (StringUtils.isEmpty(code)){
//                throw new CostumeException(20001, "凭证缺失");
//            }
//
//            //2 拿着code请求 微信固定的地址，得到两个值 accsess_token 和 openid
//            String baseAccessTokenUrl = "https://api.weixin.qq.com/sns/jscode2session" +
//                    "?appid=%s" +
//                    "&secret=%s" +
//                    "&js_code=%s" +
//                    "&grant_type=authorization_code";
//            //拼接三个参数 ：id  秘钥 和 code值
//            String accessTokenUrl = String.format(
//                    baseAccessTokenUrl,
//                    ConstantWxConfig.WX_OPEN_APP_ID,
//                    ConstantWxConfig.WX_OPEN_APP_SECRET,
//                    code
//            );
//
//            //发送请求获取session_key和openId
//            String SessionKeyOpenId = HttpClientUtils.get(accessTokenUrl);
//            Gson gson = new Gson();
//            HashMap mapAccessToken = gson.fromJson(SessionKeyOpenId, HashMap.class);
//            String session_key = (String)mapAccessToken.get("session_key");
//            String openid = (String)mapAccessToken.get("openid");
//
//            //把扫描人信息添加数据库里面
//            //判断数据表里面是否存在相同微信信息，根据openid判断
//            User user = userService.getOpenIdMember(openid);
//
//            if(user == null) {//user是空，表没有相同微信数据，进行添加
//                String result = AesCbcUtil.decrypt(encryptedData, session_key, iv, "UTF-8");
//                if (StringUtils.isEmpty(result)){
//                    throw new CostumeException(20001, "解密失败");
//                }
//                HashMap userInfoMap = gson.fromJson(result, HashMap.class);
//
//                System.out.println(userInfoMap);
//                user = new User();
//                user.setOpenid((String) userInfoMap.get("openId"));
//                user.setAvatar((String) userInfoMap.get("avatarUrl"));
//                user.setNickname((String) userInfoMap.get("nickName"));
//                user.setGmtCreate(new Date());
//
//                userService.save(user);
//            }
//            if (user != null) {
//                return R.ok().data("userinfo", user);
//            } else {
//                return R.error().message("用户名或密码错误！");
//            }
//        }catch(Exception e) {
//            e.printStackTrace();
//            throw new CostumeException(20001,"登录失败");
//        }
//    }


    //登陆
    @PostMapping("login")
    public R login(@RequestBody User user){
        user = userService.login(user);
        if (null == user){
            throw new MagicException(20001, "密码错误");
        }
        return R.ok().data("userinfo", user);
    }



}
