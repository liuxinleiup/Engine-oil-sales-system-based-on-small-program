package com.biyesheji.costume.controller.websocket;

import com.biyesheji.costume.common.R;
import com.biyesheji.costume.pojo.Message;
import com.biyesheji.costume.service.ChatService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/costume/chat")
public class ChatController {

    @Autowired
    private ChatService chatService;


    //获取聊天列表
    @PostMapping("loadChatList")
    public R loadChatList() {
        List<ChatListVO> listVOS = chatService.loadChatList();
        return R.ok().data("list", listVOS);
    }

    @Data
    public class ChatListVO {
        String avatar;
        String id;
        String name;
    }
}
