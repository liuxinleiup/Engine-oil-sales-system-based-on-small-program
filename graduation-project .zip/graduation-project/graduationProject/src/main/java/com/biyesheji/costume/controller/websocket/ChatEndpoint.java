package com.biyesheji.costume.controller.websocket;

import com.alibaba.fastjson.JSON;
import com.biyesheji.costume.pojo.ChatVO;
import com.biyesheji.costume.pojo.Message;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

//定义websocket服务器端
//每一个客户端都对应一个ChatEndpoint
@ServerEndpoint(value = "/chat/{userid}"/*, configurator = GetHttpsSessionConfig.class*/)
@Component//交给spring管理
public class ChatEndpoint {

    //  这里使用静态，让 service 属于类
    private static RedisTemplate redisTemplate;

    // 注入的时候，给类的 service 注入
    @Autowired
    public void setRedisTemplate(RedisTemplate redisTemplate) {
        ChatEndpoint.redisTemplate = redisTemplate;
    }

    //用来存储每一个客户端对象对应的ChatEndpoint对象
    private static Map<String, ChatEndpoint> onlineUsers = new ConcurrentHashMap<>();
    //申明session对象，通过该对象可以发送消息给指定的客户端
    private Session session;
    private String userid;

    //链接建立时执行
    @OnOpen
    public void onOpen(@PathParam("userid") String userid, Session session, EndpointConfig config) {
        //将局部的session对象给成员session
        this.userid = userid;
        this.session = session;
        onlineUsers.put(userid, this);


        //获取该用户在缓存中的消息和系统消息并删除
        List<Message> msgs = new ArrayList<>();
        String queryKey = "*" + "_" + userid+"*";
        Set<String> keys = redisTemplate.keys(queryKey);
        keys.forEach(key -> {
            Message message = JSON.parseObject(redisTemplate.opsForValue().get(key) + "", Message.class);
            msgs.add(message);
            redisTemplate.delete(key);
        });

        //向指定用户发送消息
        sendMsgByUid(userid, msgs);
    }

    //根据UID向用户推送消息
    public void sendMsgByUid(String uid, List<Message> msg) {
        try {
            ChatEndpoint endpoint = onlineUsers.get(uid);
            endpoint.session.getBasicRemote().sendText(JSON.toJSONString(msg));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * 接收到客户端发送的数据时调用
     * {
     * toUid 向某个用户发送
     * toUserName 向某个用户发送
     * fromUid 来自于某个用户
     * fromUserName 来自于某个用户
     * message 消息主体：字符串
     * }
     *
     * @param message
     * @param session
     * @throws IOException
     */
    @OnMessage
    public void onMessage(String message, Session session) throws IOException {
        Message msg = JSON.parseObject(message, Message.class);
        //000 代表后台发出
        String uid = msg.getToUid();
        //如果用户不在线则将消息存入缓存
        if (!onlineUsers.containsKey(uid)) {
            String key = msg.getFromUid()+"_"+msg.getToUid()+"|"+ RandomUtils.nextInt();
            redisTemplate.opsForValue().set(key, JSON.toJSON(message));
            return;
        }
        ArrayList<Message> arrayList = new ArrayList<>();
        arrayList.add(msg);
        sendMsgByUid(uid, arrayList);
    }

    //链接关闭时执行
    @OnClose
    public void onClose(Session session) {
        //移除用户
        onlineUsers.remove(userid);
    }

    @OnError
    public void onError(Session session, Throwable error) {
        System.out.println("服务端发生了错误" + error.getMessage());
        error.printStackTrace();
    }

}
