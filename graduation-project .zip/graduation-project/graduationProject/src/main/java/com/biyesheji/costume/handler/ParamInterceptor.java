package com.biyesheji.costume.handler;

import com.biyesheji.costume.common.CostumeException;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ParamInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        String token = httpServletRequest.getHeader("token");
        //token验证
        if (StringUtils.isEmpty(token)){
            throw new CostumeException(20001, "非法操作，缺失令牌");
        }
//        JwtUtil jwtUtil = new JwtUtil();
//        if (  jwtUtil.parseJWT(token).getSubject().equals("rubik_admin") || jwtUtil.parseJWT(token).getSubject().equals("rubik_user") ){
//            return true;
//        }
        throw new CostumeException(20001, "非法操作，缺失令牌");
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }

}
