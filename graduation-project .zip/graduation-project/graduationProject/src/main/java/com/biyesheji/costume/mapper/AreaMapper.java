package com.biyesheji.costume.mapper;

import com.biyesheji.costume.pojo.Area;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2020-11-16
 */
public interface AreaMapper extends BaseMapper<Area> {

}
