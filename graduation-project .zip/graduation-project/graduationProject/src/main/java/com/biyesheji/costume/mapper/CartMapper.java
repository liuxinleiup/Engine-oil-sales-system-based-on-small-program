package com.biyesheji.costume.mapper;

import com.biyesheji.costume.pojo.Cart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2020-11-21
 */
public interface CartMapper extends BaseMapper<Cart> {

}
