package com.biyesheji.costume.mapper;

import com.biyesheji.costume.pojo.Coupon;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2022-05-04
 */
public interface CouponMapper extends BaseMapper<Coupon> {

}
