package com.biyesheji.costume.mapper;

import com.biyesheji.costume.pojo.CouponUserRelation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 优惠券与产品关联 Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2022-05-04
 */
public interface CouponUserRelationMapper extends BaseMapper<CouponUserRelation> {

}
