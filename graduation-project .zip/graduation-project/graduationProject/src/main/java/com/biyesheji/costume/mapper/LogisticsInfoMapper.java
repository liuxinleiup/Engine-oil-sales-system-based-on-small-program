package com.biyesheji.costume.mapper;

import com.biyesheji.costume.pojo.LogisticsInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 物流信息 Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2021-04-10
 */
public interface LogisticsInfoMapper extends BaseMapper<LogisticsInfo> {

}
