package com.biyesheji.costume.mapper;

import com.biyesheji.costume.pojo.SpuInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2020-11-15
 */
public interface SpuInfoMapper extends BaseMapper<SpuInfo> {

    @Select("SELECT * FROM spu_info ORDER BY RAND() LIMIT 10")
    List<SpuInfo> randData();

    @Select(value = "SELECT * FROM spu_info ORDER BY RAND() LIMIT 6")
    List<SpuInfo> random();
}
