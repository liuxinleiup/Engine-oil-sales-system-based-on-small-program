package com.biyesheji.costume.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class ChatVO {


    /**
     * username : 七月
     * avatar : https://himg.bdimg.com/sys/portraitn/item/88d47762616b7362779bb1
     * id : 1331050342991654913
     * content : 1
     * mine : true
     * fromUid : 000
     * timestamp : 2021-02-14T02:18:14.046Z
     */

    @JsonProperty("username")
    private String username;
    @JsonProperty("avatar")
    private String avatar;
    @JsonProperty("id")
    private String id;
    @JsonProperty("content")
    private String content;
    @JsonProperty("mine")
    private Boolean mine;
    @JsonProperty("fromUid")
    private String fromUid;
    @JsonProperty("timestamp")
    private String timestamp;
}
