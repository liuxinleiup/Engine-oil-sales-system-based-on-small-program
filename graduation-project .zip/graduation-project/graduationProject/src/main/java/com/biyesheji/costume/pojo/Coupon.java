package com.biyesheji.costume.pojo;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.IdType;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author ${author}
 * @since 2022-05-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "Coupon对象", description = "")
public class Coupon implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "显示类型")
    private String showType;

    @ApiModelProperty(value = "优惠券名称")
    private String couponName;

    @ApiModelProperty(value = "优惠券数量")
    private Integer num;

    @ApiModelProperty(value = "金额")
    private BigDecimal amount;

    @ApiModelProperty(value = "使用门槛")
    private BigDecimal minPoint;

    @ApiModelProperty(value = "备注")
    private String note;

    @ApiModelProperty(value = "可以领取的开始日期")
    private String enableStartTime;

    @ApiModelProperty(value = "可以领取的结束日期")
    private String enableEndTime;

    @ApiModelProperty(value = "使用类型[0->全场通用；1->指定分类；2->指定商品]")
    private Integer useType;


    //商品ID
    private Integer spuid;
    @TableField(exist = false)
    private SpuInfo spuInfo;

    //分类ID
    private Integer cid;
    @TableField(exist = false)
    private Category category;


}
