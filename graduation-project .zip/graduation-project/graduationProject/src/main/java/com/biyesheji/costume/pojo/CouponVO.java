package com.biyesheji.costume.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CouponVO {


    private Integer id;

    private String showType;

    private String couponName;

    private Integer num;

    private BigDecimal amount;

    private BigDecimal minPoint;

    private String note;

    private String enableStartTime;

    private String enableEndTime;

    private Integer useType;

    private SpuInfo spuInfo;

    private Category category;

    private Boolean isGet;


}
