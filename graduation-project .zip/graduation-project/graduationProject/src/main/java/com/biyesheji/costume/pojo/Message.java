package com.biyesheji.costume.pojo;

import lombok.Data;

@Data
public class Message {

    //谁发送的
    String fromUid;
    //发送给谁
    String toUid;
    //消息主体
    String msg;
    //头像
    String avatar;
    String name;
}
