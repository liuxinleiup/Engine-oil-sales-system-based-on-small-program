package com.biyesheji.costume.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author ${author}
 * @since 2020-11-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SpuInfo对象", description="")
public class SpuInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    Integer visitor;

    private String productName;

    private String detail;

    private Integer categoryId;

    private Integer patternId;

    private Integer areaId;

    private String typeName;

    private BigDecimal price;

    private Integer sales;

    private Integer stock;

    //是否上架 0 否 1 是
    private Boolean isputaway;//是否上架

    //默认图片
    private Date createTime;

    //默认图片
    private String image;

    //图片集合
    @TableField(exist = false)
    private List<SpuImages> images;



}
