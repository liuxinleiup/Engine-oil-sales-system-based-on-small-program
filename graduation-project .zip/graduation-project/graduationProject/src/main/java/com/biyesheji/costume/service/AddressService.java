package com.biyesheji.costume.service;

import com.biyesheji.costume.pojo.Address;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-19
 */
public interface AddressService extends IService<Address> {

    Address getDefaultAddress(String uid);
}
