package com.biyesheji.costume.service;

import com.biyesheji.costume.pojo.Cart;
import com.baomidou.mybatisplus.extension.service.IService;
import com.biyesheji.costume.pojo.SpuInfo;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-21
 */
public interface CartService extends IService<Cart> {

    void saveCart(String uid, Integer spuid);

    List<Cart> queryCart(String uid);
}
