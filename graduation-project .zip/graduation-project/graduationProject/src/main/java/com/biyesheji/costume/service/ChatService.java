package com.biyesheji.costume.service;

import com.biyesheji.costume.controller.websocket.ChatController;
import com.biyesheji.costume.pojo.Message;
import com.biyesheji.costume.pojo.User;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ChatService {

    public static final String KEY = "ms_";

    @Autowired
    private StringRedisTemplate redisTemplate;
    @Autowired
    private UserService userService;


    public List<ChatController.ChatListVO> loadChatList() {
        Set<String> keys = redisTemplate.keys("*" + "000" + "*");
        Set<String> ids = keys.stream()
                .map(k -> k.split("_")[0])
                .collect(Collectors.toSet());
        //分装VO对象
        List<User> users = (List<User>) userService.listByIds(ids);
        List<ChatController.ChatListVO> finalData = new ArrayList<>();
        users.forEach(k -> {
            ChatController.ChatListVO vo = new ChatController().new ChatListVO();
            BeanUtils.copyProperties(k, vo);
            vo.setId(k.getId());
            vo.setName(k.getNickname());
            finalData.add(vo);
        });
        return finalData;
    }
}
