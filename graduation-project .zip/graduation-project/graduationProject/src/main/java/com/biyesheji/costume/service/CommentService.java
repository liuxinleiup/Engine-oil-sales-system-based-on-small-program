package com.biyesheji.costume.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.pojo.Comment;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-19
 */
public interface CommentService extends IService<Comment> {

    Page<Comment> getComment(Integer id, Integer page, Integer size);
}
