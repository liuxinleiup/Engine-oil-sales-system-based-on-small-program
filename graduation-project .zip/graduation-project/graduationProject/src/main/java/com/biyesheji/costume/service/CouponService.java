package com.biyesheji.costume.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.pojo.Coupon;
import com.baomidou.mybatisplus.extension.service.IService;
import com.biyesheji.costume.pojo.CouponVO;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ${author}
 * @since 2022-05-04
 */
public interface CouponService extends IService<Coupon> {
    List<Coupon> packageData(List<Coupon> coupons);
    Page<Coupon> conditionSearch(Coupon coupon, Integer page, Integer size);

    List<CouponVO> userConditionSearch(String uid);

    List<Coupon> getCouponBySpuid(Integer spuid);
}
