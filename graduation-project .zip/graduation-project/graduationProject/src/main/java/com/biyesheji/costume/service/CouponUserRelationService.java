package com.biyesheji.costume.service;

import com.biyesheji.costume.pojo.CouponUserRelation;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 优惠券与产品关联 服务类
 * </p>
 *
 * @author ${author}
 * @since 2022-05-04
 */
public interface CouponUserRelationService extends IService<CouponUserRelation> {

    void getCoupon(CouponUserRelation relation);
}
