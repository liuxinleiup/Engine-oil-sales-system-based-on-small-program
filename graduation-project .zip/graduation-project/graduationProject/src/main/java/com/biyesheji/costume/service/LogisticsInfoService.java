package com.biyesheji.costume.service;

import com.biyesheji.costume.pojo.LogisticsInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 物流信息 服务类
 * </p>
 *
 * @author ${author}
 * @since 2021-04-10
 */
public interface LogisticsInfoService extends IService<LogisticsInfo> {

}
