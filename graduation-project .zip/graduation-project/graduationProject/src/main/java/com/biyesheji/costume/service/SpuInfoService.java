package com.biyesheji.costume.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.pojo.SpuInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.biyesheji.costume.pojo.SpuinfoVO;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-15
 */
public interface SpuInfoService extends IService<SpuInfo> {

    void saveSpuInfo(SpuInfo spuInfo);

    Page<SpuInfo> getSpuList(SpuInfo spuInfo, Integer page, Integer size);

    SpuInfo getByIdSpu(String id);

    List<SpuInfo> getRecommendSpu();

    List<SpuInfo> bySales(Integer page, Integer size);

    List<SpuInfo> byPrice(Integer page, Integer size, Integer state);

    List<SpuInfo> queryByType(Integer type, Integer page, Integer size);

    List<SpuInfo> random();

    List<SpuinfoVO> getAllByClassfiy();
}
