package com.biyesheji.costume.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.pojo.TOrder;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 订单 服务类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-19
 */
public interface TOrderService extends IService<TOrder> {

    String createOrders(Integer spuid, String userid, Integer aid);

    void payMent(String orderNo, Integer couponId);

    void payMent(String orderNo);

    Page<TOrder> conditionSearch(TOrder order, Integer page, Integer size);
}
