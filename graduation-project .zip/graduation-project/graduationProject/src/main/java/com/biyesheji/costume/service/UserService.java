package com.biyesheji.costume.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.pojo.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-16
 */
public interface UserService extends IService<User> {

    User getOpenIdMember(String openid);

    void updateUserInfo(User user);

    Page<User> conditionSearch(User user, Integer page, Integer size);

    User login(User user);

    void register(User user);
}
