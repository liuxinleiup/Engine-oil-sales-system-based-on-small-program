package com.biyesheji.costume.service.impl;

import com.biyesheji.costume.pojo.Area;
import com.biyesheji.costume.mapper.AreaMapper;
import com.biyesheji.costume.service.AreaService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-16
 */
@Service
public class AreaServiceImpl extends ServiceImpl<AreaMapper, Area> implements AreaService {

}
