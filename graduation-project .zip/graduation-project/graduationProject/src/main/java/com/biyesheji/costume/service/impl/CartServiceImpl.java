package com.biyesheji.costume.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.biyesheji.costume.common.CostumeException;
import com.biyesheji.costume.pojo.Cart;
import com.biyesheji.costume.mapper.CartMapper;
import com.biyesheji.costume.pojo.SpuImages;
import com.biyesheji.costume.pojo.SpuInfo;
import com.biyesheji.costume.pojo.User;
import com.biyesheji.costume.service.CartService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.biyesheji.costume.service.SpuImagesService;
import com.biyesheji.costume.service.SpuInfoService;
import com.biyesheji.costume.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-21
 */
@Service
public class CartServiceImpl extends ServiceImpl<CartMapper, Cart> implements CartService {

    @Autowired
    private SpuImagesService imagesService;
    @Autowired
    private SpuInfoService spuInfoService;
    @Autowired
    private UserService userService;

    @Override
    public void saveCart(String uid, Integer spuid) {
        Cart cart = new Cart(uid, spuid);
        QueryWrapper<Cart> wrapper = new QueryWrapper<>();
        wrapper.eq("userid", uid).eq("spuid", spuid);
        Cart temp = getOne(wrapper);
        if (null != temp){
            throw new CostumeException(20001, "已添加，请勿重复添加");
        }
        save(cart);
    }

    @Override
    public List<Cart> queryCart(String uid) {
        QueryWrapper<Cart> wrapper = new QueryWrapper<>();
        wrapper.eq("userid", uid);
        List<Cart> list = list(wrapper);

//        List<SpuInfo> spuInfos = new ArrayList<>();
//        list.forEach( item->{
//            SpuInfo spuInfo = spuInfoService.getById(item.getSpuid());
//
//            QueryWrapper<SpuImages> queryWrapper = new QueryWrapper<>();
//            queryWrapper.eq("spu_id", spuInfo.getId());
//            List<SpuImages> images = imagesService.list(queryWrapper);
//            spuInfo.setImages(images);
//
//            spuInfos.add(spuInfo);
//        });
//        return spuInfos;

        list.forEach(v->{
            User user = userService.getById(v.getUserid());
            SpuInfo spuInfo = spuInfoService.getById(v.getSpuid());
            v.setUser(user);
            v.setSpuInfo(spuInfo);
        });
        return list;

    }
}
