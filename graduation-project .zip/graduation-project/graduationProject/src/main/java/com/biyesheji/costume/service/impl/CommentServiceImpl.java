package com.biyesheji.costume.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.pojo.Comment;
import com.biyesheji.costume.mapper.CommentMapper;
import com.biyesheji.costume.service.CommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-19
 */
@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements CommentService {

    @Override
    public Page<Comment> getComment(Integer id, Integer page, Integer size) {

        QueryWrapper<Comment> wrapper = new QueryWrapper<>();
        wrapper.eq("spu_id", id);
        Page<Comment> commentPage = new Page<>(page, size);
        page(commentPage, wrapper);
        commentPage.getRecords().forEach( item->{
            String json = item.getPhotos();
            List<String> images = JSON.parseArray(json, String.class);
            item.setImages(images);
        });
        return commentPage;
    }
}
