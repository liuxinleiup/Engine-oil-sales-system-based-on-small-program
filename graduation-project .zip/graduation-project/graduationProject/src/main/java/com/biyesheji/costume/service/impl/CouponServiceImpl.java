package com.biyesheji.costume.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.pojo.*;
import com.biyesheji.costume.mapper.CouponMapper;
import com.biyesheji.costume.service.CategoryService;
import com.biyesheji.costume.service.CouponService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.biyesheji.costume.service.CouponUserRelationService;
import com.biyesheji.costume.service.SpuInfoService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2022-05-04
 */
@Service
public class CouponServiceImpl extends ServiceImpl<CouponMapper, Coupon> implements CouponService {

    @Autowired
    private SpuInfoService spuInfoService;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private CouponUserRelationService relationService;


    @Override
    public List<CouponVO> userConditionSearch(String uid) {
        //查询
        List<Coupon> coupons = conditionSearch(new Coupon(), 1, 1000).getRecords();
        coupons = packageData(coupons);

        //查询已领取优惠券
        List<Coupon> getCoupons = relationService.list(
                new QueryWrapper<CouponUserRelation>().eq("user_id", uid)
        ).stream().map(item -> getById(item.getCouponId())).collect(Collectors.toList());

        List<CouponVO> data = new ArrayList<>();

        for (Coupon coupon : coupons) {
            CouponVO vo = new CouponVO();
            BeanUtils.copyProperties(coupon, vo);
            vo.setIsGet(false);
            data.add(vo);
        }

        for (CouponVO vo : data) {
            for (Coupon getCoupon : getCoupons) {
                if (vo.getId() == getCoupon.getId()) {
                    //此优惠券已经被领取
                    vo.setIsGet(true);
                }
            }
        }

        return data;
    }


    @Override
    public Page<Coupon> conditionSearch(Coupon coupon, Integer cur_page, Integer size) {

        QueryWrapper<Coupon> wrapper = new QueryWrapper<>();
        if (!StringUtils.isEmpty(coupon.getCouponName())) {
            wrapper.like("coupon_name", coupon.getCouponName());
        }

        wrapper.eq(null != coupon.getUseType(), "use_type", coupon.getUseType()).or();


        wrapper.gt("num", 0);
        Page<Coupon> page = new Page<>(cur_page, size);
        page(page, wrapper);
        page.setRecords(packageData(page.getRecords()));

        return page;

    }

    @Override
   public List<Coupon> packageData(List<Coupon> coupons) {
        return coupons.stream().map(item -> {
            if (item.getUseType() == 1) {
                Category category = categoryService.getById(item.getCid());
                item.setCategory(category);
            }

            if (item.getUseType() == 2) {
                SpuInfo spuInfo = spuInfoService.getById(item.getSpuid());
                item.setSpuInfo(spuInfo);
            }

            return item;
        }).collect(Collectors.toList());
    }


    @Override
    public List<Coupon> getCouponBySpuid(Integer spuid) {
        List<Coupon> data = new ArrayList<>();
        List<Coupon> all = list(null);
        SpuInfo spuInfo = spuInfoService.getById(spuid);

        data = all.stream().filter(item -> {
            //通用优惠券
            if (item.getUseType() == 0) {
                return true;
            } else {
                //此商品的分类优惠券
                if (null != item.getCid())
                    if (item.getCid() == spuInfo.getCategoryId()) {
                        return true;
                    }

                if (item.getSpuid() == spuid) {
                    return true;
                }
            }
            return false;
        }).collect(Collectors.toList());

        return data;
    }


}
