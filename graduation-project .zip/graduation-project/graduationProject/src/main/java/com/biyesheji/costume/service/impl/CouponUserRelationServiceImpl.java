package com.biyesheji.costume.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.biyesheji.costume.common.CostumeException;
import com.biyesheji.costume.pojo.Coupon;
import com.biyesheji.costume.pojo.CouponUserRelation;
import com.biyesheji.costume.mapper.CouponUserRelationMapper;
import com.biyesheji.costume.service.CouponService;
import com.biyesheji.costume.service.CouponUserRelationService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 优惠券与产品关联 服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2022-05-04
 */
@Service
public class CouponUserRelationServiceImpl extends ServiceImpl<CouponUserRelationMapper, CouponUserRelation> implements CouponUserRelationService {

    @Autowired
    private CouponService couponService;

    @Override
    @Transactional
    public void getCoupon(CouponUserRelation relation) {
        //查询是否已经领取
        QueryWrapper<CouponUserRelation> wrapper = new QueryWrapper<>();
        wrapper.eq("coupon_id", relation.getCouponId());
        wrapper.eq("user_id", relation.getUserId());

        CouponUserRelation one = getOne(wrapper);
        if (null != one){
            throw new CostumeException(20001, "该优惠券已经领取");
        }

        //查询是否数量足够
        Coupon coupon = couponService.getById(relation.getCouponId());
        if (coupon.getNum() <= 0){
            throw new CostumeException(20001, "该优惠券已被领取完毕");
        }

        save(relation);

        coupon.setNum(coupon.getNum()-1);
        couponService.updateById(coupon);

    }
}
