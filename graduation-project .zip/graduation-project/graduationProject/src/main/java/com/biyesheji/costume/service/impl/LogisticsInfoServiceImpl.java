package com.biyesheji.costume.service.impl;

import com.biyesheji.costume.pojo.LogisticsInfo;
import com.biyesheji.costume.mapper.LogisticsInfoMapper;
import com.biyesheji.costume.service.LogisticsInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 物流信息 服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2021-04-10
 */
@Service
public class LogisticsInfoServiceImpl extends ServiceImpl<LogisticsInfoMapper, LogisticsInfo> implements LogisticsInfoService {

}
