package com.biyesheji.costume.service.impl;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.PutObjectRequest;
import com.biyesheji.costume.config.ConstPropertiesConfig;
import com.biyesheji.costume.service.OSService;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

@Service
public class OSServiceImpl implements OSService {

    @Override
    public String upload(MultipartFile file) throws IOException {
        // Endpoint以杭州为例，其它Region请按实际情况填写。
        String endpoint = ConstPropertiesConfig.END_POINT;
        String accessKeyId = ConstPropertiesConfig.ACCESS_KEY_ID;
        String accessKeySecret = ConstPropertiesConfig.ACCESS_KEY_SECRET;
        String buacktName = ConstPropertiesConfig.BUCKET_NAME;
        String uploadUrl = null;

        // 创建OSSClient实例。
        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);

        String filename = new Date().getTime() + file.getOriginalFilename();
        InputStream inputStream = file.getInputStream();

        // 创建PutObjectRequest对象。
        PutObjectRequest putObjectRequest = new PutObjectRequest(buacktName, filename,
                inputStream);

        // 上传文件。
        ossClient.putObject(putObjectRequest);

        // 关闭OSSClient
        ossClient.shutdown();

        uploadUrl = "http://" + buacktName + "." + endpoint + "/" + filename;
        return uploadUrl;
    }

    @Override
    public void deleteFile(String fileUrl) {
        OSS client = new OSSClientBuilder().build(ConstPropertiesConfig.END_POINT,
                ConstPropertiesConfig.ACCESS_KEY_ID,
                ConstPropertiesConfig.ACCESS_KEY_SECRET);
        client.deleteObject(ConstPropertiesConfig.BUCKET_NAME, fileUrl.substring( fileUrl.lastIndexOf('/')+1)  );
        client.shutdown();
    }

}
