package com.biyesheji.costume.service.impl;

import com.biyesheji.costume.pojo.SpuImages;
import com.biyesheji.costume.mapper.SpuImagesMapper;
import com.biyesheji.costume.service.SpuImagesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-16
 */
@Service
public class SpuImagesServiceImpl extends ServiceImpl<SpuImagesMapper, SpuImages> implements SpuImagesService {

}
