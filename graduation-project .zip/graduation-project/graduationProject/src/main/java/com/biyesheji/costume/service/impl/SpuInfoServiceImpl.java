package com.biyesheji.costume.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.pojo.Category;
import com.biyesheji.costume.pojo.SpuImages;
import com.biyesheji.costume.pojo.SpuInfo;
import com.biyesheji.costume.mapper.SpuInfoMapper;
import com.biyesheji.costume.pojo.SpuinfoVO;
import com.biyesheji.costume.service.CategoryService;
import com.biyesheji.costume.service.SpuImagesService;
import com.biyesheji.costume.service.SpuInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-15
 */
@Service
public class SpuInfoServiceImpl extends ServiceImpl<SpuInfoMapper, SpuInfo> implements SpuInfoService {

    @Autowired
    private SpuImagesService imagesService;

    @Autowired
    private CategoryService categoryService;


    //保存
    @Override
    @Transactional
    public void saveSpuInfo(SpuInfo spuInfo) {

        spuInfo.setCreateTime(new Date());

        //默认图片
        spuInfo.setImage(spuInfo.getImages().get(0).getPhotoUrl());

        //查询分类
        Category category = categoryService.getById(spuInfo.getCategoryId());

        spuInfo.setTypeName(category.getCatelogName());

        spuInfo.setVisitor(0);

        // 保存商品信息
        save(spuInfo);

        // 生成商品主键
        Integer spuId = spuInfo.getId();

        // 保存商品图片信息
        List<SpuImages> spuImageList = spuInfo.getImages();
        for (SpuImages spuImage : spuImageList) {
            spuImage.setSpuId(spuId);
            imagesService.save(spuImage);
        }
    }

    //分页条件查询spu
    @Override
    public Page<SpuInfo> getSpuList(SpuInfo spuInfo, Integer pageIndex, Integer size) {
        QueryWrapper<SpuInfo> wrapper = new QueryWrapper<>();
        if ( !StringUtils.isEmpty( spuInfo.getProductName() ) ){
            wrapper.like("product_name", spuInfo.getProductName());
        }
        if ( null != spuInfo.getCategoryId() ){
            wrapper.eq("category_id", spuInfo.getCategoryId());
        }
        if ( spuInfo.getIsputaway() != null ){
            wrapper.eq("isputaway", spuInfo.getIsputaway());
        }
        if ( null !=  spuInfo.getAreaId() ){
            wrapper.eq("area_id", spuInfo.getAreaId());
        }
        Page<SpuInfo> page = new Page<>(pageIndex, size);

        page.getRecords().forEach( item->{
            //查询图片集合
            Integer spuId = item.getId();
            QueryWrapper<SpuImages> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("spu_id", spuId);
            List<SpuImages> list = imagesService.list(queryWrapper);
            item.setImages(list);
        });

        page(page, wrapper);
        return page;
    }

    @Override
    public SpuInfo getByIdSpu(String id) {
        SpuInfo spuInfo = getById(id);
        QueryWrapper<SpuImages> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("spu_id", spuInfo.getId());
        List<SpuImages> list = imagesService.list(queryWrapper);
        spuInfo.setImages(list);
        spuInfo.setTypeName(categoryService.getById(spuInfo.getCategoryId()).getCatelogName());
        return spuInfo;
    }

    //推荐（随机返回四条数据）
    @Override
    public List<SpuInfo> getRecommendSpu() {
        List<SpuInfo> spuInfos = baseMapper.randData();
        packPicture(spuInfos);
        return spuInfos;
    }

    @Override
    public List<SpuInfo> bySales(Integer page, Integer size) {
        QueryWrapper<SpuInfo> wrapper = new QueryWrapper<>();
        wrapper.orderByDesc("sales");
        List<SpuInfo> spuInfos = list(wrapper);
        packPicture(spuInfos);
        return spuInfos;
    }

    @Override
    public List<SpuInfo> byPrice(Integer page, Integer size, Integer state) {
        QueryWrapper<SpuInfo> wrapper = new QueryWrapper<>();
        if (state == 0){
            wrapper.orderByDesc("price");
        }else{
            wrapper.orderByAsc("price");
        }
        List<SpuInfo> spuInfos = list(wrapper);
        packPicture(spuInfos);
        return spuInfos;
    }

    @Override
    public List<SpuInfo> queryByType(Integer type, Integer cur_page, Integer size) {
        List<SpuInfo> foods = null;

        //1价格 2时间 3销量
        QueryWrapper<SpuInfo> wrapper = new QueryWrapper<>();
        Page<SpuInfo> page = new Page<>(cur_page, size);

        switch (type) {
            case 2:
                wrapper.orderByDesc("price");
                break;
            case 3:
                wrapper.orderByDesc("create_time");
                break;
            case 4:
                wrapper.orderByDesc("sales");
                break;
        }
        foods = page(page, wrapper).getRecords();
        return foods;
    }

    @Override
    public List<SpuInfo> random() {
        return baseMapper.random();
    }

    @Override
    public List<SpuinfoVO> getAllByClassfiy() {
        List<SpuinfoVO> foodVOS = new ArrayList<>();
        //查询所有分类
        List<Category> classfiys = categoryService.list(null);
        List<SpuInfo> spuInfos = baseMapper.selectList(null);

        for (int i = 0; i < classfiys.size(); i++) {
            SpuinfoVO vo = new SpuinfoVO();
            vo.setName(classfiys.get(i).getCatelogName());
            List<SpuInfo> data = new ArrayList();
            for (int j = 0; j < spuInfos.size(); j++) {
                if (classfiys.get(i).getId() == spuInfos.get(j).getCategoryId()){
                    data.add(spuInfos.get(j));
                }
            }
            vo.setSpuInfos(data);
            foodVOS.add(vo);
        }
        return foodVOS;
    }

    //封装图片
    private void packPicture(List<SpuInfo> spuInfos){
        spuInfos.forEach(item->{
            QueryWrapper<SpuImages> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("spu_id", item.getId());
            List<SpuImages> list = imagesService.list(queryWrapper);
            item.setImages(list);
        });
    }
}
