package com.biyesheji.costume.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.common.CostumeException;
import com.biyesheji.costume.pojo.*;
import com.biyesheji.costume.mapper.TOrderMapper;
import com.biyesheji.costume.service.*;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.biyesheji.costume.utils.OrderNoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 订单 服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-19
 */
@Service
public class TOrderServiceImpl extends ServiceImpl<TOrderMapper, TOrder> implements TOrderService {

    @Autowired
    private UserService userService;
    @Autowired
    private SpuInfoService spuinfoService;
    @Autowired
    private AddressService addressService;
    @Autowired
    private TOrderService orderService;
    @Autowired
    private CouponService couponService;
    @Autowired
    private CouponUserRelationService relationService;

    @Override
    public String createOrders(Integer spuid, String userid, Integer aid) {
        User userInfoOrder = userService.getById(userid);

        SpuInfo productfoPro = spuinfoService.getById(spuid);

        //判断库存
        if (productfoPro.getStock() == 0) {
            throw new CostumeException(20001, "没货啦~！");
        }

        //创建Order对象，向order对象里面设置需要数据
        TOrder order = new TOrder();
        order.setGmtCreate(new Date());
        order.setOrderNo(OrderNoUtil.getOrderNo());//订单号
        order.setProductId(spuid); //商品id
        order.setProductName(productfoPro.getProductName());
        order.setProductCover(productfoPro.getImage());
        order.setTotalFee(productfoPro.getPrice());
        order.setMemberId(userid);
        order.setAddressId(aid);

        order.setNickname(userInfoOrder.getNickname());
        order.setStatus(0);  //订单状态（0：未支付 1：已支付）
        order.setShipState(0);
        baseMapper.insert(order);

        //减少库存
        productfoPro.setStock(productfoPro.getStock() - 1);
        spuinfoService.updateById(productfoPro);

        //返回订单号
        return order.getId();
    }

    //支付
    @Override
    @Transactional
    public void payMent(String orderNo, Integer couponId) {
        TOrder order = orderService.getById(orderNo);
        order.setStatus(1);
        order.setShipState(0);
        BigDecimal money = order.getTotalFee().subtract(cheapMoney(couponId));
        User user = userService.getById(order.getMemberId());
        BigDecimal userMoney = user.getMoney();
        if (userMoney.subtract(money).intValue() < 0) {
            throw new CostumeException(20001, "余额不足，购买失败");
        }
        user.setMoney(userMoney.subtract(money));
        userService.updateById(user);

        SpuInfo spuInfo = spuinfoService.getById(order.getProductId());
        spuInfo.setStock(spuInfo.getStock() - 1);
        spuInfo.setSales(spuInfo.getSales() + 1);
        spuinfoService.updateById(spuInfo);
        orderService.updateById(order);

        //扣除优惠券
        if (null != couponId) {
            relationService.remove(
                    new QueryWrapper<CouponUserRelation>().eq("coupon_id",couponId)
                            .eq("user_id", order.getMemberId())
            );
        }

    }

    @Override
    public void payMent(String orderNo) {
        TOrder order = orderService.getById(orderNo);
        order.setStatus(1);
        order.setShipState(0);
        BigDecimal money = order.getTotalFee();
        User user = userService.getById(order.getMemberId());
        BigDecimal userMoney = user.getMoney();
        if (userMoney.subtract(money).intValue() < 0) {
            throw new CostumeException(20001, "余额不足，购买失败");
        }
        user.setMoney(userMoney.subtract(money));
        userService.updateById(user);

        SpuInfo spuInfo = spuinfoService.getById(order.getProductId());
        spuInfo.setStock(spuInfo.getStock() - 1);
        spuInfo.setSales(spuInfo.getSales() + 1);
        spuinfoService.updateById(spuInfo);
        orderService.updateById(order);
    }

    private BigDecimal cheapMoney(Integer couponId) {
        //TODO 判断是否使用优惠券
        if (null != couponId) {
            return couponService.getById(couponId).getAmount();
        }
        return BigDecimal.valueOf(0);
    }

    @Override
    public Page<TOrder> conditionSearch(TOrder order, Integer cur_page, Integer size) {
        QueryWrapper<TOrder> wrapper = new QueryWrapper<>();
        if (null != order.getProductId()) {
            wrapper.like("product_id", order.getProductId());
        }
        if (!StringUtils.isEmpty(order.getProductName())) {
            wrapper.eq("product_name", order.getProductName());
        }
        if (!StringUtils.isEmpty(order.getNickname())) {
            wrapper.eq("nickname", order.getNickname());
        }
        if (null != order.getStatus()) wrapper.like("status", order.getStatus());
        if (null != order.getShipState()) {
            wrapper.like("ship_state", order.getShipState());
        }
        Page<TOrder> page = new Page<>(cur_page, size);
        page(page, wrapper);
        page.getRecords().forEach(item -> {
            Address add = addressService.getById(item.getAddressId());
            item.setAddress(add);
        });
        return page;
    }


}
