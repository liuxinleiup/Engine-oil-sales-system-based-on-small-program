package com.biyesheji.costume.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.biyesheji.costume.common.MagicException;
import com.biyesheji.costume.pojo.User;
import com.biyesheji.costume.mapper.UserMapper;
import com.biyesheji.costume.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2020-11-16
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    String avatar_man = "https://tanhua-xyh.oss-cn-beijing.aliyuncs.com/images/man.jpg";
    String avatar_woman = "https://tanhua-xyh.oss-cn-beijing.aliyuncs.com/images/woman.jpg";


    //根据openid查询
    @Override
    public User getOpenIdMember(String openid) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("openid",openid);
        User user = baseMapper.selectOne(wrapper);
        return user;
    }

    @Override
    public void updateUserInfo(User user) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", user.getId());
        User db_user = getOne(queryWrapper);
        if (!StringUtils.isEmpty(user.getNickname() )){
            db_user.setNickname( user.getNickname() );
        }
        if (!StringUtils.isEmpty(user.getMobile() )){
            db_user.setMobile( user.getMobile() );
        }
        if (!StringUtils.isEmpty(user.getSex() )){
            db_user.setSex( user.getSex() );
        }
        baseMapper.update(db_user, queryWrapper);
    }

    @Override
    public Page<User> conditionSearch(User user, Integer cur_page, Integer size) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        if ( !org.springframework.util.StringUtils.isEmpty( user.getNickname() ) ){
            wrapper.like("nickname", user.getNickname());
        }
        if ( !org.springframework.util.StringUtils.isEmpty( user.getSex() ) ){
            wrapper.eq("sex", user.getSex());
        }
        Page<User> page = new Page<>(cur_page, size);
        page(page, wrapper);
        return page;
    }

    @Override
    public User login(User user) {
        //查询用户名
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("mobile",user.getMobile());
        User db_user = getOne(wrapper);
        if (null == db_user){
            throw new MagicException(20001, "用户不存在");
        }
        //校验密码
        if (!(db_user.getPassword().equals(user.getPassword()))){
            throw new MagicException(20001, "密码错误");
        }
        return db_user;
    }

    @Override
    public void register(User user) {
        user.setGmtCreate(new Date());
        //判断手机号是否存在
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("mobile", user.getMobile());
        User db_user = getOne(wrapper);
        if (null != db_user){
            throw new MagicException(20001, "该手机号已经注册");
        }
        user.setMoney(new BigDecimal(1000));
        if (user.getSex().equals("男")){
            user.setAvatar(avatar_man);
        }else{
            user.setAvatar(avatar_woman);
        }
        save(user);
    }
}
