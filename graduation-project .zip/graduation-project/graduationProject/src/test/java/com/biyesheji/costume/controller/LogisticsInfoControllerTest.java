package com.biyesheji.costume.controller;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class LogisticsInfoControllerTest {

    public static void main(String[] args) {
        System.out.println(UUID.randomUUID());
    }

}